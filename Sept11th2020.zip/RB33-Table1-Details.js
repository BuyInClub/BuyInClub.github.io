﻿var title = "Hand Details for RB33 at Table1";
var handFilename = "Table1-Details.html";
var data = [
{
id: 0,indent: 0,parent: null,handNum: "257",wonOrLost: "0.00",startAmt: "39.35",endAmt: "39.35",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 2,indent: 0,parent: null,handNum: "258",wonOrLost: "0.00",startAmt: "39.35",endAmt: "39.35",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 3,indent: 1,parent: 2,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 4,indent: 0,parent: null,handNum: "259",wonOrLost: "0.00",startAmt: "39.35",endAmt: "39.35",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 5,indent: 1,parent: 4,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 6,indent: 0,parent: null,handNum: "260",wonOrLost: "-0.50",startAmt: "39.35",endAmt: "38.85",finalHand: "",position: "BB (2 of 8)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 7,indent: 1,parent: 6,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 8,indent: 1,parent: 6,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.36",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.43",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 9,indent: 0,parent: null,handNum: "261",wonOrLost: "1.00",startAmt: "38.85",endAmt: "39.35",finalHand: "",position: "SB (1 of 8)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 10,indent: 1,parent: 9,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 11,indent: 1,parent: 9,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "0.75",potSizeToWin: "0.75",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 12,indent: 0,parent: null,handNum: "262",wonOrLost: "-16.26",startAmt: "39.35",endAmt: "23.09",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 13,indent: 1,parent: 12,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "2.50",potSizeToWin: "2.75",amountToPot: "90",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 14,indent: 1,parent: 12,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 15,indent: 1,parent: 12,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.66",potSizeToWin: "6.25",amountToPot: "42",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 16,indent: 1,parent: 12,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.66",potSizeToWin: "14.23",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Chris Moy",lastActionAmount: "5.32",boardCards: "",
},
{
id: 17,indent: 1,parent: 12,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "8.44",potSizeToWin: "25.33",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "8.44",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 18,indent: 0,parent: null,handNum: "263",wonOrLost: "-0.50",startAmt: "23.09",endAmt: "22.59",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 19,indent: 1,parent: 18,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 20,indent: 1,parent: 18,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 21,indent: 0,parent: null,handNum: "264",wonOrLost: "-0.50",startAmt: "22.59",endAmt: "22.09",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 22,indent: 1,parent: 21,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 23,indent: 1,parent: 21,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "",
},
{
id: 24,indent: 0,parent: null,handNum: "265",wonOrLost: "9.80",startAmt: "22.09",endAmt: "28.24",finalHand: "Two Pair, Q's & J's",position: "UTG2 (5 of 9)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 25,indent: 1,parent: 24,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 26,indent: 1,parent: 24,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.00",amountToPot: "16",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.75",boardCards: "",
},
{
id: 27,indent: 1,parent: 24,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "4.50",amountToPot: "11",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 28,indent: 1,parent: 24,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.02",potSizeToWin: "5.50",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 29,indent: 1,parent: 24,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.13",potSizeToWin: "7.54",amountToPot: "14",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 30,indent: 0,parent: null,handNum: "266",wonOrLost: "-0.50",startAmt: "28.24",endAmt: "27.74",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 31,indent: 1,parent: 30,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "9",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 32,indent: 1,parent: 30,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.68",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.93",boardCards: "",
},
{
id: 33,indent: 0,parent: null,handNum: "267",wonOrLost: "-11.46",startAmt: "27.74",endAmt: "16.28",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 34,indent: 1,parent: 33,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 35,indent: 1,parent: 33,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "5.75",amountToPot: "43",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "",
},
{
id: 36,indent: 1,parent: 33,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "4.23",potSizeToWin: "10.75",amountToPot: "39",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 37,indent: 1,parent: 33,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "4.23",potSizeToWin: "23.44",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "8.46",boardCards: "",
},
{
id: 38,indent: 1,parent: 33,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "27.67",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 39,indent: 1,parent: 33,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "27.67",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 40,indent: 1,parent: 33,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "41.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "13.83",boardCards: "",
},
{
id: 41,indent: 0,parent: null,handNum: "268",wonOrLost: "-0.50",startAmt: "16.28",endAmt: "15.78",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 42,indent: 1,parent: 41,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 43,indent: 1,parent: 41,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.25",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 44,indent: 0,parent: null,handNum: "269",wonOrLost: "-0.25",startAmt: "15.78",endAmt: "15.53",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 45,indent: 1,parent: 44,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 46,indent: 1,parent: 44,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 47,indent: 0,parent: null,handNum: "270",wonOrLost: "0.00",startAmt: "15.53",endAmt: "15.53",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 48,indent: 1,parent: 47,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 49,indent: 0,parent: null,handNum: "271",wonOrLost: "0.00",startAmt: "15.53",endAmt: "15.53",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 50,indent: 1,parent: 49,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 51,indent: 0,parent: null,handNum: "272",wonOrLost: "0.00",startAmt: "15.53",endAmt: "15.53",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 52,indent: 1,parent: 51,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "5",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 53,indent: 0,parent: null,handNum: "273",wonOrLost: "-0.50",startAmt: "15.53",endAmt: "15.03",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 54,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 55,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.87",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "6.37",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 56,indent: 0,parent: null,handNum: "274",wonOrLost: "0.00",startAmt: "15.03",endAmt: "15.03",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 57,indent: 1,parent: 56,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 58,indent: 0,parent: null,handNum: "275",wonOrLost: "0.00",startAmt: "15.03",endAmt: "15.03",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 59,indent: 1,parent: 58,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 60,indent: 0,parent: null,handNum: "276",wonOrLost: "-0.50",startAmt: "15.03",endAmt: "14.53",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 61,indent: 1,parent: 60,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 62,indent: 1,parent: 60,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "9.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 63,indent: 0,parent: null,handNum: "277",wonOrLost: "-2.00",startAmt: "14.53",endAmt: "12.53",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 64,indent: 1,parent: 63,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 65,indent: 1,parent: 63,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "5.75",amountToPot: "30",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 66,indent: 1,parent: 63,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "21.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Reraise",lastActionPlayer: "Craig",lastActionAmount: "5.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 67,indent: 0,parent: null,handNum: "278",wonOrLost: "1.75",startAmt: "12.53",endAmt: "13.78",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 68,indent: 1,parent: 67,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 69,indent: 1,parent: 67,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 70,indent: 1,parent: 67,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 71,indent: 1,parent: 67,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.31",potSizeToWin: "1.75",amountToPot: "74",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 72,indent: 0,parent: null,handNum: "279",wonOrLost: "0.00",startAmt: "13.78",endAmt: "13.78",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 73,indent: 1,parent: 72,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 74,indent: 0,parent: null,handNum: "280",wonOrLost: "0.00",startAmt: "13.78",endAmt: "13.78",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 75,indent: 1,parent: 74,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "",
},
{
id: 76,indent: 0,parent: null,handNum: "281",wonOrLost: "0.00",startAmt: "13.78",endAmt: "13.78",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 77,indent: 1,parent: 76,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 78,indent: 0,parent: null,handNum: "282",wonOrLost: "1.50",startAmt: "13.78",endAmt: "14.78",finalHand: "Pair, 10's",position: "UTG2 (5 of 9)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 79,indent: 1,parent: 78,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 80,indent: 1,parent: 78,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 81,indent: 1,parent: 78,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 82,indent: 1,parent: 78,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 83,indent: 0,parent: null,handNum: "283",wonOrLost: "38.56",startAmt: "14.78",endAmt: "38.56",finalHand: "Pair, A's",position: "MP1 (4 of 9)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 84,indent: 1,parent: 83,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 85,indent: 1,parent: 83,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "12.50",amountToPot: "20",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "",
},
{
id: 86,indent: 1,parent: 83,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "BetAllIn",amount: "11.78",potSizeToWin: "15.00",amountToPot: "78",numPlayers: "5",numAllIns: "1",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 87,indent: 0,parent: null,handNum: "284",wonOrLost: "0.00",startAmt: "38.56",endAmt: "38.56",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 88,indent: 1,parent: 87,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 89,indent: 0,parent: null,handNum: "285",wonOrLost: "-0.50",startAmt: "38.56",endAmt: "38.06",finalHand: "",position: "BB (2 of 9)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 90,indent: 1,parent: 89,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 91,indent: 1,parent: 89,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "2.75",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 92,indent: 0,parent: null,handNum: "286",wonOrLost: "16.25",startAmt: "38.06",endAmt: "49.06",finalHand: "",position: "SB (1 of 9)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 93,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 94,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 95,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 96,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.75",potSizeToWin: "5.00",amountToPot: "75",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 97,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "5.61",potSizeToWin: "16.25",amountToPot: "34",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 98,indent: 0,parent: null,handNum: "287",wonOrLost: "0.00",startAmt: "49.06",endAmt: "49.06",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 99,indent: 1,parent: 98,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 100,indent: 0,parent: null,handNum: "288",wonOrLost: "0.00",startAmt: "49.06",endAmt: "49.06",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 101,indent: 1,parent: 100,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.75",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 102,indent: 0,parent: null,handNum: "289",wonOrLost: "-3.00",startAmt: "49.06",endAmt: "46.06",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 103,indent: 1,parent: 102,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 104,indent: 1,parent: 102,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "8.00",amountToPot: "31",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "",
},
{
id: 105,indent: 1,parent: 102,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 106,indent: 1,parent: 102,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "17.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "7.25",boardCards: "",
},
{
id: 107,indent: 0,parent: null,handNum: "290",wonOrLost: "0.00",startAmt: "46.06",endAmt: "46.06",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 108,indent: 1,parent: 107,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 109,indent: 0,parent: null,handNum: "291",wonOrLost: "-0.50",startAmt: "46.06",endAmt: "45.56",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 110,indent: 1,parent: 109,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "9",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 111,indent: 1,parent: 109,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Greg",lastActionAmount: "5.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 112,indent: 0,parent: null,handNum: "292",wonOrLost: "-0.50",startAmt: "45.56",endAmt: "45.06",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 113,indent: 1,parent: 112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 114,indent: 1,parent: 112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 115,indent: 1,parent: 112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 116,indent: 0,parent: null,handNum: "293",wonOrLost: "-0.50",startAmt: "45.06",endAmt: "44.56",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 117,indent: 1,parent: 116,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 118,indent: 1,parent: 116,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 119,indent: 1,parent: 116,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "4.50",boardCards: "",
},
{
id: 120,indent: 0,parent: null,handNum: "294",wonOrLost: "-0.50",startAmt: "44.56",endAmt: "44.06",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 121,indent: 1,parent: 120,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 122,indent: 1,parent: 120,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 123,indent: 0,parent: null,handNum: "295",wonOrLost: "-3.25",startAmt: "44.06",endAmt: "40.81",finalHand: "",position: "SB (1 of 9)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 124,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 125,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "3.00",potSizeToWin: "7.25",amountToPot: "41",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.25",boardCards: "",
},
{
id: 126,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "10.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 127,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "27.37",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "13.12",boardCards: "",
},
{
id: 128,indent: 0,parent: null,handNum: "296",wonOrLost: "10.75",startAmt: "40.81",endAmt: "47.06",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 129,indent: 1,parent: 128,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "",
},
{
id: 130,indent: 1,parent: 128,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "6.00",potSizeToWin: "7.75",amountToPot: "77",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "3.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 131,indent: 0,parent: null,handNum: "297",wonOrLost: "-2.00",startAmt: "47.06",endAmt: "45.06",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 132,indent: 1,parent: 131,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "2.75",amountToPot: "72",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 133,indent: 1,parent: 131,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "4.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 134,indent: 0,parent: null,handNum: "298",wonOrLost: "0.00",startAmt: "45.06",endAmt: "45.06",finalHand: "",position: "Hijack (7 of 9)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 135,indent: 1,parent: 134,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 136,indent: 0,parent: null,handNum: "299",wonOrLost: "0.00",startAmt: "45.06",endAmt: "45.06",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 137,indent: 1,parent: 136,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "29.32",amountToPot: "0",numPlayers: "7",numAllIns: "1",positionToLastAction: "1",lastAction: "RaiseAllIn",lastActionPlayer: "Chris Moy",lastActionAmount: "28.57",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 138,indent: 0,parent: null,handNum: "300",wonOrLost: "0.00",startAmt: "45.06",endAmt: "45.06",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 139,indent: 1,parent: 138,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 140,indent: 0,parent: null,handNum: "301",wonOrLost: "-4.00",startAmt: "45.06",endAmt: "41.06",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 141,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 142,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.50",amountToPot: "27",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 143,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 144,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "11.00",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 145,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "13.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 146,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "13.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 147,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "14.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 148,indent: 0,parent: null,handNum: "302",wonOrLost: "-0.50",startAmt: "41.06",endAmt: "40.56",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 149,indent: 1,parent: 148,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 150,indent: 1,parent: 148,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 151,indent: 0,parent: null,handNum: "303",wonOrLost: "8.00",startAmt: "40.56",endAmt: "45.06",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 152,indent: 1,parent: 151,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 153,indent: 1,parent: 151,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "0.75",potSizeToWin: "1.25",amountToPot: "60",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 154,indent: 1,parent: 151,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 155,indent: 1,parent: 151,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "CheckRaise",amount: "5.00",potSizeToWin: "5.50",amountToPot: "90",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "",
},
{
id: 156,indent: 0,parent: null,handNum: "304",wonOrLost: "0.00",startAmt: "45.06",endAmt: "45.06",finalHand: "",position: "Dealer (8 of 8)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 157,indent: 1,parent: 156,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 158,indent: 0,parent: null,handNum: "305",wonOrLost: "0.00",startAmt: "45.06",endAmt: "45.06",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 159,indent: 1,parent: 158,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 160,indent: 0,parent: null,handNum: "306",wonOrLost: "-6.61",startAmt: "45.06",endAmt: "38.45",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 161,indent: 1,parent: 160,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 162,indent: 1,parent: 160,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.00",potSizeToWin: "3.00",amountToPot: "100",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 163,indent: 1,parent: 160,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.11",potSizeToWin: "9.00",amountToPot: "34",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 164,indent: 1,parent: 160,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "21.44",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Greg",lastActionAmount: "9.33",boardCards: "",
},
{
id: 165,indent: 0,parent: null,handNum: "307",wonOrLost: "0.00",startAmt: "38.45",endAmt: "38.45",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 166,indent: 1,parent: 165,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 167,indent: 0,parent: null,handNum: "308",wonOrLost: "0.00",startAmt: "38.45",endAmt: "38.45",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 168,indent: 1,parent: 167,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 169,indent: 0,parent: null,handNum: "309",wonOrLost: "-2.50",startAmt: "38.45",endAmt: "35.95",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 170,indent: 1,parent: 169,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 171,indent: 1,parent: 169,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "3.75",amountToPot: "53",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "",
},
{
id: 172,indent: 1,parent: 169,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 173,indent: 1,parent: 169,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 174,indent: 0,parent: null,handNum: "310",wonOrLost: "-1.50",startAmt: "35.95",endAmt: "34.45",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 175,indent: 1,parent: 174,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 176,indent: 1,parent: 174,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "6.50",amountToPot: "15",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 177,indent: 1,parent: 174,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "11.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.75",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 178,indent: 0,parent: null,handNum: "311",wonOrLost: "-0.25",startAmt: "34.45",endAmt: "34.20",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 179,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 180,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 181,indent: 0,parent: null,handNum: "312",wonOrLost: "0.00",startAmt: "34.20",endAmt: "34.20",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 182,indent: 1,parent: 181,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Chris Moy",lastActionAmount: "3.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 183,indent: 0,parent: null,handNum: "313",wonOrLost: "0.00",startAmt: "34.20",endAmt: "34.20",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 184,indent: 1,parent: 183,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 185,indent: 0,parent: null,handNum: "314",wonOrLost: "7.23",startAmt: "34.20",endAmt: "38.69",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 186,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.62",potSizeToWin: "1.75",amountToPot: "92",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 187,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.12",potSizeToWin: "6.11",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Craig",lastActionAmount: "2.74",boardCards: "",
},
{
id: 188,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.09",potSizeToWin: "7.23",amountToPot: "28",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 189,indent: 0,parent: null,handNum: "315",wonOrLost: "-0.50",startAmt: "38.69",endAmt: "38.19",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 190,indent: 1,parent: 189,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "8",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 191,indent: 1,parent: 189,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 192,indent: 0,parent: null,handNum: "316",wonOrLost: "-10.66",startAmt: "38.19",endAmt: "27.53",finalHand: "",position: "MP1 (4 of 8)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 193,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 194,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "5.50",amountToPot: "45",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.75",boardCards: "",
},
{
id: 195,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.33",potSizeToWin: "10.50",amountToPot: "31",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 196,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.33",potSizeToWin: "20.49",amountToPot: "16",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "6.66",boardCards: "",
},
{
id: 197,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "23.82",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 198,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "23.82",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 199,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "1.00",potSizeToWin: "24.82",amountToPot: "4",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 200,indent: 0,parent: null,handNum: "317",wonOrLost: "6.00",startAmt: "27.53",endAmt: "31.03",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 201,indent: 1,parent: 200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 202,indent: 1,parent: 200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 203,indent: 1,parent: 200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.00",potSizeToWin: "4.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 204,indent: 1,parent: 200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "2.09",potSizeToWin: "6.00",amountToPot: "34",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 205,indent: 0,parent: null,handNum: "318",wonOrLost: "-0.50",startAmt: "31.03",endAmt: "30.53",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 206,indent: 1,parent: 205,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 207,indent: 1,parent: 205,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.25",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 208,indent: 0,parent: null,handNum: "319",wonOrLost: "-0.25",startAmt: "30.53",endAmt: "30.28",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 209,indent: 1,parent: 208,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 210,indent: 1,parent: 208,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 211,indent: 0,parent: null,handNum: "320",wonOrLost: "0.00",startAmt: "30.28",endAmt: "30.28",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 212,indent: 1,parent: 211,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "4.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 213,indent: 0,parent: null,handNum: "321",wonOrLost: "0.00",startAmt: "30.28",endAmt: "30.28",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 214,indent: 1,parent: 213,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 215,indent: 0,parent: null,handNum: "322",wonOrLost: "0.00",startAmt: "30.28",endAmt: "30.28",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 216,indent: 1,parent: 215,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 217,indent: 0,parent: null,handNum: "323",wonOrLost: "0.00",startAmt: "30.28",endAmt: "30.28",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 218,indent: 1,parent: 217,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 219,indent: 0,parent: null,handNum: "324",wonOrLost: "-4.52",startAmt: "30.28",endAmt: "25.76",finalHand: "",position: "MP1 (4 of 8)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 220,indent: 1,parent: 219,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.01",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 221,indent: 1,parent: 219,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.51",potSizeToWin: "7.53",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "4.27",boardCards: "",
},
{
id: 222,indent: 1,parent: 219,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "15.06",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "5.02",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 223,indent: 0,parent: null,handNum: "325",wonOrLost: "-0.50",startAmt: "25.76",endAmt: "25.26",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 224,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 225,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.25",boardCards: "",
},
{
id: 226,indent: 0,parent: null,handNum: "326",wonOrLost: "-0.50",startAmt: "25.26",endAmt: "24.76",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 227,indent: 1,parent: 226,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 228,indent: 1,parent: 226,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 229,indent: 0,parent: null,handNum: "327",wonOrLost: "-0.50",startAmt: "24.76",endAmt: "24.26",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 230,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 231,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 232,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 233,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 234,indent: 0,parent: null,handNum: "328",wonOrLost: "-2.25",startAmt: "24.26",endAmt: "22.01",finalHand: "",position: "Dealer (8 of 8)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 235,indent: 1,parent: 234,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.75",amountToPot: "18",numPlayers: "7",numAllIns: "0",positionToLastAction: "5",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 236,indent: 1,parent: 234,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "10.25",amountToPot: "17",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.75",boardCards: "",
},
{
id: 237,indent: 1,parent: 234,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "24.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "12.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 238,indent: 0,parent: null,handNum: "329",wonOrLost: "5.00",startAmt: "22.01",endAmt: "25.51",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 239,indent: 1,parent: 238,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 240,indent: 1,parent: 238,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "3.31",potSizeToWin: "4.00",amountToPot: "82",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 241,indent: 0,parent: null,handNum: "330",wonOrLost: "0.00",startAmt: "25.51",endAmt: "25.51",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 242,indent: 1,parent: 241,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 243,indent: 0,parent: null,handNum: "331",wonOrLost: "-0.50",startAmt: "25.51",endAmt: "25.01",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 244,indent: 1,parent: 243,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 245,indent: 1,parent: 243,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 246,indent: 0,parent: null,handNum: "332",wonOrLost: "0.00",startAmt: "25.01",endAmt: "25.01",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 247,indent: 1,parent: 246,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 248,indent: 0,parent: null,handNum: "333",wonOrLost: "-25.01",startAmt: "25.01",endAmt: "0.00",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 249,indent: 1,parent: 248,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.30",potSizeToWin: "0.75",amountToPot: "306",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 250,indent: 1,parent: 248,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "4.60",potSizeToWin: "9.45",amountToPot: "48",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Chris Moy",lastActionAmount: "6.40",boardCards: "",
},
{
id: 251,indent: 1,parent: 248,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.15",potSizeToWin: "14.05",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 252,indent: 1,parent: 248,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "RaiseAllIn",amount: "14.96",potSizeToWin: "25.35",amountToPot: "59",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 253,indent: 0,parent: null,handNum: "337",wonOrLost: "44.50",startAmt: "40.00",endAmt: "64.75",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 254,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "PostsMissingSmallBlind",amount: "0.25",potSizeToWin: "0.75",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 255,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "4.00",amountToPot: "37",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 256,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "10.50",amountToPot: "19",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "2.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 257,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "16.00",potSizeToWin: "20.50",amountToPot: "78",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "8.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 258,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "5.35",potSizeToWin: "44.50",amountToPot: "12",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 259,indent: 0,parent: null,handNum: "338",wonOrLost: "12.48",startAmt: "64.75",endAmt: "71.74",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 260,indent: 1,parent: 259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 261,indent: 1,parent: 259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.87",potSizeToWin: "2.50",amountToPot: "74",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 262,indent: 1,parent: 259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.12",potSizeToWin: "9.36",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Jeff",lastActionAmount: "4.99",boardCards: "",
},
{
id: 263,indent: 1,parent: 259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "5.11",potSizeToWin: "12.48",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 264,indent: 0,parent: null,handNum: "339",wonOrLost: "0.00",startAmt: "71.74",endAmt: "71.74",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 265,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 266,indent: 0,parent: null,handNum: "340",wonOrLost: "-4.50",startAmt: "71.74",endAmt: "67.24",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 267,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 268,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "6.25",amountToPot: "32",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "",
},
{
id: 269,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 270,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "10.25",amountToPot: "19",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 271,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "12.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 272,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "12.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 273,indent: 0,parent: null,handNum: "341",wonOrLost: "-1.50",startAmt: "67.24",endAmt: "65.74",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 274,indent: 1,parent: 273,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 275,indent: 1,parent: 273,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "6.50",amountToPot: "15",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 276,indent: 1,parent: 273,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 277,indent: 1,parent: 273,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "",
},
{
id: 278,indent: 0,parent: null,handNum: "342",wonOrLost: "-16.06",startAmt: "65.74",endAmt: "49.68",finalHand: "",position: "SB (1 of 8)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 279,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 280,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "6.00",amountToPot: "25",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.75",boardCards: "",
},
{
id: 281,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.75",potSizeToWin: "7.50",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 282,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "5.19",potSizeToWin: "15.00",amountToPot: "34",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 283,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "5.37",potSizeToWin: "25.38",amountToPot: "21",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 284,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "45.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "15.00",boardCards: "",
},
{
id: 285,indent: 0,parent: null,handNum: "343",wonOrLost: "0.00",startAmt: "49.68",endAmt: "49.68",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 286,indent: 1,parent: 285,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "2.50",boardCards: "",
},
{
id: 287,indent: 0,parent: null,handNum: "344",wonOrLost: "-0.50",startAmt: "49.68",endAmt: "49.18",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 288,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 289,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 290,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.75",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 291,indent: 0,parent: null,handNum: "345",wonOrLost: "-0.50",startAmt: "49.18",endAmt: "48.68",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 292,indent: 1,parent: 291,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 293,indent: 1,parent: 291,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 294,indent: 0,parent: null,handNum: "346",wonOrLost: "20.18",startAmt: "48.68",endAmt: "62.77",finalHand: "Flush, Kd High",position: "UTG2 (5 of 8)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 295,indent: 1,parent: 294,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "3.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 296,indent: 1,parent: 294,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "13.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 297,indent: 1,parent: 294,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.59",potSizeToWin: "13.00",amountToPot: "27",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 298,indent: 1,parent: 294,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "20.18",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 299,indent: 0,parent: null,handNum: "347",wonOrLost: "1.75",startAmt: "62.77",endAmt: "64.02",finalHand: "",position: "MP1 (4 of 8)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 300,indent: 1,parent: 299,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 301,indent: 1,parent: 299,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "1.75",amountToPot: "85",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 302,indent: 0,parent: null,handNum: "348",wonOrLost: "3.25",startAmt: "64.02",endAmt: "66.27",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 303,indent: 1,parent: 302,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "0.75",amountToPot: "133",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 304,indent: 1,parent: 302,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.62",potSizeToWin: "3.25",amountToPot: "49",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 305,indent: 0,parent: null,handNum: "349",wonOrLost: "-3.97",startAmt: "66.27",endAmt: "62.30",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 306,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 307,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 308,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 309,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.47",potSizeToWin: "3.00",amountToPot: "82",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 310,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.94",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 311,indent: 0,parent: null,handNum: "350",wonOrLost: "24.84",startAmt: "62.30",endAmt: "75.22",finalHand: "Three of a Kind, 10's",position: "SB (1 of 8)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 312,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 313,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 314,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 315,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "4.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 316,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 317,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "CheckRaise",amount: "6.00",potSizeToWin: "9.00",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "3.00",boardCards: "",
},
{
id: 318,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "3.42",potSizeToWin: "18.00",amountToPot: "19",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 319,indent: 0,parent: null,handNum: "351",wonOrLost: "0.00",startAmt: "75.22",endAmt: "75.22",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 320,indent: 1,parent: 319,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 321,indent: 0,parent: null,handNum: "352",wonOrLost: "22.50",startAmt: "75.22",endAmt: "87.47",finalHand: "Straight, Q High",position: "Cutoff (7 of 8)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 322,indent: 1,parent: 321,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 323,indent: 1,parent: 321,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.25",potSizeToWin: "5.25",amountToPot: "42",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.25",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 324,indent: 1,parent: 321,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 325,indent: 1,parent: 321,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "7.50",potSizeToWin: "15.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "7.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 326,indent: 0,parent: null,handNum: "353",wonOrLost: "-5.50",startAmt: "87.47",endAmt: "81.97",finalHand: "",position: "Hijack (6 of 8)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 327,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "1.25",amountToPot: "80",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 328,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "5.75",amountToPot: "43",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Craig",lastActionAmount: "3.50",boardCards: "",
},
{
id: 329,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "8.25",amountToPot: "6",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 330,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "10.75",amountToPot: "13",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 331,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "12.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 332,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "14.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "",
},
{
id: 333,indent: 0,parent: null,handNum: "354",wonOrLost: "-0.50",startAmt: "81.97",endAmt: "81.47",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 334,indent: 1,parent: 333,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 335,indent: 1,parent: 333,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "4.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 336,indent: 0,parent: null,handNum: "355",wonOrLost: "-0.50",startAmt: "81.47",endAmt: "80.97",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 337,indent: 1,parent: 336,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 338,indent: 1,parent: 336,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 339,indent: 1,parent: 336,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.75",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 340,indent: 0,parent: null,handNum: "356",wonOrLost: "0.00",startAmt: "80.97",endAmt: "80.97",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 341,indent: 1,parent: 340,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 342,indent: 0,parent: null,handNum: "357",wonOrLost: "-0.50",startAmt: "80.97",endAmt: "80.47",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 343,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 344,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 345,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 346,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 347,indent: 0,parent: null,handNum: "358",wonOrLost: "-2.16",startAmt: "80.47",endAmt: "78.31",finalHand: "",position: "SB (1 of 8)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 348,indent: 1,parent: 347,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 349,indent: 1,parent: 347,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.91",potSizeToWin: "2.75",amountToPot: "69",numPlayers: "6",numAllIns: "0",positionToLastAction: "5",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 350,indent: 1,parent: 347,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.98",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 351,indent: 1,parent: 347,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "11.97",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "3.99",boardCards: "",
},
{
id: 352,indent: 0,parent: null,handNum: "359",wonOrLost: "-1.50",startAmt: "78.31",endAmt: "76.81",finalHand: "",position: "Dealer (8 of 8)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 353,indent: 1,parent: 352,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.75",amountToPot: "54",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 354,indent: 1,parent: 352,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.87",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.62",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 355,indent: 0,parent: null,handNum: "360",wonOrLost: "3.75",startAmt: "76.81",endAmt: "79.56",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 356,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 357,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.25",amountToPot: "15",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "",
},
{
id: 358,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 359,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.75",potSizeToWin: "3.75",amountToPot: "100",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 360,indent: 0,parent: null,handNum: "361",wonOrLost: "0.00",startAmt: "79.56",endAmt: "79.56",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 361,indent: 1,parent: 360,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 362,indent: 0,parent: null,handNum: "362",wonOrLost: "0.00",startAmt: "79.56",endAmt: "79.56",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 363,indent: 1,parent: 362,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 364,indent: 0,parent: null,handNum: "363",wonOrLost: "-0.50",startAmt: "79.56",endAmt: "79.06",finalHand: "",position: "MP1 (4 of 8)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 365,indent: 1,parent: 364,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 366,indent: 1,parent: 364,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "2.25",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 367,indent: 0,parent: null,handNum: "364",wonOrLost: "0.00",startAmt: "79.06",endAmt: "79.06",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 368,indent: 1,parent: 367,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 369,indent: 0,parent: null,handNum: "365",wonOrLost: "-0.50",startAmt: "79.06",endAmt: "78.56",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 370,indent: 1,parent: 369,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 371,indent: 1,parent: 369,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "4.00",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 372,indent: 0,parent: null,handNum: "366",wonOrLost: "-0.25",startAmt: "78.56",endAmt: "78.31",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 373,indent: 1,parent: 372,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 374,indent: 1,parent: 372,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "2.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 375,indent: 0,parent: null,handNum: "367",wonOrLost: "0.00",startAmt: "78.31",endAmt: "78.31",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 376,indent: 1,parent: 375,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 377,indent: 0,parent: null,handNum: "368",wonOrLost: "0.00",startAmt: "78.31",endAmt: "78.31",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 378,indent: 1,parent: 377,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "",
},
{
id: 379,indent: 0,parent: null,handNum: "369",wonOrLost: "0.00",startAmt: "78.31",endAmt: "78.31",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 380,indent: 1,parent: 379,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 381,indent: 0,parent: null,handNum: "370",wonOrLost: "-2.00",startAmt: "78.31",endAmt: "76.31",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 382,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 383,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.25",amountToPot: "28",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 384,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 385,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 386,indent: 0,parent: null,handNum: "371",wonOrLost: "-0.50",startAmt: "76.31",endAmt: "75.81",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 387,indent: 1,parent: 386,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 388,indent: 1,parent: 386,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, [10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 389,indent: 0,parent: null,handNum: "372",wonOrLost: "-2.00",startAmt: "75.81",endAmt: "73.81",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 390,indent: 1,parent: 389,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 391,indent: 1,parent: 389,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "3.25",amountToPot: "46",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "",
},
{
id: 392,indent: 1,parent: 389,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 393,indent: 1,parent: 389,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "3.50",boardCards: "",
},
{
id: 394,indent: 0,parent: null,handNum: "373",wonOrLost: "-2.00",startAmt: "73.81",endAmt: "71.81",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 395,indent: 1,parent: 394,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 396,indent: 1,parent: 394,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "4.75",amountToPot: "31",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 397,indent: 1,parent: 394,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 398,indent: 1,parent: 394,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 399,indent: 0,parent: null,handNum: "374",wonOrLost: "-0.25",startAmt: "71.81",endAmt: "71.56",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 400,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 401,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 402,indent: 0,parent: null,handNum: "375",wonOrLost: "-5.25",startAmt: "71.56",endAmt: "66.31",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 403,indent: 1,parent: 402,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 404,indent: 1,parent: 402,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "4.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 405,indent: 1,parent: 402,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.25",potSizeToWin: "6.00",amountToPot: "54",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 406,indent: 1,parent: 402,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "12.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 407,indent: 0,parent: null,handNum: "376",wonOrLost: "-1.81",startAmt: "66.31",endAmt: "64.50",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 408,indent: 1,parent: 407,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.81",potSizeToWin: "1.25",amountToPot: "144",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 409,indent: 1,parent: 407,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.86",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.62",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, [2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 410,indent: 0,parent: null,handNum: "377",wonOrLost: "0.00",startAmt: "64.50",endAmt: "64.50",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 411,indent: 1,parent: 410,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 412,indent: 0,parent: null,handNum: "378",wonOrLost: "0.00",startAmt: "64.50",endAmt: "64.50",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 413,indent: 1,parent: 412,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 414,indent: 0,parent: null,handNum: "379",wonOrLost: "0.00",startAmt: "64.50",endAmt: "64.50",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 415,indent: 1,parent: 414,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 416,indent: 0,parent: null,handNum: "380",wonOrLost: "-4.75",startAmt: "64.50",endAmt: "59.75",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 417,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 418,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 419,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.25",potSizeToWin: "2.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 420,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "7.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Chris Moy",lastActionAmount: "3.75",boardCards: "",
},
{
id: 421,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "15.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 422,indent: 0,parent: null,handNum: "381",wonOrLost: "-0.50",startAmt: "59.75",endAmt: "59.25",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 423,indent: 1,parent: 422,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 424,indent: 1,parent: 422,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 425,indent: 1,parent: 422,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 426,indent: 1,parent: 422,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 427,indent: 0,parent: null,handNum: "382",wonOrLost: "-0.25",startAmt: "59.25",endAmt: "59.00",finalHand: "",position: "SB (1 of 8)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 428,indent: 1,parent: 427,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 429,indent: 1,parent: 427,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 430,indent: 0,parent: null,handNum: "383",wonOrLost: "0.00",startAmt: "59.00",endAmt: "59.00",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 431,indent: 1,parent: 430,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 432,indent: 0,parent: null,handNum: "384",wonOrLost: "0.00",startAmt: "59.00",endAmt: "59.00",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 433,indent: 1,parent: 432,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 434,indent: 0,parent: null,handNum: "385",wonOrLost: "-1.50",startAmt: "59.00",endAmt: "57.50",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 435,indent: 1,parent: 434,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 436,indent: 1,parent: 434,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 437,indent: 0,parent: null,handNum: "386",wonOrLost: "-1.50",startAmt: "57.50",endAmt: "56.00",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 438,indent: 1,parent: 437,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 439,indent: 1,parent: 437,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.12",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.37",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 440,indent: 0,parent: null,handNum: "387",wonOrLost: "0.00",startAmt: "56.00",endAmt: "56.00",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 441,indent: 1,parent: 440,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 442,indent: 0,parent: null,handNum: "388",wonOrLost: "47.08",startAmt: "56.00",endAmt: "80.79",finalHand: "Two Pair, A's & 8's",position: "UTG1 (3 of 8)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 443,indent: 1,parent: 442,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 444,indent: 1,parent: 442,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "3.00",potSizeToWin: "5.00",amountToPot: "60",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 445,indent: 1,parent: 442,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.93",potSizeToWin: "9.50",amountToPot: "41",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 446,indent: 1,parent: 442,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "14.86",potSizeToWin: "32.22",amountToPot: "46",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "14.86",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 447,indent: 0,parent: null,handNum: "389",wonOrLost: "-1.25",startAmt: "80.79",endAmt: "79.54",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 448,indent: 1,parent: 447,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 449,indent: 1,parent: 447,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 450,indent: 1,parent: 447,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 451,indent: 1,parent: 447,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 452,indent: 1,parent: 447,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.75",potSizeToWin: "3.25",amountToPot: "23",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "0.75",boardCards: "",
},
{
id: 453,indent: 1,parent: 447,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 454,indent: 1,parent: 447,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "3.00",boardCards: "",
},
{
id: 455,indent: 0,parent: null,handNum: "390",wonOrLost: "-0.25",startAmt: "79.54",endAmt: "79.29",finalHand: "",position: "SB (1 of 8)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 456,indent: 1,parent: 455,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 457,indent: 1,parent: 455,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 458,indent: 0,parent: null,handNum: "391",wonOrLost: "0.00",startAmt: "79.29",endAmt: "79.29",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 459,indent: 1,parent: 458,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.25",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 460,indent: 0,parent: null,handNum: "392",wonOrLost: "-1.50",startAmt: "79.29",endAmt: "77.79",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 461,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 462,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.50",amountToPot: "22",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 463,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.70",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.20",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 464,indent: 0,parent: null,handNum: "393",wonOrLost: "0.00",startAmt: "77.79",endAmt: "77.79",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 465,indent: 1,parent: 464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 466,indent: 0,parent: null,handNum: "394",wonOrLost: "27.88",startAmt: "77.79",endAmt: "93.23",finalHand: "Flush, Qs High",position: "UTG2 (5 of 8)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 467,indent: 1,parent: 466,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 468,indent: 1,parent: 466,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.50",amountToPot: "27",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "2.00",boardCards: "",
},
{
id: 469,indent: 1,parent: 466,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 470,indent: 1,parent: 466,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.00",potSizeToWin: "10.00",amountToPot: "30",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "3.00",boardCards: "",
},
{
id: 471,indent: 1,parent: 466,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "13.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 472,indent: 1,parent: 466,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.00",potSizeToWin: "16.00",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "3.00",boardCards: "",
},
{
id: 473,indent: 1,parent: 466,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "4.44",potSizeToWin: "19.00",amountToPot: "23",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 474,indent: 0,parent: null,handNum: "395",wonOrLost: "0.00",startAmt: "93.23",endAmt: "93.23",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 475,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 476,indent: 0,parent: null,handNum: "396",wonOrLost: "-2.25",startAmt: "93.23",endAmt: "90.98",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 477,indent: 1,parent: 476,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.75",potSizeToWin: "0.75",amountToPot: "233",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 478,indent: 1,parent: 476,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "9.75",amountToPot: "5",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 479,indent: 1,parent: 476,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "22.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "7.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 480,indent: 0,parent: null,handNum: "397",wonOrLost: "10.00",startAmt: "90.98",endAmt: "98.48",finalHand: "",position: "BB (2 of 8)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 481,indent: 1,parent: 480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 482,indent: 1,parent: 480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "2.00",amountToPot: "100",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 483,indent: 1,parent: 480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "5.12",potSizeToWin: "10.00",amountToPot: "51",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 484,indent: 0,parent: null,handNum: "398",wonOrLost: "4.50",startAmt: "98.48",endAmt: "100.98",finalHand: "",position: "SB (1 of 8)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 485,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 486,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 487,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 488,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "CheckRaise",amount: "5.13",potSizeToWin: "3.00",amountToPot: "171",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 489,indent: 0,parent: null,handNum: "399",wonOrLost: "0.00",startAmt: "100.98",endAmt: "100.98",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 490,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 491,indent: 0,parent: null,handNum: "400",wonOrLost: "0.00",startAmt: "100.98",endAmt: "100.98",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 492,indent: 1,parent: 491,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 493,indent: 0,parent: null,handNum: "401",wonOrLost: "0.00",startAmt: "100.98",endAmt: "100.98",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 494,indent: 1,parent: 493,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 495,indent: 0,parent: null,handNum: "402",wonOrLost: "0.00",startAmt: "100.98",endAmt: "100.98",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 496,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
];
