﻿var title = "Hand Details for Will at Table1";
var handFilename = "Table1-Details.html";
var data = [
{
id: 0,indent: 0,parent: null,handNum: "1",wonOrLost: "-1.50",startAmt: "20.00",endAmt: "18.50",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 2,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "3.50",amountToPot: "28",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "",
},
{
id: 3,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.25",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, [6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 4,indent: 0,parent: null,handNum: "2",wonOrLost: "-0.50",startAmt: "18.50",endAmt: "18.00",finalHand: "",position: "SB (1 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 5,indent: 1,parent: 4,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.00",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 6,indent: 1,parent: 4,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 7,indent: 1,parent: 4,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 8,indent: 1,parent: 4,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "",
},
{
id: 9,indent: 0,parent: null,handNum: "3",wonOrLost: "-1.00",startAmt: "18.00",endAmt: "17.00",finalHand: "",position: "SB (1 of 3)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 10,indent: 1,parent: 9,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 11,indent: 1,parent: 9,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 12,indent: 1,parent: 9,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 13,indent: 1,parent: 9,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 14,indent: 1,parent: 9,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 15,indent: 0,parent: null,handNum: "4",wonOrLost: "0.00",startAmt: "17.00",endAmt: "17.00",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 16,indent: 1,parent: 15,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 17,indent: 0,parent: null,handNum: "5",wonOrLost: "3.00",startAmt: "17.00",endAmt: "19.00",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 18,indent: 1,parent: 17,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 19,indent: 1,parent: 17,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 20,indent: 1,parent: 17,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 21,indent: 1,parent: 17,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Raise",amount: "2.75",potSizeToWin: "2.50",amountToPot: "110",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 22,indent: 0,parent: null,handNum: "6",wonOrLost: "-0.50",startAmt: "19.00",endAmt: "18.50",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 23,indent: 1,parent: 22,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 24,indent: 1,parent: 22,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 25,indent: 1,parent: 22,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 26,indent: 1,parent: 22,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 27,indent: 0,parent: null,handNum: "7",wonOrLost: "-0.50",startAmt: "18.50",endAmt: "18.00",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 28,indent: 1,parent: 27,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 29,indent: 1,parent: 27,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 30,indent: 1,parent: 27,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 31,indent: 1,parent: 27,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 32,indent: 0,parent: null,handNum: "8",wonOrLost: "-1.75",startAmt: "18.00",endAmt: "16.25",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 33,indent: 1,parent: 32,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "2.50",amountToPot: "70",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 34,indent: 1,parent: 32,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.75",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 35,indent: 0,parent: null,handNum: "9",wonOrLost: "-16.25",startAmt: "16.25",endAmt: "0.00",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 36,indent: 1,parent: 35,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 37,indent: 1,parent: 35,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "6.00",potSizeToWin: "10.00",amountToPot: "60",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "6.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 38,indent: 1,parent: 35,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "CallAllIn",amount: "9.75",potSizeToWin: "32.50",amountToPot: "30",numPlayers: "3",numAllIns: "2",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "Jim O",lastActionAmount: "11.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [K<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 39,indent: 0,parent: null,handNum: "12",wonOrLost: "-0.75",startAmt: "20.00",endAmt: "19.25",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 40,indent: 1,parent: 39,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "PostsMissingSmallBlind",amount: "0.25",potSizeToWin: "0.75",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 41,indent: 1,parent: 39,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 42,indent: 1,parent: 39,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 43,indent: 0,parent: null,handNum: "13",wonOrLost: "4.50",startAmt: "19.25",endAmt: "19.75",finalHand: "Two Pair, Q's & 9's (SP:2)",position: "BB (2 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 44,indent: 1,parent: 43,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 45,indent: 1,parent: 43,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 46,indent: 1,parent: 43,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "3.50",amountToPot: "42",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 47,indent: 1,parent: 43,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 48,indent: 1,parent: 43,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "2.00",potSizeToWin: "7.00",amountToPot: "28",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "2.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 49,indent: 0,parent: null,handNum: "14",wonOrLost: "-0.25",startAmt: "19.75",endAmt: "19.50",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 50,indent: 1,parent: 49,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 51,indent: 1,parent: 49,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.00",boardCards: "",
},
{
id: 52,indent: 0,parent: null,handNum: "15",wonOrLost: "-1.00",startAmt: "19.50",endAmt: "18.50",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 53,indent: 1,parent: 52,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 54,indent: 1,parent: 52,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 55,indent: 1,parent: 52,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 56,indent: 1,parent: 52,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 57,indent: 0,parent: null,handNum: "16",wonOrLost: "0.00",startAmt: "18.50",endAmt: "18.50",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 58,indent: 1,parent: 57,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 59,indent: 0,parent: null,handNum: "17",wonOrLost: "-0.50",startAmt: "18.50",endAmt: "18.00",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 60,indent: 1,parent: 59,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 61,indent: 1,parent: 59,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 62,indent: 1,parent: 59,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 63,indent: 1,parent: 59,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 64,indent: 0,parent: null,handNum: "18",wonOrLost: "-0.50",startAmt: "18.00",endAmt: "17.50",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 65,indent: 1,parent: 64,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 66,indent: 1,parent: 64,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 67,indent: 0,parent: null,handNum: "19",wonOrLost: "-0.50",startAmt: "17.50",endAmt: "17.00",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 68,indent: 1,parent: 67,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 69,indent: 1,parent: 67,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 70,indent: 1,parent: 67,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 71,indent: 0,parent: null,handNum: "20",wonOrLost: "0.00",startAmt: "17.00",endAmt: "17.00",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 72,indent: 1,parent: 71,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 73,indent: 0,parent: null,handNum: "21",wonOrLost: "5.00",startAmt: "17.00",endAmt: "20.50",finalHand: "Three of a Kind, Q's",position: "Cutoff (4 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 74,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 75,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 76,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.00",potSizeToWin: "3.00",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 77,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 78,indent: 0,parent: null,handNum: "22",wonOrLost: "0.00",startAmt: "20.50",endAmt: "20.50",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 79,indent: 1,parent: 78,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 80,indent: 0,parent: null,handNum: "23",wonOrLost: "0.50",startAmt: "20.50",endAmt: "20.75",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 81,indent: 1,parent: 80,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 82,indent: 0,parent: null,handNum: "24",wonOrLost: "-5.00",startAmt: "20.75",endAmt: "15.75",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 83,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 84,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 85,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 86,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "3.00",amountToPot: "16",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 87,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.00",potSizeToWin: "5.00",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "",
},
{
id: 88,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "6.00",amountToPot: "8",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 89,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "2.00",potSizeToWin: "9.00",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "",
},
{
id: 90,indent: 0,parent: null,handNum: "25",wonOrLost: "0.00",startAmt: "15.75",endAmt: "15.75",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 91,indent: 1,parent: 90,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 92,indent: 0,parent: null,handNum: "26",wonOrLost: "0.00",startAmt: "15.75",endAmt: "15.75",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 93,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 94,indent: 0,parent: null,handNum: "27",wonOrLost: "3.75",startAmt: "15.75",endAmt: "17.75",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 95,indent: 1,parent: 94,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 96,indent: 1,parent: 94,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.25",potSizeToWin: "2.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 97,indent: 1,parent: 94,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 98,indent: 1,parent: 94,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "3.75",amountToPot: "13",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 99,indent: 0,parent: null,handNum: "28",wonOrLost: "-0.50",startAmt: "17.75",endAmt: "17.25",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 100,indent: 1,parent: 99,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 101,indent: 1,parent: 99,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 102,indent: 1,parent: 99,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 103,indent: 1,parent: 99,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 104,indent: 0,parent: null,handNum: "29",wonOrLost: "5.00",startAmt: "17.25",endAmt: "20.25",finalHand: "Two Pair, A's & J's",position: "SB (1 of 5)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 105,indent: 1,parent: 104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 106,indent: 1,parent: 104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 107,indent: 1,parent: 104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 108,indent: 1,parent: 104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "3.50",amountToPot: "42",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 109,indent: 1,parent: 104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 110,indent: 1,parent: 104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 111,indent: 0,parent: null,handNum: "30",wonOrLost: "-0.50",startAmt: "20.25",endAmt: "19.75",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 112,indent: 1,parent: 111,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 113,indent: 1,parent: 111,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 114,indent: 1,parent: 111,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 115,indent: 0,parent: null,handNum: "31",wonOrLost: "0.00",startAmt: "19.75",endAmt: "19.75",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 116,indent: 1,parent: 115,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 117,indent: 0,parent: null,handNum: "32",wonOrLost: "0.00",startAmt: "19.75",endAmt: "19.75",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 118,indent: 1,parent: 117,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 119,indent: 0,parent: null,handNum: "33",wonOrLost: "-0.50",startAmt: "19.75",endAmt: "19.25",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 120,indent: 1,parent: 119,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 121,indent: 1,parent: 119,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 122,indent: 0,parent: null,handNum: "34",wonOrLost: "-0.25",startAmt: "19.25",endAmt: "19.00",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 123,indent: 1,parent: 122,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 124,indent: 1,parent: 122,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 125,indent: 0,parent: null,handNum: "35",wonOrLost: "23.49",startAmt: "19.00",endAmt: "32.37",finalHand: "Pair, 8's",position: "Dealer (5 of 5)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 126,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "5.75",amountToPot: "43",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.50",boardCards: "",
},
{
id: 127,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 128,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "4.12",potSizeToWin: "12.37",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.12",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 129,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.50",potSizeToWin: "19.99",amountToPot: "17",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 130,indent: 0,parent: null,handNum: "36",wonOrLost: "0.00",startAmt: "32.37",endAmt: "32.37",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 131,indent: 1,parent: 130,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 132,indent: 0,parent: null,handNum: "37",wonOrLost: "0.00",startAmt: "32.37",endAmt: "32.37",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 133,indent: 1,parent: 132,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 134,indent: 0,parent: null,handNum: "38",wonOrLost: "-2.50",startAmt: "32.37",endAmt: "29.87",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 135,indent: 1,parent: 134,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 136,indent: 1,parent: 134,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 137,indent: 1,parent: 134,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "4.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 138,indent: 1,parent: 134,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 139,indent: 1,parent: 134,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 140,indent: 0,parent: null,handNum: "39",wonOrLost: "-0.50",startAmt: "29.87",endAmt: "29.37",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 141,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 142,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 143,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 144,indent: 1,parent: 140,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "0.75",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 145,indent: 0,parent: null,handNum: "40",wonOrLost: "0.00",startAmt: "29.37",endAmt: "29.37",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 146,indent: 1,parent: 145,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 147,indent: 0,parent: null,handNum: "41",wonOrLost: "-0.50",startAmt: "29.37",endAmt: "28.87",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 148,indent: 1,parent: 147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 149,indent: 1,parent: 147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 150,indent: 0,parent: null,handNum: "42",wonOrLost: "0.00",startAmt: "28.87",endAmt: "28.87",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 151,indent: 1,parent: 150,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 152,indent: 0,parent: null,handNum: "43",wonOrLost: "-0.50",startAmt: "28.87",endAmt: "28.37",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 153,indent: 1,parent: 152,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 154,indent: 1,parent: 152,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 155,indent: 0,parent: null,handNum: "44",wonOrLost: "-1.50",startAmt: "28.37",endAmt: "26.87",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 156,indent: 1,parent: 155,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 157,indent: 1,parent: 155,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 158,indent: 1,parent: 155,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 159,indent: 1,parent: 155,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 160,indent: 1,parent: 155,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "3.00",amountToPot: "16",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 161,indent: 1,parent: 155,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 162,indent: 0,parent: null,handNum: "45",wonOrLost: "-1.50",startAmt: "26.87",endAmt: "25.37",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 163,indent: 1,parent: 162,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 164,indent: 1,parent: 162,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.50",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.25",boardCards: "",
},
{
id: 165,indent: 1,parent: 162,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 166,indent: 0,parent: null,handNum: "46",wonOrLost: "0.00",startAmt: "25.37",endAmt: "25.37",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 167,indent: 1,parent: 166,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 168,indent: 0,parent: null,handNum: "47",wonOrLost: "-0.50",startAmt: "25.37",endAmt: "24.87",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 169,indent: 1,parent: 168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 170,indent: 1,parent: 168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 171,indent: 1,parent: 168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.25",boardCards: "",
},
{
id: 172,indent: 0,parent: null,handNum: "48",wonOrLost: "-0.50",startAmt: "24.87",endAmt: "24.37",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 173,indent: 1,parent: 172,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 174,indent: 1,parent: 172,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 175,indent: 1,parent: 172,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 176,indent: 1,parent: 172,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.00",boardCards: "",
},
{
id: 177,indent: 0,parent: null,handNum: "49",wonOrLost: "-0.50",startAmt: "24.37",endAmt: "23.87",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 178,indent: 1,parent: 177,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 179,indent: 1,parent: 177,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 180,indent: 1,parent: 177,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 181,indent: 1,parent: 177,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 182,indent: 0,parent: null,handNum: "50",wonOrLost: "0.00",startAmt: "23.87",endAmt: "23.87",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 183,indent: 1,parent: 182,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 184,indent: 0,parent: null,handNum: "53",wonOrLost: "-0.50",startAmt: "23.87",endAmt: "23.37",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 185,indent: 1,parent: 184,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 186,indent: 1,parent: 184,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 187,indent: 1,parent: 184,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 188,indent: 1,parent: 184,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 189,indent: 0,parent: null,handNum: "54",wonOrLost: "-0.50",startAmt: "23.37",endAmt: "22.87",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 190,indent: 1,parent: 189,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 191,indent: 1,parent: 189,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 192,indent: 1,parent: 189,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 193,indent: 1,parent: 189,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "",
},
{
id: 194,indent: 0,parent: null,handNum: "55",wonOrLost: "28.00",startAmt: "22.87",endAmt: "38.12",finalHand: "Full House, A's over 8's",position: "Dealer (5 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 195,indent: 1,parent: 194,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 196,indent: 1,parent: 194,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.75",potSizeToWin: "3.50",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.75",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 197,indent: 1,parent: 194,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.50",potSizeToWin: "7.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 198,indent: 1,parent: 194,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "7.00",potSizeToWin: "14.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 199,indent: 0,parent: null,handNum: "56",wonOrLost: "3.00",startAmt: "38.12",endAmt: "40.12",finalHand: "Pair, A's",position: "Cutoff (4 of 5)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 200,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 201,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 202,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 203,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 204,indent: 0,parent: null,handNum: "57",wonOrLost: "0.00",startAmt: "40.12",endAmt: "40.12",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 205,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 206,indent: 0,parent: null,handNum: "58",wonOrLost: "-1.00",startAmt: "40.12",endAmt: "39.12",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 207,indent: 1,parent: 206,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 208,indent: 1,parent: 206,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 209,indent: 1,parent: 206,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 210,indent: 1,parent: 206,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 211,indent: 1,parent: 206,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 212,indent: 0,parent: null,handNum: "59",wonOrLost: "-1.00",startAmt: "39.12",endAmt: "38.12",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 213,indent: 1,parent: 212,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 214,indent: 1,parent: 212,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.75",potSizeToWin: "2.75",amountToPot: "27",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.00",boardCards: "",
},
{
id: 215,indent: 1,parent: 212,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 216,indent: 1,parent: 212,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "11.75",amountToPot: "0",numPlayers: "3",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "Jeff",lastActionAmount: "7.75",boardCards: "",
},
{
id: 217,indent: 0,parent: null,handNum: "60",wonOrLost: "0.00",startAmt: "38.12",endAmt: "38.12",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 218,indent: 1,parent: 217,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 219,indent: 0,parent: null,handNum: "61",wonOrLost: "0.00",startAmt: "38.12",endAmt: "38.12",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 220,indent: 1,parent: 219,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 221,indent: 0,parent: null,handNum: "62",wonOrLost: "0.00",startAmt: "38.12",endAmt: "38.12",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 222,indent: 1,parent: 221,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 223,indent: 0,parent: null,handNum: "63",wonOrLost: "-2.00",startAmt: "38.12",endAmt: "36.12",finalHand: "",position: "BB (2 of 5)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 224,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 225,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.75",amountToPot: "36",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 226,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "4.75",amountToPot: "10",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 227,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 228,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 229,indent: 0,parent: null,handNum: "64",wonOrLost: "2.00",startAmt: "36.12",endAmt: "37.12",finalHand: "Two Pair, 5's & 3's",position: "SB (1 of 5)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 230,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 231,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 232,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 233,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 234,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 235,indent: 0,parent: null,handNum: "65",wonOrLost: "10.50",startAmt: "37.12",endAmt: "42.62",finalHand: "Pair, Q's",position: "Dealer (5 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 236,indent: 1,parent: 235,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 237,indent: 1,parent: 235,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.50",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.25",boardCards: "",
},
{
id: 238,indent: 1,parent: 235,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.50",potSizeToWin: "7.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 239,indent: 1,parent: 235,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 240,indent: 1,parent: 235,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 241,indent: 0,parent: null,handNum: "66",wonOrLost: "0.00",startAmt: "42.62",endAmt: "42.62",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 242,indent: 1,parent: 241,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 243,indent: 0,parent: null,handNum: "67",wonOrLost: "0.00",startAmt: "42.62",endAmt: "42.62",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 244,indent: 1,parent: 243,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 245,indent: 0,parent: null,handNum: "68",wonOrLost: "22.75",startAmt: "42.62",endAmt: "54.12",finalHand: "Three of a Kind, 2's",position: "BB (2 of 5)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 246,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 247,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "2.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 248,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 249,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.75",potSizeToWin: "6.50",amountToPot: "42",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.75",boardCards: "",
},
{
id: 250,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 251,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "6.75",potSizeToWin: "16.00",amountToPot: "42",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "6.75",boardCards: "",
},
{
id: 252,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "22.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 253,indent: 0,parent: null,handNum: "69",wonOrLost: "-0.50",startAmt: "54.12",endAmt: "53.62",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 254,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 255,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 256,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 257,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 258,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "",
},
{
id: 259,indent: 0,parent: null,handNum: "70",wonOrLost: "0.00",startAmt: "53.62",endAmt: "53.62",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 260,indent: 1,parent: 259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "",
},
{
id: 261,indent: 0,parent: null,handNum: "71",wonOrLost: "-0.50",startAmt: "53.62",endAmt: "53.12",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 262,indent: 1,parent: 261,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 263,indent: 1,parent: 261,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 264,indent: 1,parent: 261,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Jeff",lastActionAmount: "4.00",boardCards: "",
},
{
id: 265,indent: 0,parent: null,handNum: "72",wonOrLost: "-0.50",startAmt: "53.12",endAmt: "52.62",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 266,indent: 1,parent: 265,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 267,indent: 1,parent: 265,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 268,indent: 0,parent: null,handNum: "73",wonOrLost: "-0.50",startAmt: "52.62",endAmt: "52.12",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 269,indent: 1,parent: 268,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 270,indent: 1,parent: 268,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 271,indent: 1,parent: 268,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 272,indent: 1,parent: 268,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 273,indent: 0,parent: null,handNum: "74",wonOrLost: "-0.25",startAmt: "52.12",endAmt: "51.87",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 274,indent: 1,parent: 273,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 275,indent: 1,parent: 273,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.61",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.43",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 276,indent: 0,parent: null,handNum: "75",wonOrLost: "-2.00",startAmt: "51.87",endAmt: "49.87",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 277,indent: 1,parent: 276,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 278,indent: 1,parent: 276,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 279,indent: 1,parent: 276,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "4.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 280,indent: 0,parent: null,handNum: "76",wonOrLost: "27.00",startAmt: "49.87",endAmt: "63.87",finalHand: "Two Pair, J's & 10's",position: "UTG1 (3 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 281,indent: 1,parent: 280,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 282,indent: 1,parent: 280,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 283,indent: 1,parent: 280,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 284,indent: 1,parent: 280,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.00",potSizeToWin: "6.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.50",boardCards: "",
},
{
id: 285,indent: 1,parent: 280,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 286,indent: 1,parent: 280,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "9.00",potSizeToWin: "18.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "9.00",boardCards: "",
},
{
id: 287,indent: 0,parent: null,handNum: "77",wonOrLost: "-4.25",startAmt: "63.87",endAmt: "59.62",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 288,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 289,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "",
},
{
id: 290,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 291,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.25",potSizeToWin: "6.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "2.25",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 292,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "15.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "6.75",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 293,indent: 0,parent: null,handNum: "78",wonOrLost: "4.00",startAmt: "59.62",endAmt: "61.62",finalHand: "Pair, 2's",position: "BB (2 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 294,indent: 1,parent: 293,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 295,indent: 1,parent: 293,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 296,indent: 1,parent: 293,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 297,indent: 1,parent: 293,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 298,indent: 1,parent: 293,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "0.50",potSizeToWin: "3.50",amountToPot: "14",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 299,indent: 0,parent: null,handNum: "79",wonOrLost: "-0.50",startAmt: "61.62",endAmt: "61.12",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 300,indent: 1,parent: 299,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 301,indent: 1,parent: 299,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 302,indent: 1,parent: 299,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 303,indent: 1,parent: 299,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "",
},
{
id: 304,indent: 0,parent: null,handNum: "80",wonOrLost: "-0.50",startAmt: "61.12",endAmt: "60.62",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 305,indent: 1,parent: 304,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 306,indent: 1,parent: 304,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 307,indent: 0,parent: null,handNum: "81",wonOrLost: "10.00",startAmt: "60.62",endAmt: "66.62",finalHand: "Flush, Ks High",position: "UTG1 (3 of 4)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 308,indent: 1,parent: 307,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 309,indent: 1,parent: 307,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "3.00",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 310,indent: 1,parent: 307,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.50",potSizeToWin: "7.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 311,indent: 1,parent: 307,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "10.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 312,indent: 0,parent: null,handNum: "82",wonOrLost: "3.00",startAmt: "66.62",endAmt: "66.87",finalHand: "Pair, 6's (SP:2)",position: "BB (2 of 4)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 313,indent: 1,parent: 312,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 314,indent: 1,parent: 312,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 315,indent: 1,parent: 312,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.75",potSizeToWin: "2.25",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.75",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 316,indent: 1,parent: 312,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.50",potSizeToWin: "4.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 317,indent: 1,parent: 312,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 318,indent: 0,parent: null,handNum: "83",wonOrLost: "-0.25",startAmt: "66.87",endAmt: "66.62",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 319,indent: 1,parent: 318,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 320,indent: 1,parent: 318,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "",
},
{
id: 321,indent: 0,parent: null,handNum: "84",wonOrLost: "0.00",startAmt: "66.62",endAmt: "66.62",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 322,indent: 1,parent: 321,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 323,indent: 0,parent: null,handNum: "85",wonOrLost: "0.00",startAmt: "66.62",endAmt: "66.62",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 324,indent: 1,parent: 323,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 325,indent: 0,parent: null,handNum: "86",wonOrLost: "-0.50",startAmt: "66.62",endAmt: "66.12",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 326,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 327,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 328,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 329,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 330,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 331,indent: 0,parent: null,handNum: "87",wonOrLost: "-1.75",startAmt: "66.12",endAmt: "64.37",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 332,indent: 1,parent: 331,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 333,indent: 1,parent: 331,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.00",amountToPot: "12",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 334,indent: 1,parent: 331,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "5.25",amountToPot: "23",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 335,indent: 1,parent: 331,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 336,indent: 1,parent: 331,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "",
},
{
id: 337,indent: 0,parent: null,handNum: "88",wonOrLost: "0.00",startAmt: "64.37",endAmt: "64.37",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 338,indent: 1,parent: 337,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 339,indent: 0,parent: null,handNum: "89",wonOrLost: "7.75",startAmt: "64.37",endAmt: "68.62",finalHand: "Two Pair, 10's & 4's",position: "Cutoff (5 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 340,indent: 1,parent: 339,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 341,indent: 1,parent: 339,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 342,indent: 1,parent: 339,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.00",potSizeToWin: "5.75",amountToPot: "34",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "2.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 343,indent: 1,parent: 339,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 344,indent: 0,parent: null,handNum: "90",wonOrLost: "0.00",startAmt: "68.62",endAmt: "68.62",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 345,indent: 1,parent: 344,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 346,indent: 0,parent: null,handNum: "91",wonOrLost: "0.00",startAmt: "68.62",endAmt: "68.62",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 347,indent: 1,parent: 346,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 348,indent: 0,parent: null,handNum: "92",wonOrLost: "-0.50",startAmt: "68.62",endAmt: "68.12",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 349,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 350,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 351,indent: 0,parent: null,handNum: "93",wonOrLost: "1.50",startAmt: "68.12",endAmt: "69.12",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 352,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 353,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 354,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 355,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 356,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 357,indent: 0,parent: null,handNum: "94",wonOrLost: "0.00",startAmt: "69.12",endAmt: "69.12",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 358,indent: 1,parent: 357,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.00",boardCards: "",
},
{
id: 359,indent: 0,parent: null,handNum: "95",wonOrLost: "-1.00",startAmt: "69.12",endAmt: "68.12",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 360,indent: 1,parent: 359,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 361,indent: 1,parent: 359,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 362,indent: 1,parent: 359,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 363,indent: 0,parent: null,handNum: "96",wonOrLost: "2.50",startAmt: "68.12",endAmt: "70.12",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 364,indent: 1,parent: 363,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 365,indent: 1,parent: 363,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 366,indent: 0,parent: null,handNum: "97",wonOrLost: "0.00",startAmt: "70.12",endAmt: "70.12",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 367,indent: 1,parent: 366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 368,indent: 0,parent: null,handNum: "98",wonOrLost: "-0.50",startAmt: "70.12",endAmt: "69.62",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 369,indent: 1,parent: 368,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 370,indent: 1,parent: 368,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 371,indent: 0,parent: null,handNum: "99",wonOrLost: "1.00",startAmt: "69.62",endAmt: "70.12",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 372,indent: 1,parent: 371,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 373,indent: 1,parent: 371,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 374,indent: 1,parent: 371,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 375,indent: 0,parent: null,handNum: "100",wonOrLost: "0.00",startAmt: "70.12",endAmt: "70.12",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 376,indent: 1,parent: 375,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 377,indent: 0,parent: null,handNum: "101",wonOrLost: "0.00",startAmt: "70.12",endAmt: "70.12",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 378,indent: 1,parent: 377,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 379,indent: 0,parent: null,handNum: "102",wonOrLost: "0.00",startAmt: "70.12",endAmt: "70.12",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 380,indent: 1,parent: 379,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 381,indent: 0,parent: null,handNum: "103",wonOrLost: "-1.50",startAmt: "70.12",endAmt: "68.62",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 382,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 383,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.50",amountToPot: "40",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "",
},
{
id: 384,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 385,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 386,indent: 1,parent: 381,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.50",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 387,indent: 0,parent: null,handNum: "104",wonOrLost: "-1.75",startAmt: "68.62",endAmt: "66.87",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 388,indent: 1,parent: 387,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 389,indent: 1,parent: 387,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "4.00",amountToPot: "31",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 390,indent: 1,parent: 387,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.87",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.62",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 391,indent: 0,parent: null,handNum: "105",wonOrLost: "-0.25",startAmt: "66.87",endAmt: "66.62",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 392,indent: 1,parent: 391,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 393,indent: 1,parent: 391,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.50",boardCards: "",
},
{
id: 394,indent: 0,parent: null,handNum: "106",wonOrLost: "-2.00",startAmt: "66.62",endAmt: "64.62",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 395,indent: 1,parent: 394,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 396,indent: 1,parent: 394,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 397,indent: 1,parent: 394,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 398,indent: 1,parent: 394,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "4.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 399,indent: 0,parent: null,handNum: "107",wonOrLost: "-0.50",startAmt: "64.62",endAmt: "64.12",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 400,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 401,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.37",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.87",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, [5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 402,indent: 0,parent: null,handNum: "108",wonOrLost: "0.00",startAmt: "64.12",endAmt: "64.12",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 403,indent: 1,parent: 402,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 404,indent: 0,parent: null,handNum: "109",wonOrLost: "-0.50",startAmt: "64.12",endAmt: "63.62",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 405,indent: 1,parent: 404,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 406,indent: 1,parent: 404,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 407,indent: 0,parent: null,handNum: "110",wonOrLost: "0.00",startAmt: "63.62",endAmt: "63.62",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 408,indent: 1,parent: 407,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 409,indent: 0,parent: null,handNum: "111",wonOrLost: "5.00",startAmt: "63.62",endAmt: "64.62",finalHand: "Pair, Q's (SP:2)",position: "BB (2 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 410,indent: 1,parent: 409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 411,indent: 1,parent: 409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 412,indent: 1,parent: 409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 413,indent: 1,parent: 409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 414,indent: 1,parent: 409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.00",potSizeToWin: "7.00",amountToPot: "42",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "",
},
{
id: 415,indent: 1,parent: 409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "10.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 416,indent: 0,parent: null,handNum: "112",wonOrLost: "-1.00",startAmt: "64.62",endAmt: "63.62",finalHand: "",position: "SB (1 of 6)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 417,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 418,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 419,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 420,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 421,indent: 1,parent: 416,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 422,indent: 0,parent: null,handNum: "113",wonOrLost: "0.00",startAmt: "63.62",endAmt: "63.62",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 423,indent: 1,parent: 422,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 424,indent: 0,parent: null,handNum: "114",wonOrLost: "0.00",startAmt: "63.62",endAmt: "63.62",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 425,indent: 1,parent: 424,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 426,indent: 0,parent: null,handNum: "115",wonOrLost: "-0.50",startAmt: "63.62",endAmt: "63.12",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 427,indent: 1,parent: 426,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 428,indent: 1,parent: 426,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 429,indent: 0,parent: null,handNum: "116",wonOrLost: "0.00",startAmt: "63.12",endAmt: "63.12",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 430,indent: 1,parent: 429,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 431,indent: 0,parent: null,handNum: "117",wonOrLost: "22.00",startAmt: "63.12",endAmt: "76.12",finalHand: "Flush, Ad High",position: "BB (2 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 432,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 433,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 434,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 435,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.00",potSizeToWin: "5.00",amountToPot: "60",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.00",boardCards: "",
},
{
id: 436,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "11.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 437,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "5.50",potSizeToWin: "11.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 438,indent: 0,parent: null,handNum: "118",wonOrLost: "14.00",startAmt: "76.12",endAmt: "83.62",finalHand: "Straight, K High",position: "SB (1 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 439,indent: 1,parent: 438,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 440,indent: 1,parent: 438,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 441,indent: 1,parent: 438,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 442,indent: 1,parent: 438,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "4.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "",
},
{
id: 443,indent: 1,parent: 438,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "6.00",amountToPot: "8",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 444,indent: 1,parent: 438,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 445,indent: 1,parent: 438,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.50",potSizeToWin: "10.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.50",boardCards: "",
},
{
id: 446,indent: 0,parent: null,handNum: "119",wonOrLost: "0.00",startAmt: "83.62",endAmt: "83.62",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 447,indent: 1,parent: 446,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 448,indent: 0,parent: null,handNum: "120",wonOrLost: "0.00",startAmt: "83.62",endAmt: "83.62",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 449,indent: 1,parent: 448,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 450,indent: 0,parent: null,handNum: "121",wonOrLost: "0.00",startAmt: "83.62",endAmt: "83.62",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 451,indent: 1,parent: 450,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 452,indent: 0,parent: null,handNum: "122",wonOrLost: "22.91",startAmt: "83.62",endAmt: "84.78",finalHand: "Straight, 8 High (SP:3)",position: "UTG1 (3 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 453,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 454,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.25",potSizeToWin: "3.75",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 455,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.25",potSizeToWin: "11.25",amountToPot: "11",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "",
},
{
id: 456,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "6.25",potSizeToWin: "18.75",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "6.25",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 457,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "12.50",potSizeToWin: "50.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Chris Moy",lastActionAmount: "12.50",boardCards: "",
},
{
id: 458,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "66.50",amountToPot: "0",numPlayers: "3",numAllIns: "1",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 459,indent: 0,parent: null,handNum: "123",wonOrLost: "-0.50",startAmt: "84.78",endAmt: "84.28",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 460,indent: 1,parent: 459,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 461,indent: 1,parent: 459,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 462,indent: 1,parent: 459,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 463,indent: 1,parent: 459,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 464,indent: 0,parent: null,handNum: "124",wonOrLost: "-0.50",startAmt: "84.28",endAmt: "83.78",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 465,indent: 1,parent: 464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 466,indent: 1,parent: 464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 467,indent: 1,parent: 464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 468,indent: 1,parent: 464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 469,indent: 0,parent: null,handNum: "125",wonOrLost: "-0.50",startAmt: "83.78",endAmt: "83.28",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 470,indent: 1,parent: 469,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 471,indent: 1,parent: 469,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "12.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Greg",lastActionAmount: "7.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 472,indent: 0,parent: null,handNum: "126",wonOrLost: "0.00",startAmt: "83.28",endAmt: "83.28",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 473,indent: 1,parent: 472,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 474,indent: 0,parent: null,handNum: "127",wonOrLost: "-2.00",startAmt: "83.28",endAmt: "81.28",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 475,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 476,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 477,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "4.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 478,indent: 0,parent: null,handNum: "128",wonOrLost: "0.00",startAmt: "81.28",endAmt: "81.28",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 479,indent: 1,parent: 478,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 480,indent: 0,parent: null,handNum: "129",wonOrLost: "-0.50",startAmt: "81.28",endAmt: "80.78",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 481,indent: 1,parent: 480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 482,indent: 1,parent: 480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 483,indent: 1,parent: 480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "",
},
{
id: 484,indent: 0,parent: null,handNum: "130",wonOrLost: "-1.50",startAmt: "80.78",endAmt: "79.28",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 485,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 486,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "5.00",amountToPot: "20",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "",
},
{
id: 487,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 488,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.00",boardCards: "",
},
{
id: 489,indent: 0,parent: null,handNum: "131",wonOrLost: "3.00",startAmt: "79.28",endAmt: "80.78",finalHand: "Two Pair, A's & 9's",position: "SB (1 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 490,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 491,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 492,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 493,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 494,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 495,indent: 0,parent: null,handNum: "132",wonOrLost: "20.00",startAmt: "80.78",endAmt: "92.78",finalHand: "Full House, 7's over Q's",position: "Dealer (6 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 496,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 497,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "5.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 498,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.50",potSizeToWin: "12.50",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 499,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "2.50",potSizeToWin: "17.50",amountToPot: "14",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 500,indent: 0,parent: null,handNum: "133",wonOrLost: "-8.50",startAmt: "92.78",endAmt: "84.28",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 501,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 502,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.00",potSizeToWin: "5.50",amountToPot: "54",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 503,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.50",potSizeToWin: "11.00",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 504,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "2.50",potSizeToWin: "16.00",amountToPot: "15",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 505,indent: 0,parent: null,handNum: "134",wonOrLost: "0.00",startAmt: "84.28",endAmt: "84.28",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 506,indent: 1,parent: 505,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 507,indent: 0,parent: null,handNum: "135",wonOrLost: "-0.50",startAmt: "84.28",endAmt: "83.78",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 508,indent: 1,parent: 507,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 509,indent: 1,parent: 507,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 510,indent: 1,parent: 507,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 511,indent: 1,parent: 507,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 512,indent: 0,parent: null,handNum: "136",wonOrLost: "-1.50",startAmt: "83.78",endAmt: "82.28",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 513,indent: 1,parent: 512,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 514,indent: 1,parent: 512,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "5.25",amountToPot: "19",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "",
},
{
id: 515,indent: 1,parent: 512,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 516,indent: 1,parent: 512,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "21.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "10.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 517,indent: 0,parent: null,handNum: "137",wonOrLost: "-0.25",startAmt: "82.28",endAmt: "82.03",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 518,indent: 1,parent: 517,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 519,indent: 1,parent: 517,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 520,indent: 0,parent: null,handNum: "138",wonOrLost: "0.00",startAmt: "82.03",endAmt: "82.03",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 521,indent: 1,parent: 520,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 522,indent: 0,parent: null,handNum: "139",wonOrLost: "0.00",startAmt: "82.03",endAmt: "82.03",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 523,indent: 1,parent: 522,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 524,indent: 0,parent: null,handNum: "140",wonOrLost: "0.00",startAmt: "82.03",endAmt: "82.03",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 525,indent: 1,parent: 524,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 526,indent: 0,parent: null,handNum: "141",wonOrLost: "3.00",startAmt: "82.03",endAmt: "84.03",finalHand: "Pair, 6's",position: "UTG1 (3 of 6)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 527,indent: 1,parent: 526,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 528,indent: 1,parent: 526,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 529,indent: 1,parent: 526,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 530,indent: 1,parent: 526,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 531,indent: 0,parent: null,handNum: "142",wonOrLost: "1.25",startAmt: "84.03",endAmt: "84.78",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 532,indent: 1,parent: 531,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 533,indent: 1,parent: 531,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 534,indent: 1,parent: 531,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 535,indent: 1,parent: 531,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 536,indent: 0,parent: null,handNum: "143",wonOrLost: "-0.25",startAmt: "84.78",endAmt: "84.53",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 537,indent: 1,parent: 536,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 538,indent: 1,parent: 536,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 539,indent: 0,parent: null,handNum: "144",wonOrLost: "-6.75",startAmt: "84.53",endAmt: "77.78",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 540,indent: 1,parent: 539,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 541,indent: 1,parent: 539,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "5.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 542,indent: 1,parent: 539,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.75",potSizeToWin: "11.25",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.75",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 543,indent: 1,parent: 539,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "20.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 544,indent: 0,parent: null,handNum: "145",wonOrLost: "-9.00",startAmt: "77.78",endAmt: "68.78",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 545,indent: 1,parent: 544,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "2.50",amountToPot: "70",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 546,indent: 1,parent: 544,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 547,indent: 1,parent: 544,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "4.25",potSizeToWin: "8.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "4.25",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 548,indent: 1,parent: 544,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "3.00",potSizeToWin: "12.75",amountToPot: "23",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 549,indent: 0,parent: null,handNum: "146",wonOrLost: "-0.50",startAmt: "68.78",endAmt: "68.28",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 550,indent: 1,parent: 549,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 551,indent: 1,parent: 549,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 552,indent: 1,parent: 549,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.25",boardCards: "",
},
{
id: 553,indent: 0,parent: null,handNum: "147",wonOrLost: "-2.75",startAmt: "68.28",endAmt: "65.53",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 554,indent: 1,parent: 553,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 555,indent: 1,parent: 553,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 556,indent: 1,parent: 553,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.75",potSizeToWin: "3.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.75",boardCards: "",
},
{
id: 557,indent: 1,parent: 553,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 558,indent: 1,parent: 553,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "5.25",amountToPot: "9",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 559,indent: 0,parent: null,handNum: "148",wonOrLost: "-0.50",startAmt: "65.53",endAmt: "65.03",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 560,indent: 1,parent: 559,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 561,indent: 1,parent: 559,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 562,indent: 1,parent: 559,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 563,indent: 1,parent: 559,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 564,indent: 0,parent: null,handNum: "149",wonOrLost: "-0.25",startAmt: "65.03",endAmt: "64.78",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 565,indent: 1,parent: 564,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 566,indent: 1,parent: 564,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.75",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 567,indent: 0,parent: null,handNum: "151",wonOrLost: "-3.25",startAmt: "64.78",endAmt: "61.53",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 568,indent: 1,parent: 567,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 569,indent: 1,parent: 567,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.75",potSizeToWin: "5.50",amountToPot: "50",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.75",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 570,indent: 1,parent: 567,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "16.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "5.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 571,indent: 0,parent: null,handNum: "152",wonOrLost: "7.50",startAmt: "61.53",endAmt: "66.28",finalHand: "Pair, Q's",position: "MP1 (4 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 572,indent: 1,parent: 571,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "2.50",amountToPot: "70",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 573,indent: 1,parent: 571,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "5.50",amountToPot: "9",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 574,indent: 1,parent: 571,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "6.50",amountToPot: "7",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 575,indent: 1,parent: 571,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 576,indent: 0,parent: null,handNum: "153",wonOrLost: "-0.50",startAmt: "66.28",endAmt: "65.78",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 577,indent: 1,parent: 576,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 578,indent: 1,parent: 576,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 579,indent: 1,parent: 576,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.61",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.68",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 580,indent: 0,parent: null,handNum: "154",wonOrLost: "2.00",startAmt: "65.78",endAmt: "66.78",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 581,indent: 1,parent: 580,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 582,indent: 1,parent: 580,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 583,indent: 1,parent: 580,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 584,indent: 1,parent: 580,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 585,indent: 1,parent: 580,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "2.00",potSizeToWin: "2.00",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 586,indent: 0,parent: null,handNum: "155",wonOrLost: "-6.50",startAmt: "66.78",endAmt: "60.28",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 587,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 588,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 589,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 590,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.75",potSizeToWin: "1.75",amountToPot: "42",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "0.75",boardCards: "",
},
{
id: 591,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 592,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.50",potSizeToWin: "4.00",amountToPot: "37",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "",
},
{
id: 593,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 594,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.75",potSizeToWin: "9.25",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "3.75",boardCards: "",
},
{
id: 595,indent: 0,parent: null,handNum: "156",wonOrLost: "0.00",startAmt: "60.28",endAmt: "60.28",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 596,indent: 1,parent: 595,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 597,indent: 0,parent: null,handNum: "157",wonOrLost: "-1.75",startAmt: "60.28",endAmt: "58.53",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 598,indent: 1,parent: 597,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 599,indent: 1,parent: 597,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 600,indent: 1,parent: 597,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.25",potSizeToWin: "4.50",amountToPot: "27",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.25",boardCards: "",
},
{
id: 601,indent: 1,parent: 597,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 602,indent: 1,parent: 597,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 603,indent: 0,parent: null,handNum: "158",wonOrLost: "-0.50",startAmt: "58.53",endAmt: "58.03",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 604,indent: 1,parent: 603,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 605,indent: 1,parent: 603,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 606,indent: 1,parent: 603,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 607,indent: 1,parent: 603,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 608,indent: 0,parent: null,handNum: "159",wonOrLost: "-4.50",startAmt: "58.03",endAmt: "53.53",finalHand: "",position: "BB (2 of 5)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 609,indent: 1,parent: 608,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 610,indent: 1,parent: 608,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 611,indent: 1,parent: 608,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 612,indent: 1,parent: 608,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 613,indent: 1,parent: 608,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.00",potSizeToWin: "6.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 614,indent: 0,parent: null,handNum: "160",wonOrLost: "-5.00",startAmt: "53.53",endAmt: "48.53",finalHand: "",position: "SB (1 of 5)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 615,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 616,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 617,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 618,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "5.50",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 619,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "6.50",amountToPot: "7",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 620,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.00",potSizeToWin: "10.00",amountToPot: "10",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 621,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "11.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 622,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "1.50",potSizeToWin: "12.50",amountToPot: "12",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 623,indent: 0,parent: null,handNum: "161",wonOrLost: "0.00",startAmt: "48.53",endAmt: "48.53",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 624,indent: 1,parent: 623,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.25",boardCards: "",
},
{
id: 625,indent: 0,parent: null,handNum: "162",wonOrLost: "0.00",startAmt: "48.53",endAmt: "48.53",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 626,indent: 1,parent: 625,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 627,indent: 0,parent: null,handNum: "163",wonOrLost: "-2.50",startAmt: "48.53",endAmt: "46.03",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 628,indent: 1,parent: 627,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 629,indent: 1,parent: 627,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 630,indent: 1,parent: 627,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "6.50",amountToPot: "23",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "",
},
{
id: 631,indent: 1,parent: 627,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "87.37",amountToPot: "0",numPlayers: "3",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "Jim O",lastActionAmount: "79.37",boardCards: "7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 632,indent: 0,parent: null,handNum: "164",wonOrLost: "-0.50",startAmt: "46.03",endAmt: "45.53",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 633,indent: 1,parent: 632,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 634,indent: 1,parent: 632,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.65",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.36",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 635,indent: 0,parent: null,handNum: "165",wonOrLost: "-2.00",startAmt: "45.53",endAmt: "43.53",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 636,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 637,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "3.50",amountToPot: "35",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "",
},
{
id: 638,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 639,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "6.75",amountToPot: "7",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 640,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "13.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jim O",lastActionAmount: "4.00",boardCards: "",
},
{
id: 641,indent: 0,parent: null,handNum: "166",wonOrLost: "15.00",startAmt: "43.53",endAmt: "51.78",finalHand: "Two Pair, Q's & 9's",position: "Dealer (6 of 6)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 642,indent: 1,parent: 641,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 643,indent: 1,parent: 641,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "5.00",amountToPot: "50",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 644,indent: 1,parent: 641,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.75",potSizeToWin: "11.25",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.75",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 645,indent: 1,parent: 641,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "15.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 646,indent: 0,parent: null,handNum: "167",wonOrLost: "31.05",startAmt: "51.78",endAmt: "67.43",finalHand: "Three of a Kind, A's",position: "Cutoff (5 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 647,indent: 1,parent: 646,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.43",potSizeToWin: "0.75",amountToPot: "190",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 648,indent: 1,parent: 646,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.11",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 649,indent: 1,parent: 646,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.55",potSizeToWin: "4.66",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.55",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 650,indent: 1,parent: 646,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "6.21",potSizeToWin: "6.21",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 651,indent: 1,parent: 646,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "6.21",potSizeToWin: "24.84",amountToPot: "25",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Chris Moy",lastActionAmount: "12.42",boardCards: "",
},
{
id: 652,indent: 0,parent: null,handNum: "168",wonOrLost: "-2.50",startAmt: "67.43",endAmt: "64.93",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 653,indent: 1,parent: 652,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 654,indent: 1,parent: 652,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "6.25",amountToPot: "32",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.50",boardCards: "",
},
{
id: 655,indent: 1,parent: 652,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 656,indent: 1,parent: 652,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "5.00",boardCards: "",
},
{
id: 657,indent: 0,parent: null,handNum: "169",wonOrLost: "-2.00",startAmt: "64.93",endAmt: "62.93",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 658,indent: 1,parent: 657,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 659,indent: 1,parent: 657,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "",
},
{
id: 660,indent: 1,parent: 657,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "6.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 661,indent: 0,parent: null,handNum: "170",wonOrLost: "7.49",startAmt: "62.93",endAmt: "67.55",finalHand: "Full House, 2's over 3's",position: "BB (2 of 6)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 662,indent: 1,parent: 661,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 663,indent: 1,parent: 661,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 664,indent: 1,parent: 661,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 665,indent: 1,parent: 661,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "2.75",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 666,indent: 1,parent: 661,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 667,indent: 1,parent: 661,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.87",potSizeToWin: "5.62",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.87",boardCards: "",
},
{
id: 668,indent: 1,parent: 661,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.49",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 669,indent: 0,parent: null,handNum: "171",wonOrLost: "-0.25",startAmt: "67.55",endAmt: "67.30",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 670,indent: 1,parent: 669,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 671,indent: 1,parent: 669,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 672,indent: 0,parent: null,handNum: "172",wonOrLost: "-0.50",startAmt: "67.30",endAmt: "66.80",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 673,indent: 1,parent: 672,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 674,indent: 1,parent: 672,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.25",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 675,indent: 0,parent: null,handNum: "173",wonOrLost: "-4.00",startAmt: "66.80",endAmt: "62.80",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 676,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 677,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "",
},
{
id: 678,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 679,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.50",potSizeToWin: "10.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 680,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "17.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 681,indent: 0,parent: null,handNum: "174",wonOrLost: "-0.50",startAmt: "62.80",endAmt: "62.30",finalHand: "",position: "MP1 (4 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 682,indent: 1,parent: 681,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 683,indent: 1,parent: 681,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 684,indent: 0,parent: null,handNum: "175",wonOrLost: "-5.50",startAmt: "62.30",endAmt: "56.80",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 685,indent: 1,parent: 684,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 686,indent: 1,parent: 684,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 687,indent: 1,parent: 684,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 688,indent: 1,parent: 684,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.50",potSizeToWin: "5.00",amountToPot: "10",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 689,indent: 1,parent: 684,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.50",potSizeToWin: "5.50",amountToPot: "27",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 690,indent: 1,parent: 684,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "2.50",potSizeToWin: "12.50",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Jim O",lastActionAmount: "4.00",boardCards: "",
},
{
id: 691,indent: 0,parent: null,handNum: "176",wonOrLost: "-1.00",startAmt: "56.80",endAmt: "55.80",finalHand: "",position: "BB (2 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 692,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 693,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 694,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 695,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 696,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 697,indent: 0,parent: null,handNum: "177",wonOrLost: "1.00",startAmt: "55.80",endAmt: "56.30",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 698,indent: 1,parent: 697,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 699,indent: 1,parent: 697,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 700,indent: 1,parent: 697,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 701,indent: 1,parent: 697,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 702,indent: 0,parent: null,handNum: "178",wonOrLost: "27.00",startAmt: "56.30",endAmt: "60.80",finalHand: "Straight, 9 High (SP:2)",position: "Dealer (6 of 6)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 703,indent: 1,parent: 702,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 704,indent: 1,parent: 702,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "6.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 705,indent: 1,parent: 702,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "5.00",potSizeToWin: "15.00",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "5.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 706,indent: 1,parent: 702,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "14.50",potSizeToWin: "39.50",amountToPot: "36",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "14.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 707,indent: 0,parent: null,handNum: "179",wonOrLost: "-0.50",startAmt: "60.80",endAmt: "60.30",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 708,indent: 1,parent: 707,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 709,indent: 1,parent: 707,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 710,indent: 0,parent: null,handNum: "180",wonOrLost: "0.00",startAmt: "60.30",endAmt: "60.30",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 711,indent: 1,parent: 710,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 712,indent: 0,parent: null,handNum: "181",wonOrLost: "0.00",startAmt: "60.30",endAmt: "60.30",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 713,indent: 1,parent: 712,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 714,indent: 0,parent: null,handNum: "182",wonOrLost: "-1.50",startAmt: "60.30",endAmt: "58.80",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 715,indent: 1,parent: 714,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 716,indent: 1,parent: 714,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 717,indent: 1,parent: 714,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 718,indent: 1,parent: 714,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "2.75",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.00",boardCards: "",
},
{
id: 719,indent: 1,parent: 714,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 720,indent: 1,parent: 714,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.87",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.62",boardCards: "",
},
{
id: 721,indent: 0,parent: null,handNum: "183",wonOrLost: "1.50",startAmt: "58.80",endAmt: "59.80",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 722,indent: 1,parent: 721,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 723,indent: 1,parent: 721,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 724,indent: 1,parent: 721,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.75",potSizeToWin: "1.50",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 725,indent: 0,parent: null,handNum: "184",wonOrLost: "-1.75",startAmt: "59.80",endAmt: "58.05",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 726,indent: 1,parent: 725,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 727,indent: 1,parent: 725,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 728,indent: 1,parent: 725,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.25",potSizeToWin: "3.75",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 729,indent: 1,parent: 725,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 730,indent: 0,parent: null,handNum: "185",wonOrLost: "0.00",startAmt: "58.05",endAmt: "58.05",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 731,indent: 1,parent: 730,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 732,indent: 0,parent: null,handNum: "186",wonOrLost: "-0.50",startAmt: "58.05",endAmt: "57.55",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 733,indent: 1,parent: 732,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 734,indent: 1,parent: 732,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "8.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 735,indent: 0,parent: null,handNum: "187",wonOrLost: "-1.25",startAmt: "57.55",endAmt: "56.30",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 736,indent: 1,parent: 735,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 737,indent: 1,parent: 735,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.75",potSizeToWin: "2.50",amountToPot: "30",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "0.75",boardCards: "",
},
{
id: 738,indent: 1,parent: 735,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "4.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 739,indent: 0,parent: null,handNum: "188",wonOrLost: "9.00",startAmt: "56.30",endAmt: "60.80",finalHand: "Two Pair, 9's & 6's",position: "BB (2 of 6)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 740,indent: 1,parent: 739,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 741,indent: 1,parent: 739,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 742,indent: 1,parent: 739,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 743,indent: 1,parent: 739,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 744,indent: 1,parent: 739,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.00",potSizeToWin: "6.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 745,indent: 0,parent: null,handNum: "189",wonOrLost: "-14.25",startAmt: "60.80",endAmt: "46.55",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 746,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 747,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 748,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 749,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "5.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 750,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 751,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.75",potSizeToWin: "11.25",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.75",boardCards: "",
},
{
id: 752,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "15.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 753,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "7.50",potSizeToWin: "22.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "7.50",boardCards: "",
},
{
id: 754,indent: 0,parent: null,handNum: "190",wonOrLost: "-2.25",startAmt: "46.55",endAmt: "44.30",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 755,indent: 1,parent: 754,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.25",potSizeToWin: "3.50",amountToPot: "64",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.25",boardCards: "",
},
{
id: 756,indent: 1,parent: 754,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "15.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.75",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 757,indent: 0,parent: null,handNum: "191",wonOrLost: "-2.50",startAmt: "44.30",endAmt: "41.80",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 758,indent: 1,parent: 757,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 759,indent: 1,parent: 757,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "6.25",amountToPot: "32",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.50",boardCards: "",
},
{
id: 760,indent: 1,parent: 757,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 761,indent: 1,parent: 757,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "5.00",boardCards: "",
},
{
id: 762,indent: 0,parent: null,handNum: "192",wonOrLost: "-2.00",startAmt: "41.80",endAmt: "39.80",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 763,indent: 1,parent: 762,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 764,indent: 1,parent: 762,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "3.75",amountToPot: "13",numPlayers: "5",numAllIns: "1",positionToLastAction: "3",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 765,indent: 1,parent: 762,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.00",potSizeToWin: "5.75",amountToPot: "17",numPlayers: "4",numAllIns: "1",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 766,indent: 1,parent: 762,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "14.50",amountToPot: "0",numPlayers: "4",numAllIns: "1",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "7.25",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 767,indent: 0,parent: null,handNum: "193",wonOrLost: "-1.00",startAmt: "39.80",endAmt: "38.80",finalHand: "",position: "BB (2 of 5)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 768,indent: 1,parent: 767,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.50",amountToPot: "100",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 769,indent: 1,parent: 767,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 770,indent: 1,parent: 767,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 771,indent: 1,parent: 767,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 772,indent: 0,parent: null,handNum: "194",wonOrLost: "15.75",startAmt: "38.80",endAmt: "46.80",finalHand: "Three of a Kind, 10's",position: "BB (2 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 773,indent: 1,parent: 772,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 774,indent: 1,parent: 772,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "3.25",amountToPot: "61",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 775,indent: 1,parent: 772,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 776,indent: 1,parent: 772,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "5.25",potSizeToWin: "10.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.25",boardCards: "",
},
{
id: 777,indent: 1,parent: 772,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "15.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 778,indent: 1,parent: 772,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "15.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 779,indent: 0,parent: null,handNum: "195",wonOrLost: "-0.50",startAmt: "46.80",endAmt: "46.30",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 780,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 781,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 782,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 783,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 784,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 785,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 786,indent: 0,parent: null,handNum: "196",wonOrLost: "-0.50",startAmt: "46.30",endAmt: "45.80",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 787,indent: 1,parent: 786,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 788,indent: 1,parent: 786,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, [5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 789,indent: 0,parent: null,handNum: "197",wonOrLost: "0.00",startAmt: "45.80",endAmt: "45.80",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 790,indent: 1,parent: 789,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 791,indent: 0,parent: null,handNum: "198",wonOrLost: "0.00",startAmt: "45.80",endAmt: "45.80",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 792,indent: 1,parent: 791,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 793,indent: 0,parent: null,handNum: "199",wonOrLost: "-0.50",startAmt: "45.80",endAmt: "45.30",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 794,indent: 1,parent: 793,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 795,indent: 1,parent: 793,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 796,indent: 1,parent: 793,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 797,indent: 1,parent: 793,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "",
},
{
id: 798,indent: 0,parent: null,handNum: "200",wonOrLost: "5.50",startAmt: "45.30",endAmt: "45.55",finalHand: "A High (SP:2)",position: "SB (1 of 5)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 799,indent: 1,parent: 798,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 800,indent: 1,parent: 798,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.25",potSizeToWin: "3.25",amountToPot: "69",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.50",boardCards: "",
},
{
id: 801,indent: 1,parent: 798,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 802,indent: 1,parent: 798,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.75",potSizeToWin: "8.25",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "2.75",boardCards: "",
},
{
id: 803,indent: 1,parent: 798,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "11.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 804,indent: 1,parent: 798,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "11.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 805,indent: 0,parent: null,handNum: "201",wonOrLost: "0.00",startAmt: "45.55",endAmt: "45.55",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 806,indent: 1,parent: 805,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 807,indent: 0,parent: null,handNum: "202",wonOrLost: "9.93",startAmt: "45.55",endAmt: "50.64",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 808,indent: 1,parent: 807,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.12",potSizeToWin: "0.75",amountToPot: "149",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 809,indent: 1,parent: 807,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.24",potSizeToWin: "2.49",amountToPot: "49",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 810,indent: 1,parent: 807,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.48",potSizeToWin: "7.45",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.48",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 811,indent: 1,parent: 807,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "4.96",potSizeToWin: "9.93",amountToPot: "49",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 812,indent: 0,parent: null,handNum: "203",wonOrLost: "-0.50",startAmt: "50.64",endAmt: "50.14",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 813,indent: 1,parent: 812,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 814,indent: 1,parent: 812,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "",
},
{
id: 815,indent: 0,parent: null,handNum: "204",wonOrLost: "-0.50",startAmt: "50.14",endAmt: "49.64",finalHand: "",position: "BB (2 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 816,indent: 1,parent: 815,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 817,indent: 1,parent: 815,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 818,indent: 1,parent: 815,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 819,indent: 1,parent: 815,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "",
},
{
id: 820,indent: 0,parent: null,handNum: "205",wonOrLost: "-0.25",startAmt: "49.64",endAmt: "49.39",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 821,indent: 1,parent: 820,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 822,indent: 1,parent: 820,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.61",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.43",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 823,indent: 0,parent: null,handNum: "206",wonOrLost: "-7.87",startAmt: "49.39",endAmt: "41.52",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 824,indent: 1,parent: 823,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "3.25",amountToPot: "76",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 825,indent: 1,parent: 823,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 826,indent: 1,parent: 823,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.87",potSizeToWin: "8.62",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.87",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 827,indent: 1,parent: 823,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "2.50",potSizeToWin: "13.99",amountToPot: "17",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 828,indent: 0,parent: null,handNum: "207",wonOrLost: "34.50",startAmt: "41.52",endAmt: "60.02",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 829,indent: 1,parent: 828,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 830,indent: 1,parent: 828,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.00",amountToPot: "30",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "",
},
{
id: 831,indent: 1,parent: 828,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 832,indent: 1,parent: 828,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "5.00",potSizeToWin: "11.50",amountToPot: "43",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "5.00",boardCards: "",
},
{
id: 833,indent: 1,parent: 828,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "16.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 834,indent: 1,parent: 828,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "CheckRaise",amount: "26.25",potSizeToWin: "25.50",amountToPot: "102",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "9.00",boardCards: "",
},
{
id: 835,indent: 0,parent: null,handNum: "208",wonOrLost: "-2.00",startAmt: "60.02",endAmt: "58.02",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 836,indent: 1,parent: 835,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 837,indent: 1,parent: 835,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "4.75",amountToPot: "31",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "",
},
{
id: 838,indent: 1,parent: 835,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 839,indent: 1,parent: 835,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "4.00",boardCards: "",
},
{
id: 840,indent: 0,parent: null,handNum: "209",wonOrLost: "-2.00",startAmt: "58.02",endAmt: "56.02",finalHand: "",position: "BB (2 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 841,indent: 1,parent: 840,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 842,indent: 1,parent: 840,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 843,indent: 1,parent: 840,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "4.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 844,indent: 0,parent: null,handNum: "210",wonOrLost: "-5.75",startAmt: "56.02",endAmt: "50.27",finalHand: "",position: "SB (1 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 845,indent: 1,parent: 844,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 846,indent: 1,parent: 844,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.50",amountToPot: "60",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 847,indent: 1,parent: 844,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 848,indent: 1,parent: 844,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "5.00",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "",
},
{
id: 849,indent: 1,parent: 844,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 850,indent: 1,parent: 844,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.00",potSizeToWin: "9.00",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "",
},
{
id: 851,indent: 1,parent: 844,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 852,indent: 1,parent: 844,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "18.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "6.00",boardCards: "",
},
{
id: 853,indent: 0,parent: null,handNum: "211",wonOrLost: "0.50",startAmt: "50.27",endAmt: "50.27",finalHand: "Two Pair, K's & 10's (SP:3)",position: "Dealer (5 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 854,indent: 1,parent: 853,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 855,indent: 1,parent: 853,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 856,indent: 1,parent: 853,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 857,indent: 1,parent: 853,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 858,indent: 0,parent: null,handNum: "212",wonOrLost: "-3.00",startAmt: "50.27",endAmt: "47.27",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 859,indent: 1,parent: 858,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "2.50",amountToPot: "70",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 860,indent: 1,parent: 858,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "8.25",amountToPot: "15",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "2.75",boardCards: "",
},
{
id: 861,indent: 1,parent: 858,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "15.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, [3<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 862,indent: 0,parent: null,handNum: "213",wonOrLost: "0.00",startAmt: "47.27",endAmt: "47.27",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 863,indent: 1,parent: 862,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 864,indent: 0,parent: null,handNum: "214",wonOrLost: "-1.50",startAmt: "47.27",endAmt: "45.77",finalHand: "",position: "BB (2 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 865,indent: 1,parent: 864,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 866,indent: 1,parent: 864,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 867,indent: 1,parent: 864,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 868,indent: 1,parent: 864,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 869,indent: 1,parent: 864,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 870,indent: 0,parent: null,handNum: "215",wonOrLost: "1.00",startAmt: "45.77",endAmt: "46.27",finalHand: "",position: "SB (1 of 5)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 871,indent: 1,parent: 870,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 872,indent: 1,parent: 870,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 873,indent: 1,parent: 870,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 874,indent: 1,parent: 870,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 875,indent: 0,parent: null,handNum: "216",wonOrLost: "6.00",startAmt: "46.27",endAmt: "49.77",finalHand: "",position: "Dealer (5 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 876,indent: 1,parent: 875,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 877,indent: 1,parent: 875,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "4.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 878,indent: 1,parent: 875,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 879,indent: 1,parent: 875,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "4.50",potSizeToWin: "6.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 880,indent: 0,parent: null,handNum: "217",wonOrLost: "-2.00",startAmt: "49.77",endAmt: "47.77",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 881,indent: 1,parent: 880,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 882,indent: 1,parent: 880,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "6.50",amountToPot: "23",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "",
},
{
id: 883,indent: 1,parent: 880,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "16.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "8.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, [7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 884,indent: 0,parent: null,handNum: "218",wonOrLost: "0.00",startAmt: "47.77",endAmt: "47.77",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 885,indent: 1,parent: 884,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 886,indent: 0,parent: null,handNum: "219",wonOrLost: "-0.50",startAmt: "47.77",endAmt: "47.27",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 887,indent: 1,parent: 886,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 888,indent: 1,parent: 886,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 889,indent: 1,parent: 886,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 890,indent: 1,parent: 886,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 891,indent: 1,parent: 886,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 892,indent: 0,parent: null,handNum: "220",wonOrLost: "-1.50",startAmt: "47.27",endAmt: "45.77",finalHand: "",position: "SB (1 of 5)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 893,indent: 1,parent: 892,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 894,indent: 1,parent: 892,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 895,indent: 1,parent: 892,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 896,indent: 1,parent: 892,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 897,indent: 1,parent: 892,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.00",potSizeToWin: "4.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.00",boardCards: "",
},
{
id: 898,indent: 1,parent: 892,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 899,indent: 1,parent: 892,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "",
},
{
id: 900,indent: 0,parent: null,handNum: "221",wonOrLost: "8.00",startAmt: "45.77",endAmt: "50.27",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 901,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 902,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "3.00",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 903,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.00",potSizeToWin: "6.00",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 904,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "8.00",potSizeToWin: "8.00",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 905,indent: 0,parent: null,handNum: "222",wonOrLost: "0.00",startAmt: "50.27",endAmt: "50.27",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 906,indent: 1,parent: 905,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 907,indent: 0,parent: null,handNum: "223",wonOrLost: "-0.50",startAmt: "50.27",endAmt: "49.77",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 908,indent: 1,parent: 907,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 909,indent: 1,parent: 907,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "4.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 910,indent: 0,parent: null,handNum: "224",wonOrLost: "-2.00",startAmt: "49.77",endAmt: "47.77",finalHand: "",position: "BB (2 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 911,indent: 1,parent: 910,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 912,indent: 1,parent: 910,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 913,indent: 1,parent: 910,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 914,indent: 1,parent: 910,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 915,indent: 1,parent: 910,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "4.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 916,indent: 0,parent: null,handNum: "225",wonOrLost: "-1.81",startAmt: "47.77",endAmt: "45.96",finalHand: "",position: "SB (1 of 6)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 917,indent: 1,parent: 916,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 918,indent: 1,parent: 916,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.56",potSizeToWin: "4.87",amountToPot: "32",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.81",boardCards: "",
},
{
id: 919,indent: 1,parent: 916,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.43",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 920,indent: 1,parent: 916,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.43",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 921,indent: 1,parent: 916,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "9.64",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.21",boardCards: "",
},
{
id: 922,indent: 0,parent: null,handNum: "226",wonOrLost: "-1.00",startAmt: "45.96",endAmt: "44.96",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 923,indent: 1,parent: 922,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 924,indent: 1,parent: 922,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 925,indent: 1,parent: 922,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, [7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 926,indent: 0,parent: null,handNum: "227",wonOrLost: "-2.00",startAmt: "44.96",endAmt: "42.96",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 927,indent: 1,parent: 926,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 928,indent: 1,parent: 926,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 929,indent: 1,parent: 926,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "7.00",amountToPot: "21",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "",
},
{
id: 930,indent: 1,parent: 926,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "8.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 931,indent: 1,parent: 926,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "8.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 932,indent: 1,parent: 926,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "12.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "",
},
{
id: 933,indent: 0,parent: null,handNum: "228",wonOrLost: "-0.50",startAmt: "42.96",endAmt: "42.46",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 934,indent: 1,parent: 933,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 935,indent: 1,parent: 933,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 936,indent: 1,parent: 933,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 937,indent: 1,parent: 933,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 938,indent: 0,parent: null,handNum: "229",wonOrLost: "-0.50",startAmt: "42.46",endAmt: "41.96",finalHand: "",position: "BB (2 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 939,indent: 1,parent: 938,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 940,indent: 1,parent: 938,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.25",boardCards: "",
},
{
id: 941,indent: 0,parent: null,handNum: "230",wonOrLost: "6.50",startAmt: "41.96",endAmt: "46.46",finalHand: "Two Pair, 8's & 7's",position: "SB (1 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 942,indent: 1,parent: 941,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 943,indent: 1,parent: 941,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 944,indent: 1,parent: 941,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 945,indent: 1,parent: 941,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "3.50",amountToPot: "14",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 946,indent: 1,parent: 941,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.50",potSizeToWin: "6.00",amountToPot: "8",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 947,indent: 1,parent: 941,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 948,indent: 0,parent: null,handNum: "231",wonOrLost: "-1.00",startAmt: "46.46",endAmt: "45.46",finalHand: "",position: "Dealer (5 of 5)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 949,indent: 1,parent: 948,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 950,indent: 1,parent: 948,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "4.00",amountToPot: "12",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 951,indent: 1,parent: 948,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.75",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 952,indent: 0,parent: null,handNum: "232",wonOrLost: "9.75",startAmt: "45.46",endAmt: "50.96",finalHand: "Straight, J High",position: "Cutoff (5 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 953,indent: 1,parent: 952,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 954,indent: 1,parent: 952,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 955,indent: 1,parent: 952,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 956,indent: 1,parent: 952,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "3.25",potSizeToWin: "3.25",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 957,indent: 0,parent: null,handNum: "233",wonOrLost: "0.00",startAmt: "50.96",endAmt: "50.96",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 958,indent: 1,parent: 957,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 959,indent: 0,parent: null,handNum: "234",wonOrLost: "21.92",startAmt: "50.96",endAmt: "62.17",finalHand: "Pair, 5's",position: "UTG1 (3 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 960,indent: 1,parent: 959,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.12",potSizeToWin: "0.75",amountToPot: "149",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 961,indent: 1,parent: 959,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.37",potSizeToWin: "4.11",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.37",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 962,indent: 1,parent: 959,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.74",potSizeToWin: "8.22",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.74",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 963,indent: 1,parent: 959,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "5.48",potSizeToWin: "16.44",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.48",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 964,indent: 0,parent: null,handNum: "235",wonOrLost: "-0.50",startAmt: "62.17",endAmt: "61.67",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 965,indent: 1,parent: 964,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 966,indent: 1,parent: 964,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 967,indent: 1,parent: 964,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 968,indent: 1,parent: 964,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.75",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
];
