﻿var title = "Hand Details for Greg at Table1";
var handFilename = "Table1-Details.html";
var data = [
{
id: 0,indent: 0,parent: null,handNum: "88",wonOrLost: "-1.50",startAmt: "40.00",endAmt: "38.50",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 2,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.75",amountToPot: "36",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 3,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "3",numAllIns: "1",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 4,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.50",amountToPot: "0",numPlayers: "3",numAllIns: "1",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.75",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 5,indent: 0,parent: null,handNum: "89",wonOrLost: "-0.25",startAmt: "38.50",endAmt: "38.25",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 6,indent: 1,parent: 5,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 7,indent: 1,parent: 5,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 8,indent: 0,parent: null,handNum: "90",wonOrLost: "0.00",startAmt: "38.25",endAmt: "38.25",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 9,indent: 1,parent: 8,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 10,indent: 0,parent: null,handNum: "91",wonOrLost: "0.00",startAmt: "38.25",endAmt: "38.25",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 11,indent: 1,parent: 10,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 12,indent: 0,parent: null,handNum: "92",wonOrLost: "-2.00",startAmt: "38.25",endAmt: "36.25",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 13,indent: 1,parent: 12,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 14,indent: 1,parent: 12,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 15,indent: 1,parent: 12,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "11.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "5.00",boardCards: "",
},
{
id: 16,indent: 0,parent: null,handNum: "93",wonOrLost: "0.00",startAmt: "36.25",endAmt: "36.25",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 17,indent: 1,parent: 16,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 18,indent: 0,parent: null,handNum: "94",wonOrLost: "-0.50",startAmt: "36.25",endAmt: "35.75",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 19,indent: 1,parent: 18,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 20,indent: 1,parent: 18,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.00",boardCards: "",
},
{
id: 21,indent: 0,parent: null,handNum: "95",wonOrLost: "-0.50",startAmt: "35.75",endAmt: "35.25",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 22,indent: 1,parent: 21,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 23,indent: 1,parent: 21,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 24,indent: 1,parent: 21,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 25,indent: 1,parent: 21,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 26,indent: 0,parent: null,handNum: "96",wonOrLost: "-0.50",startAmt: "35.25",endAmt: "34.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 27,indent: 1,parent: 26,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 28,indent: 1,parent: 26,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 29,indent: 0,parent: null,handNum: "97",wonOrLost: "4.75",startAmt: "34.75",endAmt: "37.50",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 30,indent: 1,parent: 29,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 31,indent: 1,parent: 29,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.25",potSizeToWin: "4.75",amountToPot: "68",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 32,indent: 0,parent: null,handNum: "98",wonOrLost: "3.75",startAmt: "37.50",endAmt: "39.75",finalHand: "",position: "MP1 (4 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 33,indent: 1,parent: 32,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 34,indent: 1,parent: 32,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.75",potSizeToWin: "3.75",amountToPot: "73",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 35,indent: 0,parent: null,handNum: "99",wonOrLost: "0.00",startAmt: "39.75",endAmt: "39.75",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 36,indent: 1,parent: 35,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 37,indent: 0,parent: null,handNum: "100",wonOrLost: "-1.50",startAmt: "39.75",endAmt: "38.25",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 38,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 39,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "3.50",amountToPot: "28",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 40,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 41,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.50",boardCards: "",
},
{
id: 42,indent: 0,parent: null,handNum: "101",wonOrLost: "-38.25",startAmt: "38.25",endAmt: "0.00",finalHand: "",position: "SB (1 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 43,indent: 1,parent: 42,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 44,indent: 1,parent: 42,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 45,indent: 1,parent: 42,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.75",potSizeToWin: "2.50",amountToPot: "70",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 46,indent: 1,parent: 42,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "4.50",potSizeToWin: "7.75",amountToPot: "58",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 47,indent: 1,parent: 42,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "4.50",potSizeToWin: "21.25",amountToPot: "21",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "9.00",boardCards: "",
},
{
id: 48,indent: 1,parent: 42,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "17.50",potSizeToWin: "25.75",amountToPot: "67",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 49,indent: 1,parent: 42,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "CallAllIn",amount: "9.50",potSizeToWin: "85.90",amountToPot: "11",numPlayers: "2",numAllIns: "2",positionToLastAction: "1",lastAction: "RaiseAllIn",lastActionPlayer: "Chris Moy",lastActionAmount: "42.65",boardCards: "",
},
{
id: 50,indent: 0,parent: null,handNum: "104",wonOrLost: "0.00",startAmt: "40.00",endAmt: "40.00",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 51,indent: 1,parent: 50,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 52,indent: 0,parent: null,handNum: "105",wonOrLost: "0.00",startAmt: "40.00",endAmt: "40.00",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 53,indent: 1,parent: 52,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 54,indent: 0,parent: null,handNum: "106",wonOrLost: "-0.50",startAmt: "40.00",endAmt: "39.50",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 55,indent: 1,parent: 54,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 56,indent: 1,parent: 54,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 57,indent: 1,parent: 54,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, [8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 58,indent: 0,parent: null,handNum: "107",wonOrLost: "-0.50",startAmt: "39.50",endAmt: "39.00",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 59,indent: 1,parent: 58,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 60,indent: 1,parent: 58,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 61,indent: 1,parent: 58,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 62,indent: 1,parent: 58,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.11",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.74",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 63,indent: 0,parent: null,handNum: "108",wonOrLost: "0.00",startAmt: "39.00",endAmt: "39.00",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 64,indent: 1,parent: 63,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 65,indent: 0,parent: null,handNum: "109",wonOrLost: "0.00",startAmt: "39.00",endAmt: "39.00",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 66,indent: 1,parent: 65,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 67,indent: 0,parent: null,handNum: "110",wonOrLost: "1.25",startAmt: "39.00",endAmt: "39.75",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 68,indent: 1,parent: 67,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 69,indent: 0,parent: null,handNum: "111",wonOrLost: "0.00",startAmt: "39.75",endAmt: "39.75",finalHand: "",position: "MP1 (4 of 6)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 70,indent: 1,parent: 69,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 71,indent: 0,parent: null,handNum: "112",wonOrLost: "0.00",startAmt: "39.75",endAmt: "39.75",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 72,indent: 1,parent: 71,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 73,indent: 0,parent: null,handNum: "113",wonOrLost: "-0.50",startAmt: "39.75",endAmt: "39.25",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 74,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 75,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 76,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 77,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 78,indent: 1,parent: 73,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 79,indent: 0,parent: null,handNum: "114",wonOrLost: "15.00",startAmt: "39.25",endAmt: "46.75",finalHand: "Pair, 10's",position: "SB (1 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 80,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 81,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.25",potSizeToWin: "0.75",amountToPot: "166",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 82,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 83,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "4.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 84,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 85,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "4.50",potSizeToWin: "10.50",amountToPot: "42",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "4.50",boardCards: "",
},
{
id: 86,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "15.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 87,indent: 0,parent: null,handNum: "115",wonOrLost: "0.00",startAmt: "46.75",endAmt: "46.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 88,indent: 1,parent: 87,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 89,indent: 0,parent: null,handNum: "116",wonOrLost: "0.00",startAmt: "46.75",endAmt: "46.75",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 90,indent: 1,parent: 89,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 91,indent: 0,parent: null,handNum: "117",wonOrLost: "0.00",startAmt: "46.75",endAmt: "46.75",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 92,indent: 1,parent: 91,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 93,indent: 0,parent: null,handNum: "118",wonOrLost: "0.00",startAmt: "46.75",endAmt: "46.75",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 94,indent: 1,parent: 93,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 95,indent: 0,parent: null,handNum: "119",wonOrLost: "2.50",startAmt: "46.75",endAmt: "48.00",finalHand: "Straight, 5 High",position: "BB (2 of 6)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 96,indent: 1,parent: 95,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 97,indent: 1,parent: 95,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 98,indent: 1,parent: 95,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.75",potSizeToWin: "1.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 99,indent: 1,parent: 95,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 100,indent: 1,parent: 95,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 101,indent: 0,parent: null,handNum: "120",wonOrLost: "-0.25",startAmt: "48.00",endAmt: "47.75",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 102,indent: 1,parent: 101,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 103,indent: 1,parent: 101,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.25",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 104,indent: 0,parent: null,handNum: "121",wonOrLost: "0.00",startAmt: "47.75",endAmt: "47.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 105,indent: 1,parent: 104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "",
},
{
id: 106,indent: 0,parent: null,handNum: "122",wonOrLost: "0.00",startAmt: "47.75",endAmt: "47.75",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 107,indent: 1,parent: 106,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 108,indent: 0,parent: null,handNum: "123",wonOrLost: "0.00",startAmt: "47.75",endAmt: "47.75",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 109,indent: 1,parent: 108,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 110,indent: 0,parent: null,handNum: "124",wonOrLost: "0.00",startAmt: "47.75",endAmt: "47.75",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 111,indent: 1,parent: 110,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 112,indent: 0,parent: null,handNum: "125",wonOrLost: "41.32",startAmt: "47.75",endAmt: "69.41",finalHand: "Three of a Kind, J's",position: "BB (2 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 113,indent: 1,parent: 112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 114,indent: 1,parent: 112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "7.00",potSizeToWin: "5.25",amountToPot: "133",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "",
},
{
id: 115,indent: 1,parent: 112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "12.50",potSizeToWin: "17.00",amountToPot: "73",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 116,indent: 0,parent: null,handNum: "126",wonOrLost: "-0.50",startAmt: "69.41",endAmt: "68.91",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 117,indent: 1,parent: 116,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 118,indent: 1,parent: 116,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 119,indent: 1,parent: 116,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 120,indent: 1,parent: 116,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 121,indent: 0,parent: null,handNum: "127",wonOrLost: "0.00",startAmt: "68.91",endAmt: "68.91",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 122,indent: 1,parent: 121,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 123,indent: 0,parent: null,handNum: "128",wonOrLost: "0.00",startAmt: "68.91",endAmt: "68.91",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 124,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 125,indent: 0,parent: null,handNum: "129",wonOrLost: "0.00",startAmt: "68.91",endAmt: "68.91",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 126,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 127,indent: 0,parent: null,handNum: "130",wonOrLost: "-1.50",startAmt: "68.91",endAmt: "67.41",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 128,indent: 1,parent: 127,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 129,indent: 1,parent: 127,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 130,indent: 1,parent: 127,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.00",boardCards: "",
},
{
id: 131,indent: 0,parent: null,handNum: "131",wonOrLost: "-1.50",startAmt: "67.41",endAmt: "65.91",finalHand: "",position: "BB (2 of 6)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 132,indent: 1,parent: 131,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 133,indent: 1,parent: 131,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 134,indent: 1,parent: 131,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 135,indent: 1,parent: 131,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 136,indent: 1,parent: 131,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 137,indent: 0,parent: null,handNum: "132",wonOrLost: "-0.50",startAmt: "65.91",endAmt: "65.41",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 138,indent: 1,parent: 137,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 139,indent: 1,parent: 137,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 140,indent: 1,parent: 137,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 141,indent: 1,parent: 137,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 142,indent: 0,parent: null,handNum: "133",wonOrLost: "0.00",startAmt: "65.41",endAmt: "65.41",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 143,indent: 1,parent: 142,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 144,indent: 0,parent: null,handNum: "134",wonOrLost: "0.00",startAmt: "65.41",endAmt: "65.41",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 145,indent: 1,parent: 144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 146,indent: 0,parent: null,handNum: "135",wonOrLost: "0.00",startAmt: "65.41",endAmt: "65.41",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 147,indent: 1,parent: 146,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 148,indent: 0,parent: null,handNum: "136",wonOrLost: "64.21",startAmt: "65.41",endAmt: "99.14",finalHand: "Pair, A's",position: "UTG1 (3 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 149,indent: 1,parent: 148,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 150,indent: 1,parent: 148,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "5.00",potSizeToWin: "6.25",amountToPot: "80",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 151,indent: 1,parent: 148,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "5.00",potSizeToWin: "21.25",amountToPot: "23",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "10.00",boardCards: "",
},
{
id: 152,indent: 1,parent: 148,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "26.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 153,indent: 1,parent: 148,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "18.98",potSizeToWin: "45.23",amountToPot: "41",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "Jeff",lastActionAmount: "18.98",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 154,indent: 0,parent: null,handNum: "137",wonOrLost: "1.75",startAmt: "99.14",endAmt: "100.39",finalHand: "",position: "BB (2 of 5)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 155,indent: 1,parent: 154,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 156,indent: 1,parent: 154,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.75",amountToPot: "85",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 157,indent: 0,parent: null,handNum: "138",wonOrLost: "-0.25",startAmt: "100.39",endAmt: "100.14",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 158,indent: 1,parent: 157,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 159,indent: 1,parent: 157,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 160,indent: 0,parent: null,handNum: "139",wonOrLost: "0.00",startAmt: "100.14",endAmt: "100.14",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 161,indent: 1,parent: 160,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 162,indent: 0,parent: null,handNum: "140",wonOrLost: "0.00",startAmt: "100.14",endAmt: "100.14",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 163,indent: 1,parent: 162,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 164,indent: 0,parent: null,handNum: "141",wonOrLost: "0.00",startAmt: "100.14",endAmt: "100.14",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 165,indent: 1,parent: 164,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 166,indent: 0,parent: null,handNum: "142",wonOrLost: "0.00",startAmt: "100.14",endAmt: "100.14",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 167,indent: 1,parent: 166,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 168,indent: 0,parent: null,handNum: "143",wonOrLost: "-0.50",startAmt: "100.14",endAmt: "99.64",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 169,indent: 1,parent: 168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 170,indent: 1,parent: 168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 171,indent: 0,parent: null,handNum: "144",wonOrLost: "-0.50",startAmt: "99.64",endAmt: "99.14",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 172,indent: 1,parent: 171,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 173,indent: 1,parent: 171,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 174,indent: 1,parent: 171,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 175,indent: 1,parent: 171,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 176,indent: 0,parent: null,handNum: "145",wonOrLost: "0.00",startAmt: "99.14",endAmt: "99.14",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 177,indent: 1,parent: 176,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 178,indent: 0,parent: null,handNum: "146",wonOrLost: "2.00",startAmt: "99.14",endAmt: "100.64",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 179,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 180,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.25",potSizeToWin: "2.00",amountToPot: "62",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 181,indent: 0,parent: null,handNum: "147",wonOrLost: "0.00",startAmt: "100.64",endAmt: "100.64",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 182,indent: 1,parent: 181,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 183,indent: 0,parent: null,handNum: "148",wonOrLost: "0.00",startAmt: "100.64",endAmt: "100.64",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 184,indent: 1,parent: 183,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 185,indent: 0,parent: null,handNum: "149",wonOrLost: "12.75",startAmt: "100.64",endAmt: "107.64",finalHand: "Two Pair, A's & 3's",position: "BB (2 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 186,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 187,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.25",potSizeToWin: "4.50",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.75",boardCards: "",
},
{
id: 188,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 189,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.00",potSizeToWin: "9.75",amountToPot: "30",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "",
},
{
id: 190,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "12.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 191,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "12.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 192,indent: 0,parent: null,handNum: "150",wonOrLost: "13.50",startAmt: "107.64",endAmt: "115.14",finalHand: "Pair, Q's",position: "SB (1 of 5)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 193,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 194,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "2.25",amountToPot: "55",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 195,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 196,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "4.50",potSizeToWin: "9.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.50",boardCards: "",
},
{
id: 197,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "13.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 198,indent: 1,parent: 192,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "13.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 199,indent: 0,parent: null,handNum: "151",wonOrLost: "-20.75",startAmt: "115.14",endAmt: "94.39",finalHand: "",position: "Dealer (6 of 6)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 200,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 201,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.75",potSizeToWin: "8.25",amountToPot: "33",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.75",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 202,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "5.50",potSizeToWin: "16.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "5.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 203,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "12.00",potSizeToWin: "22.00",amountToPot: "54",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 204,indent: 0,parent: null,handNum: "152",wonOrLost: "0.00",startAmt: "94.39",endAmt: "94.39",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 205,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 206,indent: 0,parent: null,handNum: "153",wonOrLost: "0.00",startAmt: "94.39",endAmt: "94.39",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 207,indent: 1,parent: 206,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 208,indent: 0,parent: null,handNum: "154",wonOrLost: "0.00",startAmt: "94.39",endAmt: "94.39",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 209,indent: 1,parent: 208,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 210,indent: 0,parent: null,handNum: "155",wonOrLost: "13.00",startAmt: "94.39",endAmt: "100.89",finalHand: "Flush, Jh High",position: "BB (2 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 211,indent: 1,parent: 210,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 212,indent: 1,parent: 210,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 213,indent: 1,parent: 210,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.75",potSizeToWin: "1.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 214,indent: 1,parent: 210,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "2.50",amountToPot: "60",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 215,indent: 1,parent: 210,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "3.75",potSizeToWin: "5.50",amountToPot: "68",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 216,indent: 0,parent: null,handNum: "156",wonOrLost: "6.00",startAmt: "100.89",endAmt: "104.89",finalHand: "",position: "SB (1 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 217,indent: 1,parent: 216,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 218,indent: 1,parent: 216,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.75",potSizeToWin: "1.25",amountToPot: "140",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 219,indent: 1,parent: 216,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "4.00",potSizeToWin: "6.00",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 220,indent: 0,parent: null,handNum: "157",wonOrLost: "5.75",startAmt: "104.89",endAmt: "108.89",finalHand: "Two Pair, K's & Q's",position: "Dealer (5 of 5)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 221,indent: 1,parent: 220,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 222,indent: 1,parent: 220,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.25",potSizeToWin: "2.00",amountToPot: "62",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 223,indent: 1,parent: 220,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 224,indent: 1,parent: 220,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 225,indent: 0,parent: null,handNum: "158",wonOrLost: "0.00",startAmt: "108.89",endAmt: "108.89",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 226,indent: 1,parent: 225,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 227,indent: 0,parent: null,handNum: "159",wonOrLost: "0.00",startAmt: "108.89",endAmt: "108.89",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 228,indent: 1,parent: 227,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 229,indent: 0,parent: null,handNum: "160",wonOrLost: "-0.50",startAmt: "108.89",endAmt: "108.39",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 230,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 231,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 232,indent: 1,parent: 229,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 233,indent: 0,parent: null,handNum: "161",wonOrLost: "-0.25",startAmt: "108.39",endAmt: "108.14",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 234,indent: 1,parent: 233,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 235,indent: 1,parent: 233,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.25",boardCards: "",
},
{
id: 236,indent: 0,parent: null,handNum: "162",wonOrLost: "0.00",startAmt: "108.14",endAmt: "108.14",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 237,indent: 1,parent: 236,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 238,indent: 0,parent: null,handNum: "163",wonOrLost: "-2.50",startAmt: "108.14",endAmt: "105.64",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 239,indent: 1,parent: 238,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 240,indent: 1,parent: 238,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "2.00",potSizeToWin: "2.50",amountToPot: "80",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 241,indent: 1,parent: 238,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "87.37",amountToPot: "0",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "Jim O",lastActionAmount: "79.37",boardCards: "7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 242,indent: 0,parent: null,handNum: "164",wonOrLost: "0.00",startAmt: "105.64",endAmt: "105.64",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 243,indent: 1,parent: 242,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 244,indent: 0,parent: null,handNum: "165",wonOrLost: "-3.50",startAmt: "105.64",endAmt: "102.14",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 245,indent: 1,parent: 244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 246,indent: 1,parent: 244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.75",amountToPot: "21",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.50",boardCards: "",
},
{
id: 247,indent: 1,parent: 244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 248,indent: 1,parent: 244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "2.00",potSizeToWin: "7.25",amountToPot: "27",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 249,indent: 1,parent: 244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "13.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jim O",lastActionAmount: "4.00",boardCards: "",
},
{
id: 250,indent: 0,parent: null,handNum: "166",wonOrLost: "-0.50",startAmt: "102.14",endAmt: "101.64",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 251,indent: 1,parent: 250,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 252,indent: 1,parent: 250,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 253,indent: 1,parent: 250,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 254,indent: 1,parent: 250,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 255,indent: 0,parent: null,handNum: "167",wonOrLost: "0.00",startAmt: "101.64",endAmt: "101.64",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 256,indent: 1,parent: 255,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.18",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Will",lastActionAmount: "1.43",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 257,indent: 0,parent: null,handNum: "168",wonOrLost: "8.25",startAmt: "101.64",endAmt: "107.39",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 258,indent: 1,parent: 257,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "1.75",amountToPot: "142",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 259,indent: 1,parent: 257,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "5.00",potSizeToWin: "8.25",amountToPot: "60",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 260,indent: 0,parent: null,handNum: "169",wonOrLost: "0.00",startAmt: "107.39",endAmt: "107.39",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 261,indent: 1,parent: 260,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 262,indent: 0,parent: null,handNum: "170",wonOrLost: "0.00",startAmt: "107.39",endAmt: "107.39",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 263,indent: 1,parent: 262,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 264,indent: 0,parent: null,handNum: "171",wonOrLost: "19.49",startAmt: "107.39",endAmt: "117.26",finalHand: "",position: "BB (2 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 265,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 266,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.25",amountToPot: "44",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 267,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 268,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.25",potSizeToWin: "6.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.25",boardCards: "",
},
{
id: 269,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 270,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "CheckRaise",amount: "15.00",potSizeToWin: "14.62",amountToPot: "102",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.87",boardCards: "",
},
{
id: 271,indent: 0,parent: null,handNum: "172",wonOrLost: "-0.50",startAmt: "117.26",endAmt: "116.76",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 272,indent: 1,parent: 271,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 273,indent: 1,parent: 271,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 274,indent: 1,parent: 271,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 275,indent: 1,parent: 271,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.25",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 276,indent: 0,parent: null,handNum: "173",wonOrLost: "0.00",startAmt: "116.76",endAmt: "116.76",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 277,indent: 1,parent: 276,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 278,indent: 0,parent: null,handNum: "174",wonOrLost: "0.00",startAmt: "116.76",endAmt: "116.76",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 279,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 280,indent: 0,parent: null,handNum: "175",wonOrLost: "0.00",startAmt: "116.76",endAmt: "116.76",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 281,indent: 1,parent: 280,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 282,indent: 0,parent: null,handNum: "176",wonOrLost: "0.00",startAmt: "116.76",endAmt: "116.76",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 283,indent: 1,parent: 282,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 284,indent: 0,parent: null,handNum: "177",wonOrLost: "-0.50",startAmt: "116.76",endAmt: "116.26",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 285,indent: 1,parent: 284,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 286,indent: 1,parent: 284,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 287,indent: 1,parent: 284,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 288,indent: 1,parent: 284,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 289,indent: 0,parent: null,handNum: "178",wonOrLost: "-0.50",startAmt: "116.26",endAmt: "115.76",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 290,indent: 1,parent: 289,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 291,indent: 1,parent: 289,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 292,indent: 1,parent: 289,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 293,indent: 1,parent: 289,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 294,indent: 0,parent: null,handNum: "179",wonOrLost: "0.00",startAmt: "115.76",endAmt: "115.76",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 295,indent: 1,parent: 294,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 296,indent: 0,parent: null,handNum: "180",wonOrLost: "-3.75",startAmt: "115.76",endAmt: "112.01",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 297,indent: 1,parent: 296,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "1.75",amountToPot: "57",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "",
},
{
id: 298,indent: 1,parent: 296,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 299,indent: 1,parent: 296,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.75",potSizeToWin: "5.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "2.75",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 300,indent: 1,parent: 296,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "16.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "8.25",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 301,indent: 0,parent: null,handNum: "181",wonOrLost: "0.00",startAmt: "112.01",endAmt: "112.01",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 302,indent: 1,parent: 301,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 303,indent: 0,parent: null,handNum: "182",wonOrLost: "0.00",startAmt: "112.01",endAmt: "112.01",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 304,indent: 1,parent: 303,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 305,indent: 0,parent: null,handNum: "183",wonOrLost: "-0.50",startAmt: "112.01",endAmt: "111.51",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 306,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 307,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 308,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.75",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 309,indent: 0,parent: null,handNum: "184",wonOrLost: "-0.50",startAmt: "111.51",endAmt: "111.01",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 310,indent: 1,parent: 309,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 311,indent: 1,parent: 309,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 312,indent: 1,parent: 309,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 313,indent: 1,parent: 309,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 314,indent: 1,parent: 309,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 315,indent: 0,parent: null,handNum: "185",wonOrLost: "0.00",startAmt: "111.01",endAmt: "111.01",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 316,indent: 1,parent: 315,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 317,indent: 0,parent: null,handNum: "186",wonOrLost: "-3.50",startAmt: "111.01",endAmt: "107.51",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 318,indent: 1,parent: 317,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "",
},
{
id: 319,indent: 1,parent: 317,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "3.00",potSizeToWin: "8.50",amountToPot: "35",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.50",boardCards: "",
},
{
id: 320,indent: 1,parent: 317,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "17.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.75",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, [9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 321,indent: 0,parent: null,handNum: "187",wonOrLost: "0.00",startAmt: "107.51",endAmt: "107.51",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 322,indent: 1,parent: 321,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 323,indent: 0,parent: null,handNum: "188",wonOrLost: "0.00",startAmt: "107.51",endAmt: "107.51",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 324,indent: 1,parent: 323,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 325,indent: 0,parent: null,handNum: "189",wonOrLost: "-0.50",startAmt: "107.51",endAmt: "107.01",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 326,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 327,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 328,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 329,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 330,indent: 0,parent: null,handNum: "190",wonOrLost: "-0.25",startAmt: "107.01",endAmt: "106.76",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 331,indent: 1,parent: 330,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 332,indent: 1,parent: 330,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.25",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 333,indent: 0,parent: null,handNum: "191",wonOrLost: "8.25",startAmt: "106.76",endAmt: "112.51",finalHand: "",position: "Dealer (6 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 334,indent: 1,parent: 333,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "1.75",amountToPot: "142",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 335,indent: 1,parent: 333,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "5.00",potSizeToWin: "8.25",amountToPot: "60",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 336,indent: 0,parent: null,handNum: "192",wonOrLost: "0.00",startAmt: "112.51",endAmt: "112.51",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 337,indent: 1,parent: 336,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Suzanne",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 338,indent: 0,parent: null,handNum: "193",wonOrLost: "0.00",startAmt: "112.51",endAmt: "112.51",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 339,indent: 1,parent: 338,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 340,indent: 0,parent: null,handNum: "194",wonOrLost: "0.00",startAmt: "112.51",endAmt: "112.51",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 341,indent: 1,parent: 340,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 342,indent: 0,parent: null,handNum: "195",wonOrLost: "1.00",startAmt: "112.51",endAmt: "113.01",finalHand: "",position: "BB (2 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 343,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 344,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 345,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 346,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 347,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 348,indent: 0,parent: null,handNum: "196",wonOrLost: "-20.25",startAmt: "113.01",endAmt: "92.76",finalHand: "",position: "SB (1 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 349,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 350,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 351,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "2.50",amountToPot: "80",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 352,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 353,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "5.25",potSizeToWin: "21.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.25",boardCards: "",
},
{
id: 354,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "26.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 355,indent: 1,parent: 348,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "12.50",potSizeToWin: "38.75",amountToPot: "32",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "12.50",boardCards: "",
},
{
id: 356,indent: 0,parent: null,handNum: "197",wonOrLost: "0.00",startAmt: "92.76",endAmt: "92.76",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 357,indent: 1,parent: 356,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 358,indent: 0,parent: null,handNum: "198",wonOrLost: "0.00",startAmt: "92.76",endAmt: "92.76",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 359,indent: 1,parent: 358,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 360,indent: 0,parent: null,handNum: "199",wonOrLost: "0.00",startAmt: "92.76",endAmt: "92.76",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 361,indent: 1,parent: 360,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 362,indent: 0,parent: null,handNum: "200",wonOrLost: "-0.50",startAmt: "92.76",endAmt: "92.26",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 363,indent: 1,parent: 362,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 364,indent: 1,parent: 362,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 365,indent: 0,parent: null,handNum: "201",wonOrLost: "-0.25",startAmt: "92.26",endAmt: "92.01",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 366,indent: 1,parent: 365,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 367,indent: 1,parent: 365,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 368,indent: 0,parent: null,handNum: "202",wonOrLost: "0.00",startAmt: "92.01",endAmt: "92.01",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 369,indent: 1,parent: 368,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.87",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Will",lastActionAmount: "1.12",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 370,indent: 0,parent: null,handNum: "203",wonOrLost: "1.75",startAmt: "92.01",endAmt: "93.26",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 371,indent: 1,parent: 370,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 372,indent: 0,parent: null,handNum: "204",wonOrLost: "0.00",startAmt: "93.26",endAmt: "93.26",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 373,indent: 1,parent: 372,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 374,indent: 0,parent: null,handNum: "205",wonOrLost: "-1.43",startAmt: "93.26",endAmt: "91.83",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 375,indent: 1,parent: 374,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 376,indent: 1,parent: 374,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.93",potSizeToWin: "3.61",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.43",boardCards: "",
},
{
id: 377,indent: 1,parent: 374,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.54",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 378,indent: 1,parent: 374,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.62",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "6.81",boardCards: "",
},
{
id: 379,indent: 0,parent: null,handNum: "206",wonOrLost: "-0.25",startAmt: "91.83",endAmt: "91.58",finalHand: "",position: "SB (1 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 380,indent: 1,parent: 379,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 381,indent: 1,parent: 379,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 382,indent: 0,parent: null,handNum: "207",wonOrLost: "-16.00",startAmt: "91.58",endAmt: "75.58",finalHand: "",position: "Dealer (5 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 383,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 384,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "5.00",potSizeToWin: "6.50",amountToPot: "76",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 385,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "9.00",potSizeToWin: "16.50",amountToPot: "54",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 386,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "51.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Will",lastActionAmount: "26.25",boardCards: "",
},
{
id: 387,indent: 0,parent: null,handNum: "208",wonOrLost: "6.25",startAmt: "75.58",endAmt: "79.83",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 388,indent: 1,parent: 387,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 389,indent: 1,parent: 387,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "4.00",potSizeToWin: "6.25",amountToPot: "64",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 390,indent: 0,parent: null,handNum: "209",wonOrLost: "0.00",startAmt: "79.83",endAmt: "79.83",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 391,indent: 1,parent: 390,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 392,indent: 0,parent: null,handNum: "210",wonOrLost: "-0.50",startAmt: "79.83",endAmt: "79.33",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 393,indent: 1,parent: 392,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 394,indent: 1,parent: 392,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 395,indent: 0,parent: null,handNum: "211",wonOrLost: "0.50",startAmt: "79.33",endAmt: "79.33",finalHand: "Two Pair, K's & 10's (SP:3)",position: "SB (1 of 5)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 396,indent: 1,parent: 395,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 397,indent: 1,parent: 395,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 398,indent: 1,parent: 395,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 399,indent: 1,parent: 395,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 400,indent: 1,parent: 395,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 401,indent: 0,parent: null,handNum: "212",wonOrLost: "0.00",startAmt: "79.33",endAmt: "79.33",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 402,indent: 1,parent: 401,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.75",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 403,indent: 0,parent: null,handNum: "213",wonOrLost: "-1.50",startAmt: "79.33",endAmt: "77.83",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 404,indent: 1,parent: 403,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 405,indent: 1,parent: 403,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.75",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 406,indent: 0,parent: null,handNum: "214",wonOrLost: "0.00",startAmt: "77.83",endAmt: "77.83",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 407,indent: 1,parent: 406,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 408,indent: 0,parent: null,handNum: "215",wonOrLost: "-0.50",startAmt: "77.83",endAmt: "77.33",finalHand: "",position: "BB (2 of 5)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 409,indent: 1,parent: 408,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 410,indent: 1,parent: 408,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 411,indent: 1,parent: 408,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 412,indent: 1,parent: 408,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 413,indent: 0,parent: null,handNum: "216",wonOrLost: "-0.50",startAmt: "77.33",endAmt: "76.83",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 414,indent: 1,parent: 413,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 415,indent: 1,parent: 413,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 416,indent: 1,parent: 413,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 417,indent: 1,parent: 413,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 418,indent: 0,parent: null,handNum: "217",wonOrLost: "-2.00",startAmt: "76.83",endAmt: "74.83",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 419,indent: 1,parent: 418,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 420,indent: 1,parent: 418,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "16.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "8.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, [7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 421,indent: 0,parent: null,handNum: "218",wonOrLost: "0.00",startAmt: "74.83",endAmt: "74.83",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 422,indent: 1,parent: 421,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 423,indent: 0,parent: null,handNum: "219",wonOrLost: "0.00",startAmt: "74.83",endAmt: "74.83",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 424,indent: 1,parent: 423,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 425,indent: 0,parent: null,handNum: "220",wonOrLost: "-0.50",startAmt: "74.83",endAmt: "74.33",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 426,indent: 1,parent: 425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 427,indent: 1,parent: 425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 428,indent: 1,parent: 425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 429,indent: 1,parent: 425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 430,indent: 1,parent: 425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 431,indent: 0,parent: null,handNum: "221",wonOrLost: "-0.50",startAmt: "74.33",endAmt: "73.83",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 432,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 433,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 434,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 435,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 436,indent: 0,parent: null,handNum: "222",wonOrLost: "1.75",startAmt: "73.83",endAmt: "75.08",finalHand: "",position: "Dealer (5 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 437,indent: 1,parent: 436,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "1.25",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 438,indent: 0,parent: null,handNum: "223",wonOrLost: "0.00",startAmt: "75.08",endAmt: "75.08",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 439,indent: 1,parent: 438,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 440,indent: 0,parent: null,handNum: "224",wonOrLost: "0.00",startAmt: "75.08",endAmt: "75.08",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 441,indent: 1,parent: 440,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 442,indent: 0,parent: null,handNum: "225",wonOrLost: "-0.50",startAmt: "75.08",endAmt: "74.58",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 443,indent: 1,parent: 442,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 444,indent: 1,parent: 442,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.43",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.81",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 445,indent: 0,parent: null,handNum: "226",wonOrLost: "9.00",startAmt: "74.58",endAmt: "79.58",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 446,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 447,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 448,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 449,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 450,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "CheckRaise",amount: "3.00",potSizeToWin: "4.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 451,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "6.00",potSizeToWin: "9.00",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 452,indent: 0,parent: null,handNum: "227",wonOrLost: "12.50",startAmt: "79.58",endAmt: "88.08",finalHand: "Straight, 6 High",position: "Dealer (6 of 6)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 453,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 454,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "2.50",amountToPot: "60",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 455,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "8.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 456,indent: 1,parent: 452,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "2.00",potSizeToWin: "8.50",amountToPot: "23",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 457,indent: 0,parent: null,handNum: "228",wonOrLost: "2.50",startAmt: "88.08",endAmt: "90.08",finalHand: "Two Pair, 8's & 6's",position: "Cutoff (4 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 458,indent: 1,parent: 457,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 459,indent: 1,parent: 457,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 460,indent: 1,parent: 457,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 461,indent: 1,parent: 457,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 462,indent: 0,parent: null,handNum: "229",wonOrLost: "0.00",startAmt: "90.08",endAmt: "90.08",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 463,indent: 1,parent: 462,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "",
},
{
id: 464,indent: 0,parent: null,handNum: "230",wonOrLost: "-0.50",startAmt: "90.08",endAmt: "89.58",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 465,indent: 1,parent: 464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 466,indent: 1,parent: 464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 467,indent: 1,parent: 464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, [4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 468,indent: 0,parent: null,handNum: "231",wonOrLost: "-1.00",startAmt: "89.58",endAmt: "88.58",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 469,indent: 1,parent: 468,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 470,indent: 1,parent: 468,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 471,indent: 1,parent: 468,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "4.50",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 472,indent: 1,parent: 468,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 473,indent: 1,parent: 468,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.75",boardCards: "",
},
{
id: 474,indent: 0,parent: null,handNum: "232",wonOrLost: "0.00",startAmt: "88.58",endAmt: "88.58",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 475,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 476,indent: 0,parent: null,handNum: "233",wonOrLost: "16.00",startAmt: "88.58",endAmt: "98.08",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 477,indent: 1,parent: 476,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "1.25",amountToPot: "200",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 478,indent: 1,parent: 476,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "10.00",potSizeToWin: "12.00",amountToPot: "83",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "4.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 479,indent: 0,parent: null,handNum: "234",wonOrLost: "0.00",startAmt: "98.08",endAmt: "98.08",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 480,indent: 1,parent: 479,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.87",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Will",lastActionAmount: "1.12",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 481,indent: 0,parent: null,handNum: "235",wonOrLost: "0.00",startAmt: "98.08",endAmt: "98.08",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 482,indent: 1,parent: 481,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Will",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 483,indent: 0,parent: null,handNum: "238",wonOrLost: "0.00",startAmt: "98.08",endAmt: "98.08",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 484,indent: 1,parent: 483,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 485,indent: 0,parent: null,handNum: "239",wonOrLost: "0.00",startAmt: "98.08",endAmt: "98.08",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 486,indent: 1,parent: 485,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 487,indent: 0,parent: null,handNum: "240",wonOrLost: "-0.50",startAmt: "98.08",endAmt: "97.58",finalHand: "",position: "BB (2 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 488,indent: 1,parent: 487,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 489,indent: 1,parent: 487,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 490,indent: 1,parent: 487,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 491,indent: 1,parent: 487,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 492,indent: 1,parent: 487,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 493,indent: 0,parent: null,handNum: "241",wonOrLost: "-0.25",startAmt: "97.58",endAmt: "97.33",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 494,indent: 1,parent: 493,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 495,indent: 1,parent: 493,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 496,indent: 0,parent: null,handNum: "242",wonOrLost: "0.00",startAmt: "97.33",endAmt: "97.33",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 497,indent: 1,parent: 496,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 498,indent: 0,parent: null,handNum: "243",wonOrLost: "1.25",startAmt: "97.33",endAmt: "98.08",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 499,indent: 1,parent: 498,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 500,indent: 0,parent: null,handNum: "244",wonOrLost: "0.00",startAmt: "98.08",endAmt: "98.08",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 501,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 502,indent: 0,parent: null,handNum: "245",wonOrLost: "-0.50",startAmt: "98.08",endAmt: "97.58",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 503,indent: 1,parent: 502,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 504,indent: 1,parent: 502,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.75",boardCards: "",
},
{
id: 505,indent: 0,parent: null,handNum: "246",wonOrLost: "-0.25",startAmt: "97.58",endAmt: "97.33",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 506,indent: 1,parent: 505,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 507,indent: 1,parent: 505,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "",
},
{
id: 508,indent: 0,parent: null,handNum: "247",wonOrLost: "11.50",startAmt: "97.33",endAmt: "103.83",finalHand: "Pair, Q's",position: "Dealer (4 of 4)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 509,indent: 1,parent: 508,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 510,indent: 1,parent: 508,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.00",amountToPot: "16",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.75",boardCards: "",
},
{
id: 511,indent: 1,parent: 508,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "5.00",amountToPot: "30",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 512,indent: 1,parent: 508,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.50",potSizeToWin: "9.00",amountToPot: "27",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "2.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 513,indent: 1,parent: 508,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "11.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 514,indent: 0,parent: null,handNum: "248",wonOrLost: "0.00",startAmt: "103.83",endAmt: "103.83",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 515,indent: 1,parent: 514,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 516,indent: 0,parent: null,handNum: "249",wonOrLost: "8.75",startAmt: "103.83",endAmt: "108.58",finalHand: "Pair, Q's",position: "UTG1 (3 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 517,indent: 1,parent: 516,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 518,indent: 1,parent: 516,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 519,indent: 1,parent: 516,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 520,indent: 1,parent: 516,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "3.75",amountToPot: "26",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 521,indent: 1,parent: 516,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 522,indent: 1,parent: 516,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.00",potSizeToWin: "6.75",amountToPot: "29",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "",
},
{
id: 523,indent: 1,parent: 516,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 524,indent: 0,parent: null,handNum: "250",wonOrLost: "-0.50",startAmt: "108.58",endAmt: "108.08",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 525,indent: 1,parent: 524,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 526,indent: 1,parent: 524,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 527,indent: 1,parent: 524,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 528,indent: 1,parent: 524,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 529,indent: 0,parent: null,handNum: "251",wonOrLost: "-0.50",startAmt: "108.08",endAmt: "107.58",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 530,indent: 1,parent: 529,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 531,indent: 1,parent: 529,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 532,indent: 1,parent: 529,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 533,indent: 1,parent: 529,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "",
},
{
id: 534,indent: 0,parent: null,handNum: "252",wonOrLost: "0.00",startAmt: "107.58",endAmt: "107.58",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 535,indent: 1,parent: 534,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 536,indent: 0,parent: null,handNum: "253",wonOrLost: "0.00",startAmt: "107.58",endAmt: "107.58",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 537,indent: 1,parent: 536,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 538,indent: 0,parent: null,handNum: "254",wonOrLost: "1.25",startAmt: "107.58",endAmt: "108.33",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 539,indent: 1,parent: 538,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 540,indent: 0,parent: null,handNum: "255",wonOrLost: "-0.50",startAmt: "108.33",endAmt: "107.83",finalHand: "",position: "BB (2 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 541,indent: 1,parent: 540,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 542,indent: 1,parent: 540,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 543,indent: 1,parent: 540,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 544,indent: 1,parent: 540,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "1.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 545,indent: 0,parent: null,handNum: "256",wonOrLost: "-0.25",startAmt: "107.83",endAmt: "107.58",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 546,indent: 1,parent: 545,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 547,indent: 1,parent: 545,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 548,indent: 0,parent: null,handNum: "257",wonOrLost: "0.00",startAmt: "107.58",endAmt: "107.58",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 549,indent: 1,parent: 548,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.25",boardCards: "",
},
{
id: 550,indent: 0,parent: null,handNum: "258",wonOrLost: "-1.50",startAmt: "107.58",endAmt: "106.08",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 551,indent: 1,parent: 550,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 552,indent: 1,parent: 550,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 553,indent: 0,parent: null,handNum: "259",wonOrLost: "0.00",startAmt: "106.08",endAmt: "106.08",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 554,indent: 1,parent: 553,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 555,indent: 0,parent: null,handNum: "260",wonOrLost: "0.00",startAmt: "106.08",endAmt: "106.08",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 556,indent: 1,parent: 555,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 557,indent: 0,parent: null,handNum: "261",wonOrLost: "0.00",startAmt: "106.08",endAmt: "106.08",finalHand: "",position: "MP1 (4 of 8)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 558,indent: 1,parent: 557,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 559,indent: 0,parent: null,handNum: "262",wonOrLost: "0.00",startAmt: "106.08",endAmt: "106.08",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 560,indent: 1,parent: 559,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 561,indent: 0,parent: null,handNum: "263",wonOrLost: "-0.50",startAmt: "106.08",endAmt: "105.58",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 562,indent: 1,parent: 561,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 563,indent: 1,parent: 561,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 564,indent: 1,parent: 561,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 565,indent: 1,parent: 561,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 566,indent: 0,parent: null,handNum: "264",wonOrLost: "-0.25",startAmt: "105.58",endAmt: "105.33",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 567,indent: 1,parent: 566,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 568,indent: 1,parent: 566,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "2.50",boardCards: "",
},
{
id: 569,indent: 0,parent: null,handNum: "265",wonOrLost: "0.00",startAmt: "105.33",endAmt: "105.33",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 570,indent: 1,parent: 569,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 571,indent: 0,parent: null,handNum: "266",wonOrLost: "0.00",startAmt: "105.33",endAmt: "105.33",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 572,indent: 1,parent: 571,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.68",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "1.93",boardCards: "",
},
{
id: 573,indent: 0,parent: null,handNum: "267",wonOrLost: "-0.50",startAmt: "105.33",endAmt: "104.83",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 574,indent: 1,parent: 573,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 575,indent: 1,parent: 573,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 576,indent: 0,parent: null,handNum: "268",wonOrLost: "0.00",startAmt: "104.83",endAmt: "104.83",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 577,indent: 1,parent: 576,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.25",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 578,indent: 0,parent: null,handNum: "269",wonOrLost: "0.00",startAmt: "104.83",endAmt: "104.83",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 579,indent: 1,parent: 578,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 580,indent: 0,parent: null,handNum: "270",wonOrLost: "0.00",startAmt: "104.83",endAmt: "104.83",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 581,indent: 1,parent: 580,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 582,indent: 0,parent: null,handNum: "271",wonOrLost: "-0.50",startAmt: "104.83",endAmt: "104.33",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 583,indent: 1,parent: 582,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 584,indent: 1,parent: 582,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 585,indent: 1,parent: 582,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 586,indent: 1,parent: 582,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 587,indent: 0,parent: null,handNum: "272",wonOrLost: "-0.50",startAmt: "104.33",endAmt: "103.83",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 588,indent: 1,parent: 587,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 589,indent: 1,parent: 587,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "3.50",amountToPot: "7",numPlayers: "7",numAllIns: "0",positionToLastAction: "6",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 590,indent: 1,parent: 587,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 591,indent: 1,parent: 587,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "4.00",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 592,indent: 0,parent: null,handNum: "273",wonOrLost: "0.00",startAmt: "103.83",endAmt: "103.83",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 593,indent: 1,parent: 592,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.25",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 594,indent: 0,parent: null,handNum: "274",wonOrLost: "0.00",startAmt: "103.83",endAmt: "103.83",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 595,indent: 1,parent: 594,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "",
},
{
id: 596,indent: 0,parent: null,handNum: "275",wonOrLost: "0.00",startAmt: "103.83",endAmt: "103.83",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 597,indent: 1,parent: 596,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 598,indent: 0,parent: null,handNum: "276",wonOrLost: "0.00",startAmt: "103.83",endAmt: "103.83",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 599,indent: 1,parent: 598,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 600,indent: 0,parent: null,handNum: "277",wonOrLost: "0.00",startAmt: "103.83",endAmt: "103.83",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 601,indent: 1,parent: 600,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 602,indent: 0,parent: null,handNum: "278",wonOrLost: "0.00",startAmt: "103.83",endAmt: "103.83",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 603,indent: 1,parent: 602,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 604,indent: 0,parent: null,handNum: "279",wonOrLost: "0.00",startAmt: "103.83",endAmt: "103.83",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 605,indent: 1,parent: 604,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 606,indent: 0,parent: null,handNum: "280",wonOrLost: "-0.50",startAmt: "103.83",endAmt: "103.33",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 607,indent: 1,parent: 606,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 608,indent: 1,parent: 606,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jim O",lastActionAmount: "7.75",boardCards: "",
},
{
id: 609,indent: 0,parent: null,handNum: "281",wonOrLost: "-0.25",startAmt: "103.33",endAmt: "103.08",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 610,indent: 1,parent: 609,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 611,indent: 1,parent: 609,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "2.75",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 612,indent: 0,parent: null,handNum: "282",wonOrLost: "0.00",startAmt: "103.08",endAmt: "103.08",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 613,indent: 1,parent: 612,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 614,indent: 0,parent: null,handNum: "283",wonOrLost: "0.00",startAmt: "103.08",endAmt: "103.08",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 615,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 616,indent: 0,parent: null,handNum: "284",wonOrLost: "0.00",startAmt: "103.08",endAmt: "103.08",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 617,indent: 1,parent: 616,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 618,indent: 0,parent: null,handNum: "285",wonOrLost: "0.00",startAmt: "103.08",endAmt: "103.08",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 619,indent: 1,parent: 618,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "2.75",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 620,indent: 0,parent: null,handNum: "286",wonOrLost: "0.00",startAmt: "103.08",endAmt: "103.08",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 621,indent: 1,parent: 620,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 622,indent: 0,parent: null,handNum: "287",wonOrLost: "0.00",startAmt: "103.08",endAmt: "103.08",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 623,indent: 1,parent: 622,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 624,indent: 0,parent: null,handNum: "288",wonOrLost: "0.00",startAmt: "103.08",endAmt: "103.08",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 625,indent: 1,parent: 624,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 626,indent: 0,parent: null,handNum: "289",wonOrLost: "-0.50",startAmt: "103.08",endAmt: "102.58",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 627,indent: 1,parent: 626,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 628,indent: 1,parent: 626,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 629,indent: 0,parent: null,handNum: "290",wonOrLost: "-0.25",startAmt: "102.58",endAmt: "102.33",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 630,indent: 1,parent: 629,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 631,indent: 1,parent: 629,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 632,indent: 0,parent: null,handNum: "291",wonOrLost: "23.62",startAmt: "102.33",endAmt: "103.45",finalHand: "Two Pair, A's & J's (SP:2)",position: "Dealer (9 of 9)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 633,indent: 1,parent: 632,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "5.50",potSizeToWin: "5.00",amountToPot: "110",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "2.75",boardCards: "",
},
{
id: 634,indent: 1,parent: 632,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "7.00",potSizeToWin: "13.25",amountToPot: "52",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 635,indent: 1,parent: 632,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "27.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 636,indent: 1,parent: 632,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "10.00",potSizeToWin: "27.25",amountToPot: "36",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 637,indent: 0,parent: null,handNum: "292",wonOrLost: "0.00",startAmt: "103.45",endAmt: "103.45",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 638,indent: 1,parent: 637,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 639,indent: 0,parent: null,handNum: "293",wonOrLost: "0.00",startAmt: "103.45",endAmt: "103.45",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 640,indent: 1,parent: 639,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 641,indent: 0,parent: null,handNum: "294",wonOrLost: "0.00",startAmt: "103.45",endAmt: "103.45",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 642,indent: 1,parent: 641,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 643,indent: 0,parent: null,handNum: "295",wonOrLost: "0.00",startAmt: "103.45",endAmt: "103.45",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 644,indent: 1,parent: 643,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.25",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 645,indent: 0,parent: null,handNum: "296",wonOrLost: "-4.50",startAmt: "103.45",endAmt: "98.95",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 646,indent: 1,parent: 645,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 647,indent: 1,parent: 645,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.00",potSizeToWin: "4.75",amountToPot: "63",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 648,indent: 1,parent: 645,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "6.00",boardCards: "",
},
{
id: 649,indent: 0,parent: null,handNum: "297",wonOrLost: "0.00",startAmt: "98.95",endAmt: "98.95",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 650,indent: 1,parent: 649,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 651,indent: 0,parent: null,handNum: "298",wonOrLost: "212.90",startAmt: "98.95",endAmt: "212.90",finalHand: "Straight, 6 High",position: "BB (2 of 9)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 652,indent: 1,parent: 651,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 653,indent: 1,parent: 651,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.75",amountToPot: "26",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 654,indent: 1,parent: 651,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 655,indent: 1,parent: 651,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "CheckRaise",amount: "14.00",potSizeToWin: "19.25",amountToPot: "72",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "6.00",boardCards: "",
},
{
id: 656,indent: 1,parent: 651,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "35.00",potSizeToWin: "47.00",amountToPot: "74",numPlayers: "3",numAllIns: "1",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 657,indent: 1,parent: 651,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "BetAllIn",amount: "47.95",potSizeToWin: "117.00",amountToPot: "40",numPlayers: "3",numAllIns: "2",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 658,indent: 0,parent: null,handNum: "299",wonOrLost: "-0.25",startAmt: "212.90",endAmt: "212.65",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 659,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 660,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "29.43",amountToPot: "0",numPlayers: "4",numAllIns: "2",positionToLastAction: "2",lastAction: "RaiseAllIn",lastActionPlayer: "Chris Moy",lastActionAmount: "28.57",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 661,indent: 0,parent: null,handNum: "300",wonOrLost: "0.00",startAmt: "212.65",endAmt: "212.65",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 662,indent: 1,parent: 661,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "2.25",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 663,indent: 0,parent: null,handNum: "301",wonOrLost: "0.00",startAmt: "212.65",endAmt: "212.65",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 664,indent: 1,parent: 663,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 665,indent: 0,parent: null,handNum: "302",wonOrLost: "0.00",startAmt: "212.65",endAmt: "212.65",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 666,indent: 1,parent: 665,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 667,indent: 0,parent: null,handNum: "303",wonOrLost: "0.00",startAmt: "212.65",endAmt: "212.65",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 668,indent: 1,parent: 667,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 669,indent: 0,parent: null,handNum: "304",wonOrLost: "0.00",startAmt: "212.65",endAmt: "212.65",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 670,indent: 1,parent: 669,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 671,indent: 0,parent: null,handNum: "305",wonOrLost: "-1.50",startAmt: "212.65",endAmt: "211.15",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 672,indent: 1,parent: 671,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 673,indent: 1,parent: 671,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "6.50",amountToPot: "15",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 674,indent: 1,parent: 671,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "12.50",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, [6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 675,indent: 0,parent: null,handNum: "306",wonOrLost: "15.22",startAmt: "211.15",endAmt: "219.76",finalHand: "",position: "SB (1 of 8)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 676,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 677,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.75",amountToPot: "9",numPlayers: "6",numAllIns: "0",positionToLastAction: "5",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 678,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 679,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.00",potSizeToWin: "6.00",amountToPot: "50",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "3.00",boardCards: "",
},
{
id: 680,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 681,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "CheckRaise",amount: "9.33",potSizeToWin: "12.11",amountToPot: "77",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "3.11",boardCards: "",
},
{
id: 682,indent: 0,parent: null,handNum: "307",wonOrLost: "0.00",startAmt: "219.76",endAmt: "219.76",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 683,indent: 1,parent: 682,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "2.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 684,indent: 0,parent: null,handNum: "308",wonOrLost: "0.00",startAmt: "219.76",endAmt: "219.76",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 685,indent: 1,parent: 684,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "11.97",amountToPot: "0",numPlayers: "5",numAllIns: "1",positionToLastAction: "1",lastAction: "RaiseAllIn",lastActionPlayer: "Craig",lastActionAmount: "11.22",boardCards: "",
},
{
id: 686,indent: 0,parent: null,handNum: "309",wonOrLost: "0.00",startAmt: "219.76",endAmt: "219.76",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 687,indent: 1,parent: 686,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 688,indent: 0,parent: null,handNum: "310",wonOrLost: "0.00",startAmt: "219.76",endAmt: "219.76",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 689,indent: 1,parent: 688,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 690,indent: 0,parent: null,handNum: "311",wonOrLost: "0.00",startAmt: "219.76",endAmt: "219.76",finalHand: "",position: "MP1 (4 of 8)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 691,indent: 1,parent: 690,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.25",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 692,indent: 0,parent: null,handNum: "312",wonOrLost: "0.00",startAmt: "219.76",endAmt: "219.76",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 693,indent: 1,parent: 692,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 694,indent: 0,parent: null,handNum: "313",wonOrLost: "3.75",startAmt: "219.76",endAmt: "221.76",finalHand: "Two Pair, 7's & 5's (SP:2)",position: "BB (2 of 7)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 695,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 696,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "3.75",amountToPot: "33",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.50",boardCards: "",
},
{
id: 697,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 698,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 699,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 700,indent: 0,parent: null,handNum: "314",wonOrLost: "-0.25",startAmt: "221.76",endAmt: "221.51",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 701,indent: 1,parent: 700,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 702,indent: 1,parent: 700,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.11",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Craig",lastActionAmount: "2.74",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 703,indent: 0,parent: null,handNum: "315",wonOrLost: "-0.50",startAmt: "221.51",endAmt: "221.01",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 704,indent: 1,parent: 703,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 705,indent: 1,parent: 703,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 706,indent: 0,parent: null,handNum: "316",wonOrLost: "-0.50",startAmt: "221.01",endAmt: "220.51",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 707,indent: 1,parent: 706,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 708,indent: 1,parent: 706,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.75",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 709,indent: 0,parent: null,handNum: "317",wonOrLost: "0.00",startAmt: "220.51",endAmt: "220.51",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 710,indent: 1,parent: 709,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 711,indent: 0,parent: null,handNum: "318",wonOrLost: "0.00",startAmt: "220.51",endAmt: "220.51",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 712,indent: 1,parent: 711,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.25",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 713,indent: 0,parent: null,handNum: "319",wonOrLost: "6.75",startAmt: "220.51",endAmt: "225.26",finalHand: "",position: "MP1 (4 of 8)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 714,indent: 1,parent: 713,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 715,indent: 1,parent: 713,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "5.00",potSizeToWin: "6.75",amountToPot: "74",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 716,indent: 0,parent: null,handNum: "320",wonOrLost: "-4.00",startAmt: "225.26",endAmt: "221.26",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 717,indent: 1,parent: 716,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 718,indent: 1,parent: 716,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "6.75",amountToPot: "29",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "4.00",boardCards: "",
},
{
id: 719,indent: 1,parent: 716,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 720,indent: 1,parent: 716,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "11.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "3.00",boardCards: "",
},
{
id: 721,indent: 0,parent: null,handNum: "321",wonOrLost: "-1.00",startAmt: "221.26",endAmt: "220.26",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 722,indent: 1,parent: 721,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 723,indent: 1,parent: 721,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "",
},
{
id: 724,indent: 1,parent: 721,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 725,indent: 1,parent: 721,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.66",amountToPot: "0",numPlayers: "3",numAllIns: "1",positionToLastAction: "1",lastAction: "RaiseAllIn",lastActionPlayer: "Craig",lastActionAmount: "7.98",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 726,indent: 0,parent: null,handNum: "322",wonOrLost: "9.00",startAmt: "220.26",endAmt: "225.76",finalHand: "Pair, Q's",position: "SB (1 of 8)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 727,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 728,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "3.75",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 729,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 730,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "7.00",amountToPot: "28",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 731,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 732,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 733,indent: 0,parent: null,handNum: "323",wonOrLost: "0.00",startAmt: "225.76",endAmt: "225.76",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 734,indent: 1,parent: 733,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 735,indent: 0,parent: null,handNum: "324",wonOrLost: "0.00",startAmt: "225.76",endAmt: "225.76",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 736,indent: 1,parent: 735,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.26",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "2.01",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 737,indent: 0,parent: null,handNum: "325",wonOrLost: "0.00",startAmt: "225.76",endAmt: "225.76",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 738,indent: 1,parent: 737,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 739,indent: 0,parent: null,handNum: "326",wonOrLost: "0.00",startAmt: "225.76",endAmt: "225.76",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 740,indent: 1,parent: 739,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 741,indent: 0,parent: null,handNum: "327",wonOrLost: "0.00",startAmt: "225.76",endAmt: "225.76",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 742,indent: 1,parent: 741,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 743,indent: 0,parent: null,handNum: "328",wonOrLost: "0.00",startAmt: "225.76",endAmt: "225.76",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 744,indent: 1,parent: 743,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 745,indent: 0,parent: null,handNum: "329",wonOrLost: "-1.50",startAmt: "225.76",endAmt: "224.26",finalHand: "",position: "BB (2 of 8)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 746,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 747,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 748,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "3.00",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 749,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.31",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "3.31",boardCards: "",
},
{
id: 750,indent: 0,parent: null,handNum: "330",wonOrLost: "-0.25",startAmt: "224.26",endAmt: "224.01",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 751,indent: 1,parent: 750,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 752,indent: 1,parent: 750,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "2.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 753,indent: 0,parent: null,handNum: "331",wonOrLost: "-0.50",startAmt: "224.01",endAmt: "223.51",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 754,indent: 1,parent: 753,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 755,indent: 1,parent: 753,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 756,indent: 0,parent: null,handNum: "332",wonOrLost: "0.00",startAmt: "223.51",endAmt: "223.51",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 757,indent: 1,parent: 756,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "4.00",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 758,indent: 0,parent: null,handNum: "333",wonOrLost: "0.00",startAmt: "223.51",endAmt: "223.51",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 759,indent: 1,parent: 758,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.05",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "2.30",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 760,indent: 0,parent: null,handNum: "334",wonOrLost: "0.00",startAmt: "223.51",endAmt: "223.51",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 761,indent: 1,parent: 760,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 762,indent: 0,parent: null,handNum: "335",wonOrLost: "0.00",startAmt: "223.51",endAmt: "223.51",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 763,indent: 1,parent: 762,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 764,indent: 0,parent: null,handNum: "336",wonOrLost: "-1.50",startAmt: "223.51",endAmt: "222.01",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 765,indent: 1,parent: 764,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 766,indent: 1,parent: 764,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "3.75",amountToPot: "26",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 767,indent: 1,parent: 764,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 768,indent: 1,parent: 764,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "6.00",boardCards: "",
},
{
id: 769,indent: 0,parent: null,handNum: "337",wonOrLost: "-0.25",startAmt: "222.01",endAmt: "221.76",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 770,indent: 1,parent: 769,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 771,indent: 1,parent: 769,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 772,indent: 0,parent: null,handNum: "338",wonOrLost: "-0.50",startAmt: "221.76",endAmt: "221.26",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 773,indent: 1,parent: 772,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 774,indent: 1,parent: 772,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.37",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "1.87",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 775,indent: 0,parent: null,handNum: "339",wonOrLost: "0.00",startAmt: "221.26",endAmt: "221.26",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 776,indent: 1,parent: 775,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 777,indent: 0,parent: null,handNum: "340",wonOrLost: "0.00",startAmt: "221.26",endAmt: "221.26",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 778,indent: 1,parent: 777,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 779,indent: 0,parent: null,handNum: "341",wonOrLost: "0.00",startAmt: "221.26",endAmt: "221.26",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 780,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 781,indent: 0,parent: null,handNum: "342",wonOrLost: "0.00",startAmt: "221.26",endAmt: "221.26",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 782,indent: 1,parent: 781,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.75",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 783,indent: 0,parent: null,handNum: "343",wonOrLost: "0.00",startAmt: "221.26",endAmt: "221.26",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 784,indent: 1,parent: 783,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 785,indent: 0,parent: null,handNum: "344",wonOrLost: "2.50",startAmt: "221.26",endAmt: "223.26",finalHand: "",position: "BB (2 of 8)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 786,indent: 1,parent: 785,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 787,indent: 1,parent: 785,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 788,indent: 1,parent: 785,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 789,indent: 1,parent: 785,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.75",potSizeToWin: "2.50",amountToPot: "70",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 790,indent: 0,parent: null,handNum: "345",wonOrLost: "-0.50",startAmt: "223.26",endAmt: "222.76",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 791,indent: 1,parent: 790,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 792,indent: 1,parent: 790,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.75",amountToPot: "9",numPlayers: "6",numAllIns: "0",positionToLastAction: "5",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 793,indent: 1,parent: 790,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 794,indent: 1,parent: 790,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "",
},
{
id: 795,indent: 0,parent: null,handNum: "346",wonOrLost: "0.00",startAmt: "222.76",endAmt: "222.76",finalHand: "",position: "Dealer (8 of 8)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 796,indent: 1,parent: 795,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 797,indent: 0,parent: null,handNum: "347",wonOrLost: "-0.50",startAmt: "222.76",endAmt: "222.26",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 798,indent: 1,parent: 797,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 799,indent: 1,parent: 797,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "1.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 800,indent: 0,parent: null,handNum: "348",wonOrLost: "-1.00",startAmt: "222.26",endAmt: "221.26",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 801,indent: 1,parent: 800,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "1.75",amountToPot: "57",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.00",boardCards: "",
},
{
id: 802,indent: 1,parent: 800,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.87",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "1.62",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 803,indent: 0,parent: null,handNum: "349",wonOrLost: "0.00",startAmt: "221.26",endAmt: "221.26",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 804,indent: 1,parent: 803,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 805,indent: 0,parent: null,handNum: "350",wonOrLost: "0.00",startAmt: "221.26",endAmt: "221.26",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 806,indent: 1,parent: 805,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 807,indent: 0,parent: null,handNum: "351",wonOrLost: "0.00",startAmt: "221.26",endAmt: "221.26",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 808,indent: 1,parent: 807,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 809,indent: 0,parent: null,handNum: "352",wonOrLost: "-0.50",startAmt: "221.26",endAmt: "220.76",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 810,indent: 1,parent: 809,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 811,indent: 1,parent: 809,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 812,indent: 1,parent: 809,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.25",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 813,indent: 0,parent: null,handNum: "353",wonOrLost: "-0.25",startAmt: "220.76",endAmt: "220.51",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 814,indent: 1,parent: 813,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 815,indent: 1,parent: 813,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Craig",lastActionAmount: "3.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 816,indent: 0,parent: null,handNum: "354",wonOrLost: "-5.00",startAmt: "220.51",endAmt: "215.51",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 817,indent: 1,parent: 816,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "4.25",amountToPot: "35",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 818,indent: 1,parent: 816,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "3.50",potSizeToWin: "10.25",amountToPot: "34",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "4.50",boardCards: "",
},
{
id: 819,indent: 1,parent: 816,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "20.62",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "6.87",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 820,indent: 0,parent: null,handNum: "355",wonOrLost: "0.00",startAmt: "215.51",endAmt: "215.51",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 821,indent: 1,parent: 820,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 822,indent: 0,parent: null,handNum: "356",wonOrLost: "0.00",startAmt: "215.51",endAmt: "215.51",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 823,indent: 1,parent: 822,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 824,indent: 0,parent: null,handNum: "357",wonOrLost: "0.00",startAmt: "215.51",endAmt: "215.51",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 825,indent: 1,parent: 824,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 826,indent: 0,parent: null,handNum: "358",wonOrLost: "0.00",startAmt: "215.51",endAmt: "215.51",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 827,indent: 1,parent: 826,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 828,indent: 0,parent: null,handNum: "359",wonOrLost: "0.00",startAmt: "215.51",endAmt: "215.51",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 829,indent: 1,parent: 828,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 830,indent: 0,parent: null,handNum: "360",wonOrLost: "-0.50",startAmt: "215.51",endAmt: "215.01",finalHand: "",position: "BB (2 of 8)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 831,indent: 1,parent: 830,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 832,indent: 1,parent: 830,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 833,indent: 0,parent: null,handNum: "361",wonOrLost: "-0.50",startAmt: "215.01",endAmt: "214.51",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 834,indent: 1,parent: 833,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 835,indent: 1,parent: 833,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 836,indent: 1,parent: 833,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 837,indent: 1,parent: 833,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 838,indent: 0,parent: null,handNum: "362",wonOrLost: "0.00",startAmt: "214.51",endAmt: "214.51",finalHand: "",position: "Dealer (8 of 8)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 839,indent: 1,parent: 838,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 840,indent: 0,parent: null,handNum: "363",wonOrLost: "5.75",startAmt: "214.51",endAmt: "218.01",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 841,indent: 1,parent: 840,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.25",potSizeToWin: "3.50",amountToPot: "64",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "2.25",boardCards: "",
},
{
id: 842,indent: 1,parent: 840,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.50",potSizeToWin: "5.75",amountToPot: "60",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 843,indent: 0,parent: null,handNum: "364",wonOrLost: "-4.50",startAmt: "218.01",endAmt: "213.51",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 844,indent: 1,parent: 843,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 845,indent: 1,parent: 843,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.00",potSizeToWin: "4.75",amountToPot: "63",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 846,indent: 1,parent: 843,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "10.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 847,indent: 1,parent: 843,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "16.12",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.37",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 848,indent: 0,parent: null,handNum: "365",wonOrLost: "0.00",startAmt: "213.51",endAmt: "213.51",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 849,indent: 1,parent: 848,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 850,indent: 0,parent: null,handNum: "366",wonOrLost: "0.00",startAmt: "213.51",endAmt: "213.51",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 851,indent: 1,parent: 850,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 852,indent: 0,parent: null,handNum: "367",wonOrLost: "0.00",startAmt: "213.51",endAmt: "213.51",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 853,indent: 1,parent: 852,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 854,indent: 0,parent: null,handNum: "368",wonOrLost: "-0.50",startAmt: "213.51",endAmt: "213.01",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 855,indent: 1,parent: 854,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 856,indent: 1,parent: 854,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "",
},
{
id: 857,indent: 0,parent: null,handNum: "369",wonOrLost: "-0.25",startAmt: "213.01",endAmt: "212.76",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 858,indent: 1,parent: 857,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 859,indent: 1,parent: 857,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 860,indent: 0,parent: null,handNum: "370",wonOrLost: "0.00",startAmt: "212.76",endAmt: "212.76",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 861,indent: 1,parent: 860,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 862,indent: 0,parent: null,handNum: "371",wonOrLost: "-0.50",startAmt: "212.76",endAmt: "212.26",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 863,indent: 1,parent: 862,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "7",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 864,indent: 1,parent: 862,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, [10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 865,indent: 0,parent: null,handNum: "372",wonOrLost: "0.00",startAmt: "212.26",endAmt: "212.26",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 866,indent: 1,parent: 865,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 867,indent: 0,parent: null,handNum: "373",wonOrLost: "0.00",startAmt: "212.26",endAmt: "212.26",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 868,indent: 1,parent: 867,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 869,indent: 0,parent: null,handNum: "374",wonOrLost: "26.75",startAmt: "212.26",endAmt: "226.01",finalHand: "",position: "MP1 (4 of 8)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 870,indent: 1,parent: 869,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 871,indent: 1,parent: 869,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.50",potSizeToWin: "4.75",amountToPot: "73",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 872,indent: 1,parent: 869,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.50",potSizeToWin: "15.25",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "7.00",boardCards: "",
},
{
id: 873,indent: 1,parent: 869,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "18.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 874,indent: 1,parent: 869,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "CheckRaise",amount: "10.00",potSizeToWin: "22.75",amountToPot: "43",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "4.00",boardCards: "",
},
{
id: 875,indent: 0,parent: null,handNum: "375",wonOrLost: "0.00",startAmt: "226.01",endAmt: "226.01",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 876,indent: 1,parent: 875,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 877,indent: 0,parent: null,handNum: "376",wonOrLost: "-1.81",startAmt: "226.01",endAmt: "224.20",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 878,indent: 1,parent: 877,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 879,indent: 1,parent: 877,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.31",potSizeToWin: "4.62",amountToPot: "28",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.81",boardCards: "",
},
{
id: 880,indent: 1,parent: 877,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.24",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 881,indent: 1,parent: 877,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "14.48",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.62",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 882,indent: 0,parent: null,handNum: "377",wonOrLost: "-0.25",startAmt: "224.20",endAmt: "223.95",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 883,indent: 1,parent: 882,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 884,indent: 1,parent: 882,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 885,indent: 0,parent: null,handNum: "378",wonOrLost: "0.00",startAmt: "223.95",endAmt: "223.95",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 886,indent: 1,parent: 885,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 887,indent: 0,parent: null,handNum: "379",wonOrLost: "0.00",startAmt: "223.95",endAmt: "223.95",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 888,indent: 1,parent: 887,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 889,indent: 0,parent: null,handNum: "380",wonOrLost: "0.00",startAmt: "223.95",endAmt: "223.95",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 890,indent: 1,parent: 889,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 891,indent: 0,parent: null,handNum: "381",wonOrLost: "0.00",startAmt: "223.95",endAmt: "223.95",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 892,indent: 1,parent: 891,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 893,indent: 0,parent: null,handNum: "382",wonOrLost: "0.00",startAmt: "223.95",endAmt: "223.95",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 894,indent: 1,parent: 893,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 895,indent: 0,parent: null,handNum: "383",wonOrLost: "0.00",startAmt: "223.95",endAmt: "223.95",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 896,indent: 1,parent: 895,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 897,indent: 0,parent: null,handNum: "384",wonOrLost: "-0.50",startAmt: "223.95",endAmt: "223.45",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 898,indent: 1,parent: 897,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 899,indent: 1,parent: 897,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 900,indent: 0,parent: null,handNum: "385",wonOrLost: "-0.25",startAmt: "223.45",endAmt: "223.20",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 901,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 902,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 903,indent: 0,parent: null,handNum: "386",wonOrLost: "0.00",startAmt: "223.20",endAmt: "223.20",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 904,indent: 1,parent: 903,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 905,indent: 0,parent: null,handNum: "387",wonOrLost: "0.00",startAmt: "223.20",endAmt: "223.20",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 906,indent: 1,parent: 905,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 907,indent: 0,parent: null,handNum: "388",wonOrLost: "-0.50",startAmt: "223.20",endAmt: "222.70",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 908,indent: 1,parent: 907,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 909,indent: 1,parent: 907,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "3.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 910,indent: 0,parent: null,handNum: "389",wonOrLost: "0.00",startAmt: "222.70",endAmt: "222.70",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 911,indent: 1,parent: 910,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 912,indent: 0,parent: null,handNum: "390",wonOrLost: "-14.93",startAmt: "222.70",endAmt: "207.77",finalHand: "",position: "MP1 (4 of 8)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 913,indent: 1,parent: 912,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 914,indent: 1,parent: 912,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.75",potSizeToWin: "4.75",amountToPot: "78",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 915,indent: 1,parent: 912,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "12.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 916,indent: 1,parent: 912,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "9.18",potSizeToWin: "21.43",amountToPot: "42",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "9.18",boardCards: "",
},
{
id: 917,indent: 1,parent: 912,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "30.61",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 918,indent: 0,parent: null,handNum: "391",wonOrLost: "0.00",startAmt: "207.77",endAmt: "207.77",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 919,indent: 1,parent: 918,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 920,indent: 0,parent: null,handNum: "392",wonOrLost: "-0.50",startAmt: "207.77",endAmt: "207.27",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 921,indent: 1,parent: 920,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 922,indent: 1,parent: 920,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 923,indent: 0,parent: null,handNum: "393",wonOrLost: "-0.50",startAmt: "207.27",endAmt: "206.77",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 924,indent: 1,parent: 923,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 925,indent: 1,parent: 923,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 926,indent: 1,parent: 923,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 927,indent: 1,parent: 923,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 928,indent: 0,parent: null,handNum: "394",wonOrLost: "0.00",startAmt: "206.77",endAmt: "206.77",finalHand: "",position: "Dealer (8 of 8)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 929,indent: 1,parent: 928,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "2.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 930,indent: 0,parent: null,handNum: "395",wonOrLost: "0.00",startAmt: "206.77",endAmt: "206.77",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 931,indent: 1,parent: 930,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 932,indent: 0,parent: null,handNum: "396",wonOrLost: "0.00",startAmt: "206.77",endAmt: "206.77",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 933,indent: 1,parent: 932,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.75",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 934,indent: 0,parent: null,handNum: "397",wonOrLost: "0.00",startAmt: "206.77",endAmt: "206.77",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 935,indent: 1,parent: 934,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 936,indent: 0,parent: null,handNum: "398",wonOrLost: "0.00",startAmt: "206.77",endAmt: "206.77",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 937,indent: 1,parent: 936,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 938,indent: 0,parent: null,handNum: "399",wonOrLost: "0.00",startAmt: "206.77",endAmt: "206.77",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 939,indent: 1,parent: 938,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 940,indent: 0,parent: null,handNum: "400",wonOrLost: "-2.00",startAmt: "206.77",endAmt: "204.77",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 941,indent: 1,parent: 940,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 942,indent: 1,parent: 940,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 943,indent: 1,parent: 940,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 944,indent: 1,parent: 940,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "4.75",amountToPot: "31",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 945,indent: 1,parent: 940,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.56",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Jeff",lastActionAmount: "7.31",boardCards: "",
},
{
id: 946,indent: 0,parent: null,handNum: "401",wonOrLost: "-0.25",startAmt: "204.77",endAmt: "204.52",finalHand: "",position: "SB (1 of 8)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 947,indent: 1,parent: 946,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 948,indent: 1,parent: 946,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "9.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "5.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 949,indent: 0,parent: null,handNum: "402",wonOrLost: "-1.50",startAmt: "204.52",endAmt: "203.02",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 950,indent: 1,parent: 949,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 951,indent: 1,parent: 949,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.25",boardCards: "",
},
{
id: 952,indent: 1,parent: 949,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.20",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.20",boardCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, [9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 953,indent: 0,parent: null,handNum: "403",wonOrLost: "0.00",startAmt: "203.02",endAmt: "203.02",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 954,indent: 1,parent: 953,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "3.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 955,indent: 0,parent: null,handNum: "404",wonOrLost: "0.00",startAmt: "203.02",endAmt: "203.02",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 956,indent: 1,parent: 955,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "4.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 957,indent: 0,parent: null,handNum: "405",wonOrLost: "0.00",startAmt: "203.02",endAmt: "203.02",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 958,indent: 1,parent: 957,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 959,indent: 0,parent: null,handNum: "406",wonOrLost: "44.25",startAmt: "203.02",endAmt: "227.27",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 960,indent: 1,parent: 959,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 961,indent: 1,parent: 959,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "6.00",potSizeToWin: "8.25",amountToPot: "72",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 962,indent: 1,parent: 959,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "12.00",potSizeToWin: "20.25",amountToPot: "59",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 963,indent: 1,parent: 959,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "12.00",potSizeToWin: "44.25",amountToPot: "27",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 964,indent: 0,parent: null,handNum: "407",wonOrLost: "-0.50",startAmt: "227.27",endAmt: "226.77",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 965,indent: 1,parent: 964,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 966,indent: 1,parent: 964,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 967,indent: 0,parent: null,handNum: "408",wonOrLost: "-1.75",startAmt: "226.77",endAmt: "225.02",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 968,indent: 1,parent: 967,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 969,indent: 1,parent: 967,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.75",boardCards: "",
},
{
id: 970,indent: 1,parent: 967,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 971,indent: 1,parent: 967,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 972,indent: 0,parent: null,handNum: "409",wonOrLost: "0.00",startAmt: "225.02",endAmt: "225.02",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 973,indent: 1,parent: 972,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 974,indent: 0,parent: null,handNum: "410",wonOrLost: "0.00",startAmt: "225.02",endAmt: "225.02",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 975,indent: 1,parent: 974,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "3.00",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 976,indent: 0,parent: null,handNum: "411",wonOrLost: "0.00",startAmt: "225.02",endAmt: "225.02",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 977,indent: 1,parent: 976,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 978,indent: 0,parent: null,handNum: "412",wonOrLost: "0.00",startAmt: "225.02",endAmt: "225.02",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 979,indent: 1,parent: 978,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 980,indent: 0,parent: null,handNum: "413",wonOrLost: "0.00",startAmt: "225.02",endAmt: "225.02",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 981,indent: 1,parent: 980,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 982,indent: 0,parent: null,handNum: "414",wonOrLost: "-0.50",startAmt: "225.02",endAmt: "224.52",finalHand: "",position: "BB (2 of 7)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 983,indent: 1,parent: 982,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 984,indent: 1,parent: 982,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "",
},
{
id: 985,indent: 0,parent: null,handNum: "415",wonOrLost: "-0.50",startAmt: "224.52",endAmt: "224.02",finalHand: "",position: "SB (1 of 7)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 986,indent: 1,parent: 985,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 987,indent: 1,parent: 985,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 988,indent: 1,parent: 985,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 989,indent: 1,parent: 985,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 990,indent: 1,parent: 985,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 991,indent: 0,parent: null,handNum: "416",wonOrLost: "0.00",startAmt: "224.02",endAmt: "224.02",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 992,indent: 1,parent: 991,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 993,indent: 0,parent: null,handNum: "417",wonOrLost: "0.00",startAmt: "224.02",endAmt: "224.02",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 994,indent: 1,parent: 993,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 995,indent: 0,parent: null,handNum: "418",wonOrLost: "0.00",startAmt: "224.02",endAmt: "224.02",finalHand: "",position: "Hijack (5 of 7)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 996,indent: 1,parent: 995,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 997,indent: 0,parent: null,handNum: "419",wonOrLost: "0.00",startAmt: "224.02",endAmt: "224.02",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 998,indent: 1,parent: 997,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 999,indent: 0,parent: null,handNum: "420",wonOrLost: "0.00",startAmt: "224.02",endAmt: "224.02",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1000,indent: 1,parent: 999,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1001,indent: 0,parent: null,handNum: "421",wonOrLost: "-1.00",startAmt: "224.02",endAmt: "223.02",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1002,indent: 1,parent: 1001,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1003,indent: 1,parent: 1001,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "0.75",boardCards: "",
},
{
id: 1004,indent: 1,parent: 1001,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.25",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1005,indent: 0,parent: null,handNum: "422",wonOrLost: "-0.25",startAmt: "223.02",endAmt: "222.77",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1006,indent: 1,parent: 1005,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1007,indent: 1,parent: 1005,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1008,indent: 0,parent: null,handNum: "423",wonOrLost: "5.00",startAmt: "222.77",endAmt: "225.77",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1009,indent: 1,parent: 1008,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1010,indent: 1,parent: 1008,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.50",potSizeToWin: "5.00",amountToPot: "70",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1011,indent: 0,parent: null,handNum: "424",wonOrLost: "-1.00",startAmt: "225.77",endAmt: "224.77",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1012,indent: 1,parent: 1011,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "1.75",amountToPot: "57",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "",
},
{
id: 1013,indent: 1,parent: 1011,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.37",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.12",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, [2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1014,indent: 0,parent: null,handNum: "425",wonOrLost: "-0.50",startAmt: "224.77",endAmt: "224.27",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1015,indent: 1,parent: 1014,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1016,indent: 1,parent: 1014,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, [7<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1017,indent: 0,parent: null,handNum: "426",wonOrLost: "-2.00",startAmt: "224.27",endAmt: "222.27",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1018,indent: 1,parent: 1017,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1019,indent: 1,parent: 1017,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "11.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "6.00",boardCards: "",
},
{
id: 1020,indent: 0,parent: null,handNum: "427",wonOrLost: "0.00",startAmt: "222.27",endAmt: "222.27",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1021,indent: 1,parent: 1020,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1022,indent: 0,parent: null,handNum: "428",wonOrLost: "-0.50",startAmt: "222.27",endAmt: "221.77",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1023,indent: 1,parent: 1022,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1024,indent: 1,parent: 1022,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1025,indent: 0,parent: null,handNum: "429",wonOrLost: "9.00",startAmt: "221.77",endAmt: "228.27",finalHand: "",position: "SB (1 of 7)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1026,indent: 1,parent: 1025,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1027,indent: 1,parent: 1025,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "3.75",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1028,indent: 1,parent: 1025,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1029,indent: 1,parent: 1025,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "CheckRaise",amount: "4.00",potSizeToWin: "8.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.00",boardCards: "",
},
{
id: 1030,indent: 0,parent: null,handNum: "430",wonOrLost: "-1.50",startAmt: "228.27",endAmt: "226.77",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1031,indent: 1,parent: 1030,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1032,indent: 1,parent: 1030,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "5.50",boardCards: "",
},
{
id: 1033,indent: 0,parent: null,handNum: "431",wonOrLost: "0.00",startAmt: "226.77",endAmt: "226.77",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1034,indent: 1,parent: 1033,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "",
},
{
id: 1035,indent: 0,parent: null,handNum: "432",wonOrLost: "6.50",startAmt: "226.77",endAmt: "231.27",finalHand: "",position: "Hijack (5 of 7)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1036,indent: 1,parent: 1035,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1037,indent: 1,parent: 1035,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "4.00",potSizeToWin: "6.50",amountToPot: "61",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1038,indent: 0,parent: null,handNum: "433",wonOrLost: "0.00",startAmt: "231.27",endAmt: "231.27",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1039,indent: 1,parent: 1038,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1040,indent: 0,parent: null,handNum: "434",wonOrLost: "0.00",startAmt: "231.27",endAmt: "231.27",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1041,indent: 1,parent: 1040,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1042,indent: 0,parent: null,handNum: "435",wonOrLost: "-1.50",startAmt: "231.27",endAmt: "229.77",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1043,indent: 1,parent: 1042,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1044,indent: 1,parent: 1042,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1045,indent: 1,parent: 1042,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.25",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, [J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1046,indent: 0,parent: null,handNum: "436",wonOrLost: "18.00",startAmt: "229.77",endAmt: "241.27",finalHand: "Pair, A's",position: "SB (1 of 7)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1047,indent: 1,parent: 1046,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1048,indent: 1,parent: 1046,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1049,indent: 1,parent: 1046,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "5.00",amountToPot: "20",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 1050,indent: 1,parent: 1046,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1051,indent: 1,parent: 1046,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "8.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 1052,indent: 1,parent: 1046,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1053,indent: 1,parent: 1046,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1054,indent: 1,parent: 1046,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.00",potSizeToWin: "15.00",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "3.00",boardCards: "",
},
{
id: 1055,indent: 0,parent: null,handNum: "437",wonOrLost: "-0.50",startAmt: "241.27",endAmt: "240.77",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1056,indent: 1,parent: 1055,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1057,indent: 1,parent: 1055,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1058,indent: 0,parent: null,handNum: "438",wonOrLost: "1.25",startAmt: "240.77",endAmt: "241.52",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1059,indent: 1,parent: 1058,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1060,indent: 0,parent: null,handNum: "439",wonOrLost: "0.00",startAmt: "241.52",endAmt: "241.52",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1061,indent: 1,parent: 1060,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1062,indent: 0,parent: null,handNum: "440",wonOrLost: "0.00",startAmt: "241.52",endAmt: "241.52",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1063,indent: 1,parent: 1062,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1064,indent: 0,parent: null,handNum: "441",wonOrLost: "0.00",startAmt: "241.52",endAmt: "241.52",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1065,indent: 1,parent: 1064,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1066,indent: 0,parent: null,handNum: "442",wonOrLost: "-0.50",startAmt: "241.52",endAmt: "241.02",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1067,indent: 1,parent: 1066,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1068,indent: 1,parent: 1066,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1069,indent: 0,parent: null,handNum: "443",wonOrLost: "-1.50",startAmt: "241.02",endAmt: "239.52",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1070,indent: 1,parent: 1069,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1071,indent: 1,parent: 1069,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "4.25",amountToPot: "29",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1072,indent: 1,parent: 1069,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1073,indent: 1,parent: 1069,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1074,indent: 0,parent: null,handNum: "444",wonOrLost: "0.00",startAmt: "239.52",endAmt: "239.52",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1075,indent: 1,parent: 1074,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1076,indent: 0,parent: null,handNum: "445",wonOrLost: "0.00",startAmt: "239.52",endAmt: "239.52",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1077,indent: 1,parent: 1076,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1078,indent: 0,parent: null,handNum: "446",wonOrLost: "0.00",startAmt: "239.52",endAmt: "239.52",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1079,indent: 1,parent: 1078,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1080,indent: 0,parent: null,handNum: "447",wonOrLost: "0.00",startAmt: "239.52",endAmt: "239.52",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1081,indent: 1,parent: 1080,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1082,indent: 0,parent: null,handNum: "448",wonOrLost: "11.25",startAmt: "239.52",endAmt: "246.77",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1083,indent: 1,parent: 1082,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1084,indent: 1,parent: 1082,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "7.25",amountToPot: "13",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1085,indent: 1,parent: 1082,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "6.00",potSizeToWin: "10.25",amountToPot: "58",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1086,indent: 0,parent: null,handNum: "449",wonOrLost: "-0.50",startAmt: "246.77",endAmt: "246.27",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1087,indent: 1,parent: 1086,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1088,indent: 1,parent: 1086,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1089,indent: 1,parent: 1086,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1090,indent: 1,parent: 1086,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.37",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.87",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1091,indent: 0,parent: null,handNum: "450",wonOrLost: "-0.25",startAmt: "246.27",endAmt: "246.02",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1092,indent: 1,parent: 1091,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1093,indent: 1,parent: 1091,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1094,indent: 0,parent: null,handNum: "451",wonOrLost: "0.00",startAmt: "246.02",endAmt: "246.02",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1095,indent: 1,parent: 1094,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 1096,indent: 0,parent: null,handNum: "452",wonOrLost: "0.00",startAmt: "246.02",endAmt: "246.02",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1097,indent: 1,parent: 1096,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1098,indent: 0,parent: null,handNum: "453",wonOrLost: "-0.50",startAmt: "246.02",endAmt: "245.52",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1099,indent: 1,parent: 1098,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1100,indent: 1,parent: 1098,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1101,indent: 0,parent: null,handNum: "454",wonOrLost: "-0.50",startAmt: "245.52",endAmt: "245.02",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1102,indent: 1,parent: 1101,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1103,indent: 1,parent: 1101,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "1.75",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1104,indent: 0,parent: null,handNum: "455",wonOrLost: "4.50",startAmt: "245.02",endAmt: "247.52",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1105,indent: 1,parent: 1104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1106,indent: 1,parent: 1104,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.00",potSizeToWin: "4.50",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1107,indent: 0,parent: null,handNum: "456",wonOrLost: "-2.00",startAmt: "247.52",endAmt: "245.52",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1108,indent: 1,parent: 1107,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1109,indent: 1,parent: 1107,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.25",amountToPot: "28",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 1110,indent: 1,parent: 1107,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1111,indent: 1,parent: 1107,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "14.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "3.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1112,indent: 0,parent: null,handNum: "457",wonOrLost: "-0.50",startAmt: "245.52",endAmt: "245.02",finalHand: "",position: "SB (1 of 7)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1113,indent: 1,parent: 1112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1114,indent: 1,parent: 1112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1115,indent: 1,parent: 1112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1116,indent: 1,parent: 1112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1117,indent: 1,parent: 1112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1118,indent: 0,parent: null,handNum: "458",wonOrLost: "0.00",startAmt: "245.02",endAmt: "245.02",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1119,indent: 1,parent: 1118,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1120,indent: 0,parent: null,handNum: "459",wonOrLost: "0.00",startAmt: "245.02",endAmt: "245.02",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1121,indent: 1,parent: 1120,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1122,indent: 0,parent: null,handNum: "460",wonOrLost: "0.00",startAmt: "245.02",endAmt: "245.02",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1123,indent: 1,parent: 1122,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1124,indent: 0,parent: null,handNum: "461",wonOrLost: "-0.50",startAmt: "245.02",endAmt: "244.52",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1125,indent: 1,parent: 1124,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1126,indent: 1,parent: 1124,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1127,indent: 0,parent: null,handNum: "462",wonOrLost: "-0.25",startAmt: "244.52",endAmt: "244.27",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1128,indent: 1,parent: 1127,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1129,indent: 1,parent: 1127,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1130,indent: 0,parent: null,handNum: "463",wonOrLost: "0.00",startAmt: "244.27",endAmt: "244.27",finalHand: "",position: "Dealer (5 of 5)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1131,indent: 1,parent: 1130,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1132,indent: 0,parent: null,handNum: "464",wonOrLost: "0.00",startAmt: "244.27",endAmt: "244.27",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1133,indent: 1,parent: 1132,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1134,indent: 0,parent: null,handNum: "465",wonOrLost: "0.00",startAmt: "244.27",endAmt: "244.27",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1135,indent: 1,parent: 1134,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1136,indent: 0,parent: null,handNum: "466",wonOrLost: "-0.50",startAmt: "244.27",endAmt: "243.77",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1137,indent: 1,parent: 1136,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1138,indent: 1,parent: 1136,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1139,indent: 0,parent: null,handNum: "467",wonOrLost: "2.00",startAmt: "243.77",endAmt: "245.27",finalHand: "",position: "SB (1 of 5)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1140,indent: 1,parent: 1139,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1141,indent: 1,parent: 1139,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.25",potSizeToWin: "1.75",amountToPot: "128",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1142,indent: 0,parent: null,handNum: "468",wonOrLost: "1.75",startAmt: "245.27",endAmt: "246.52",finalHand: "",position: "Dealer (5 of 5)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1143,indent: 1,parent: 1142,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1144,indent: 0,parent: null,handNum: "469",wonOrLost: "3.50",startAmt: "246.52",endAmt: "248.52",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1145,indent: 1,parent: 1144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1146,indent: 1,parent: 1144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.75",potSizeToWin: "3.50",amountToPot: "78",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1147,indent: 0,parent: null,handNum: "470",wonOrLost: "-1.50",startAmt: "248.52",endAmt: "247.02",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1148,indent: 1,parent: 1147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1149,indent: 1,parent: 1147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Chris Moy",lastActionAmount: "4.25",boardCards: "",
},
{
id: 1150,indent: 0,parent: null,handNum: "471",wonOrLost: "-0.50",startAmt: "247.02",endAmt: "246.52",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1151,indent: 1,parent: 1150,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1152,indent: 1,parent: 1150,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.75",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1153,indent: 0,parent: null,handNum: "472",wonOrLost: "1.00",startAmt: "246.52",endAmt: "247.02",finalHand: "Pair, 6's",position: "SB (1 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1154,indent: 1,parent: 1153,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1155,indent: 1,parent: 1153,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1156,indent: 1,parent: 1153,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1157,indent: 1,parent: 1153,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1158,indent: 1,parent: 1153,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1159,indent: 0,parent: null,handNum: "473",wonOrLost: "0.00",startAmt: "247.02",endAmt: "247.02",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1160,indent: 1,parent: 1159,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1161,indent: 0,parent: null,handNum: "474",wonOrLost: "5.75",startAmt: "247.02",endAmt: "250.27",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1162,indent: 1,parent: 1161,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1163,indent: 1,parent: 1161,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.75",amountToPot: "21",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "2.50",boardCards: "",
},
{
id: 1164,indent: 1,parent: 1161,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1165,indent: 1,parent: 1161,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.00",potSizeToWin: "5.75",amountToPot: "52",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1166,indent: 0,parent: null,handNum: "475",wonOrLost: "0.00",startAmt: "250.27",endAmt: "250.27",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1167,indent: 1,parent: 1166,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1168,indent: 0,parent: null,handNum: "476",wonOrLost: "111.75",startAmt: "250.27",endAmt: "311.52",finalHand: "Flush, Ah High",position: "BB (2 of 5)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1169,indent: 1,parent: 1168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1170,indent: 1,parent: 1168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1171,indent: 1,parent: 1168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.25",potSizeToWin: "1.75",amountToPot: "71",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1172,indent: 1,parent: 1168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "8.00",amountToPot: "31",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "3.75",boardCards: "",
},
{
id: 1173,indent: 1,parent: 1168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "6.25",potSizeToWin: "25.50",amountToPot: "24",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "8.75",boardCards: "",
},
{
id: 1174,indent: 1,parent: 1168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "31.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1175,indent: 1,parent: 1168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "10.00",potSizeToWin: "41.75",amountToPot: "23",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "10.00",boardCards: "",
},
{
id: 1176,indent: 1,parent: 1168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "30.00",potSizeToWin: "51.75",amountToPot: "57",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1177,indent: 0,parent: null,handNum: "477",wonOrLost: "-2.00",startAmt: "311.52",endAmt: "309.52",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1178,indent: 1,parent: 1177,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1179,indent: 1,parent: 1177,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.75",potSizeToWin: "1.25",amountToPot: "140",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1180,indent: 1,parent: 1177,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1181,indent: 1,parent: 1177,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.50",boardCards: "",
},
{
id: 1182,indent: 0,parent: null,handNum: "478",wonOrLost: "0.00",startAmt: "309.52",endAmt: "309.52",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1183,indent: 1,parent: 1182,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1184,indent: 0,parent: null,handNum: "479",wonOrLost: "-3.00",startAmt: "309.52",endAmt: "306.52",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1185,indent: 1,parent: 1184,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1186,indent: 1,parent: 1184,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "8.25",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "3.00",boardCards: "",
},
{
id: 1187,indent: 1,parent: 1184,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "9.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1188,indent: 1,parent: 1184,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "14.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "5.00",boardCards: "",
},
{
id: 1189,indent: 0,parent: null,handNum: "480",wonOrLost: "0.00",startAmt: "306.52",endAmt: "306.52",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1190,indent: 1,parent: 1189,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1191,indent: 0,parent: null,handNum: "481",wonOrLost: "-0.50",startAmt: "306.52",endAmt: "306.02",finalHand: "",position: "BB (2 of 5)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1192,indent: 1,parent: 1191,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1193,indent: 1,parent: 1191,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1194,indent: 1,parent: 1191,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1195,indent: 0,parent: null,handNum: "482",wonOrLost: "-0.25",startAmt: "306.02",endAmt: "305.77",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1196,indent: 1,parent: 1195,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1197,indent: 1,parent: 1195,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1198,indent: 0,parent: null,handNum: "483",wonOrLost: "0.00",startAmt: "305.77",endAmt: "305.77",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1199,indent: 1,parent: 1198,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1200,indent: 0,parent: null,handNum: "484",wonOrLost: "-10.50",startAmt: "305.77",endAmt: "295.27",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1201,indent: 1,parent: 1200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1202,indent: 1,parent: 1200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.50",potSizeToWin: "3.75",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1203,indent: 1,parent: 1200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "11.25",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "5.00",boardCards: "",
},
{
id: 1204,indent: 1,parent: 1200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "13.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1205,indent: 1,parent: 1200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "4.00",potSizeToWin: "17.75",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "4.00",boardCards: "",
},
{
id: 1206,indent: 1,parent: 1200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "21.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1207,indent: 0,parent: null,handNum: "485",wonOrLost: "0.00",startAmt: "295.27",endAmt: "295.27",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1208,indent: 1,parent: 1207,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1209,indent: 0,parent: null,handNum: "486",wonOrLost: "-0.50",startAmt: "295.27",endAmt: "294.77",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1210,indent: 1,parent: 1209,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1211,indent: 1,parent: 1209,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1212,indent: 1,parent: 1209,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1213,indent: 1,parent: 1209,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.00",boardCards: "",
},
{
id: 1214,indent: 0,parent: null,handNum: "487",wonOrLost: "-0.50",startAmt: "294.77",endAmt: "294.27",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1215,indent: 1,parent: 1214,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1216,indent: 1,parent: 1214,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1217,indent: 1,parent: 1214,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1218,indent: 1,parent: 1214,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1219,indent: 0,parent: null,handNum: "488",wonOrLost: "0.00",startAmt: "294.27",endAmt: "294.27",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1220,indent: 1,parent: 1219,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1221,indent: 0,parent: null,handNum: "489",wonOrLost: "0.00",startAmt: "294.27",endAmt: "294.27",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1222,indent: 1,parent: 1221,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1223,indent: 0,parent: null,handNum: "490",wonOrLost: "0.00",startAmt: "294.27",endAmt: "294.27",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1224,indent: 1,parent: 1223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1225,indent: 0,parent: null,handNum: "491",wonOrLost: "-0.50",startAmt: "294.27",endAmt: "293.77",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1226,indent: 1,parent: 1225,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1227,indent: 1,parent: 1225,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1228,indent: 0,parent: null,handNum: "492",wonOrLost: "-0.25",startAmt: "293.77",endAmt: "293.52",finalHand: "",position: "SB (1 of 5)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1229,indent: 1,parent: 1228,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1230,indent: 1,parent: 1228,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1231,indent: 0,parent: null,handNum: "493",wonOrLost: "-0.50",startAmt: "293.52",endAmt: "293.02",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1232,indent: 1,parent: 1231,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1233,indent: 1,parent: 1231,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, [3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1234,indent: 0,parent: null,handNum: "494",wonOrLost: "0.00",startAmt: "293.02",endAmt: "293.02",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1235,indent: 1,parent: 1234,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1236,indent: 0,parent: null,handNum: "495",wonOrLost: "0.00",startAmt: "293.02",endAmt: "293.02",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1237,indent: 1,parent: 1236,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1238,indent: 0,parent: null,handNum: "496",wonOrLost: "-0.50",startAmt: "293.02",endAmt: "292.52",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1239,indent: 1,parent: 1238,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1240,indent: 1,parent: 1238,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1241,indent: 0,parent: null,handNum: "497",wonOrLost: "-0.25",startAmt: "292.52",endAmt: "292.27",finalHand: "",position: "SB (1 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1242,indent: 1,parent: 1241,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1243,indent: 1,parent: 1241,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "3.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1244,indent: 0,parent: null,handNum: "498",wonOrLost: "18.50",startAmt: "292.27",endAmt: "305.27",finalHand: "",position: "Dealer (5 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1245,indent: 1,parent: 1244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1246,indent: 1,parent: 1244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "8.50",amountToPot: "29",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1247,indent: 1,parent: 1244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.50",potSizeToWin: "16.00",amountToPot: "15",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1248,indent: 1,parent: 1244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "10.00",potSizeToWin: "18.50",amountToPot: "54",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1249,indent: 0,parent: null,handNum: "499",wonOrLost: "-1.50",startAmt: "305.27",endAmt: "303.77",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1250,indent: 1,parent: 1249,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.00",amountToPot: "75",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1251,indent: 1,parent: 1249,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1252,indent: 0,parent: null,handNum: "500",wonOrLost: "0.00",startAmt: "303.77",endAmt: "303.77",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1253,indent: 1,parent: 1252,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1254,indent: 0,parent: null,handNum: "501",wonOrLost: "-0.50",startAmt: "303.77",endAmt: "303.27",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1255,indent: 1,parent: 1254,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1256,indent: 1,parent: 1254,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1257,indent: 1,parent: 1254,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1258,indent: 1,parent: 1254,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1259,indent: 0,parent: null,handNum: "502",wonOrLost: "-0.50",startAmt: "303.27",endAmt: "302.77",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1260,indent: 1,parent: 1259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1261,indent: 1,parent: 1259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1262,indent: 1,parent: 1259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1263,indent: 1,parent: 1259,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1264,indent: 0,parent: null,handNum: "503",wonOrLost: "-1.00",startAmt: "302.77",endAmt: "301.77",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1265,indent: 1,parent: 1264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1266,indent: 1,parent: 1264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1267,indent: 1,parent: 1264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1268,indent: 0,parent: null,handNum: "504",wonOrLost: "0.00",startAmt: "301.77",endAmt: "301.77",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1269,indent: 1,parent: 1268,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1270,indent: 0,parent: null,handNum: "505",wonOrLost: "4.50",startAmt: "301.77",endAmt: "304.52",finalHand: "Two Pair, A's & 6's",position: "BB (2 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1271,indent: 1,parent: 1270,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1272,indent: 1,parent: 1270,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1273,indent: 1,parent: 1270,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1274,indent: 1,parent: 1270,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.25",potSizeToWin: "2.00",amountToPot: "62",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1275,indent: 1,parent: 1270,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1276,indent: 0,parent: null,handNum: "506",wonOrLost: "-0.25",startAmt: "304.52",endAmt: "304.27",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1277,indent: 1,parent: 1276,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1278,indent: 1,parent: 1276,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1279,indent: 0,parent: null,handNum: "507",wonOrLost: "0.00",startAmt: "304.27",endAmt: "304.27",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1280,indent: 1,parent: 1279,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1281,indent: 0,parent: null,handNum: "508",wonOrLost: "0.00",startAmt: "304.27",endAmt: "304.27",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1282,indent: 1,parent: 1281,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1283,indent: 0,parent: null,handNum: "509",wonOrLost: "4.50",startAmt: "304.27",endAmt: "307.02",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1284,indent: 1,parent: 1283,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1285,indent: 1,parent: 1283,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1286,indent: 1,parent: 1283,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.25",potSizeToWin: "2.00",amountToPot: "62",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1287,indent: 1,parent: 1283,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.00",potSizeToWin: "4.50",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1288,indent: 0,parent: null,handNum: "510",wonOrLost: "-0.50",startAmt: "307.02",endAmt: "306.52",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1289,indent: 1,parent: 1288,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1290,indent: 1,parent: 1288,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1291,indent: 1,parent: 1288,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1292,indent: 1,parent: 1288,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "",
},
{
id: 1293,indent: 0,parent: null,handNum: "511",wonOrLost: "0.00",startAmt: "306.52",endAmt: "306.52",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1294,indent: 1,parent: 1293,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1295,indent: 0,parent: null,handNum: "512",wonOrLost: "0.00",startAmt: "306.52",endAmt: "306.52",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1296,indent: 1,parent: 1295,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1297,indent: 0,parent: null,handNum: "513",wonOrLost: "-0.50",startAmt: "306.52",endAmt: "306.02",finalHand: "",position: "BB (2 of 4)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1298,indent: 1,parent: 1297,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1299,indent: 1,parent: 1297,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1300,indent: 1,parent: 1297,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1301,indent: 0,parent: null,handNum: "514",wonOrLost: "-0.25",startAmt: "306.02",endAmt: "305.77",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1302,indent: 1,parent: 1301,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1303,indent: 1,parent: 1301,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1304,indent: 0,parent: null,handNum: "515",wonOrLost: "-14.37",startAmt: "305.77",endAmt: "291.40",finalHand: "",position: "Dealer (4 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1305,indent: 1,parent: 1304,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1306,indent: 1,parent: 1304,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.25",potSizeToWin: "6.75",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.25",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1307,indent: 1,parent: 1304,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "5.62",potSizeToWin: "16.87",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.62",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1308,indent: 1,parent: 1304,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "5.00",potSizeToWin: "27.49",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "5.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1309,indent: 0,parent: null,handNum: "516",wonOrLost: "1.25",startAmt: "291.40",endAmt: "292.15",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1310,indent: 1,parent: 1309,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1311,indent: 0,parent: null,handNum: "517",wonOrLost: "-0.50",startAmt: "292.15",endAmt: "291.65",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1312,indent: 1,parent: 1311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1313,indent: 1,parent: 1311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1314,indent: 1,parent: 1311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1315,indent: 1,parent: 1311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.75",boardCards: "",
},
{
id: 1316,indent: 0,parent: null,handNum: "518",wonOrLost: "-1.50",startAmt: "291.65",endAmt: "290.15",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1317,indent: 1,parent: 1316,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1318,indent: 1,parent: 1316,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "2.25",amountToPot: "55",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1319,indent: 1,parent: 1316,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1320,indent: 1,parent: 1316,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.75",boardCards: "",
},
{
id: 1321,indent: 0,parent: null,handNum: "519",wonOrLost: "3.50",startAmt: "290.15",endAmt: "292.15",finalHand: "",position: "Dealer (4 of 4)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1322,indent: 1,parent: 1321,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1323,indent: 1,parent: 1321,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.50",potSizeToWin: "3.50",amountToPot: "71",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1324,indent: 0,parent: null,handNum: "520",wonOrLost: "0.00",startAmt: "292.15",endAmt: "292.15",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1325,indent: 1,parent: 1324,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1326,indent: 0,parent: null,handNum: "521",wonOrLost: "-0.50",startAmt: "292.15",endAmt: "291.65",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1327,indent: 1,parent: 1326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1328,indent: 1,parent: 1326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1329,indent: 1,parent: 1326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1330,indent: 1,parent: 1326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1331,indent: 0,parent: null,handNum: "522",wonOrLost: "5.00",startAmt: "291.65",endAmt: "295.15",finalHand: "",position: "SB (1 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1332,indent: 1,parent: 1331,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1333,indent: 1,parent: 1331,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "4.75",potSizeToWin: "3.75",amountToPot: "126",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1334,indent: 0,parent: null,handNum: "523",wonOrLost: "0.00",startAmt: "295.15",endAmt: "295.15",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1335,indent: 1,parent: 1334,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1336,indent: 0,parent: null,handNum: "524",wonOrLost: "13.49",startAmt: "295.15",endAmt: "303.27",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1337,indent: 1,parent: 1336,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1338,indent: 1,parent: 1336,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "5.75",amountToPot: "17",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 1339,indent: 1,parent: 1336,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "7.00",potSizeToWin: "10.62",amountToPot: "65",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.87",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1340,indent: 0,parent: null,handNum: "525",wonOrLost: "-0.50",startAmt: "303.27",endAmt: "302.77",finalHand: "",position: "BB (2 of 4)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1341,indent: 1,parent: 1340,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1342,indent: 1,parent: 1340,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 1343,indent: 0,parent: null,handNum: "526",wonOrLost: "-1.25",startAmt: "302.77",endAmt: "301.52",finalHand: "",position: "SB (1 of 4)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1344,indent: 1,parent: 1343,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1345,indent: 1,parent: 1343,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1346,indent: 1,parent: 1343,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.75",potSizeToWin: "1.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1347,indent: 1,parent: 1343,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1348,indent: 1,parent: 1343,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1349,indent: 0,parent: null,handNum: "527",wonOrLost: "0.00",startAmt: "301.52",endAmt: "301.52",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1350,indent: 1,parent: 1349,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1351,indent: 0,parent: null,handNum: "528",wonOrLost: "-3.00",startAmt: "301.52",endAmt: "298.52",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1352,indent: 1,parent: 1351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1353,indent: 1,parent: 1351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "7.75",amountToPot: "19",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "3.00",boardCards: "",
},
{
id: 1354,indent: 1,parent: 1351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.87",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "4.62",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1355,indent: 0,parent: null,handNum: "529",wonOrLost: "14.25",startAmt: "298.52",endAmt: "306.52",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1356,indent: 1,parent: 1355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1357,indent: 1,parent: 1355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.75",amountToPot: "36",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1358,indent: 1,parent: 1355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1359,indent: 1,parent: 1355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "CheckRaise",amount: "10.00",potSizeToWin: "9.50",amountToPot: "105",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.75",boardCards: "",
},
{
id: 1360,indent: 0,parent: null,handNum: "530",wonOrLost: "1.00",startAmt: "306.52",endAmt: "307.02",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1361,indent: 1,parent: 1360,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1362,indent: 1,parent: 1360,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.25",potSizeToWin: "0.75",amountToPot: "166",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1363,indent: 0,parent: null,handNum: "531",wonOrLost: "-1.50",startAmt: "307.02",endAmt: "305.52",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1364,indent: 1,parent: 1363,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1365,indent: 1,parent: 1363,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.87",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.62",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1366,indent: 0,parent: null,handNum: "532",wonOrLost: "-7.50",startAmt: "305.52",endAmt: "298.02",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1367,indent: 1,parent: 1366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1368,indent: 1,parent: 1366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "7.00",amountToPot: "14",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "2.50",boardCards: "",
},
{
id: 1369,indent: 1,parent: 1366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "5.00",potSizeToWin: "8.50",amountToPot: "58",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1370,indent: 1,parent: 1366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "18.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1371,indent: 1,parent: 1366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "23.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "5.00",boardCards: "",
},
{
id: 1372,indent: 0,parent: null,handNum: "533",wonOrLost: "-0.50",startAmt: "298.02",endAmt: "297.52",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1373,indent: 1,parent: 1372,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1374,indent: 1,parent: 1372,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1375,indent: 0,parent: null,handNum: "534",wonOrLost: "-0.25",startAmt: "297.52",endAmt: "297.27",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1376,indent: 1,parent: 1375,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1377,indent: 1,parent: 1375,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1378,indent: 0,parent: null,handNum: "535",wonOrLost: "0.00",startAmt: "297.27",endAmt: "297.27",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1379,indent: 1,parent: 1378,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1380,indent: 0,parent: null,handNum: "536",wonOrLost: "1.25",startAmt: "297.27",endAmt: "298.02",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1381,indent: 1,parent: 1380,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1382,indent: 0,parent: null,handNum: "537",wonOrLost: "-0.50",startAmt: "298.02",endAmt: "297.52",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1383,indent: 1,parent: 1382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1384,indent: 1,parent: 1382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1385,indent: 0,parent: null,handNum: "538",wonOrLost: "-0.25",startAmt: "297.52",endAmt: "297.27",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1386,indent: 1,parent: 1385,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1387,indent: 1,parent: 1385,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1388,indent: 0,parent: null,handNum: "539",wonOrLost: "-4.75",startAmt: "297.27",endAmt: "292.52",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1389,indent: 1,parent: 1388,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1390,indent: 1,parent: 1388,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.25",potSizeToWin: "2.00",amountToPot: "62",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1391,indent: 1,parent: 1388,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.00",potSizeToWin: "4.50",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1392,indent: 1,parent: 1388,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "13.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "DanC",lastActionAmount: "6.00",boardCards: "",
},
{
id: 1393,indent: 0,parent: null,handNum: "540",wonOrLost: "0.00",startAmt: "292.52",endAmt: "292.52",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1394,indent: 1,parent: 1393,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1395,indent: 0,parent: null,handNum: "541",wonOrLost: "-0.50",startAmt: "292.52",endAmt: "292.02",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1396,indent: 1,parent: 1395,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1397,indent: 1,parent: 1395,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1398,indent: 1,parent: 1395,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1399,indent: 0,parent: null,handNum: "542",wonOrLost: "-0.50",startAmt: "292.02",endAmt: "291.52",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1400,indent: 1,parent: 1399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1401,indent: 1,parent: 1399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1402,indent: 1,parent: 1399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 1403,indent: 0,parent: null,handNum: "543",wonOrLost: "0.00",startAmt: "291.52",endAmt: "291.52",finalHand: "",position: "Dealer_UTG (3 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1404,indent: 1,parent: 1403,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1405,indent: 0,parent: null,handNum: "544",wonOrLost: "1.50",startAmt: "291.52",endAmt: "292.52",finalHand: "",position: "BB (2 of 3)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1406,indent: 1,parent: 1405,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1407,indent: 1,parent: 1405,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1408,indent: 1,parent: 1405,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.00",potSizeToWin: "1.50",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1409,indent: 0,parent: null,handNum: "545",wonOrLost: "9.50",startAmt: "292.52",endAmt: "297.52",finalHand: "",position: "SB (1 of 3)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1410,indent: 1,parent: 1409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1411,indent: 1,parent: 1409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "4.25",potSizeToWin: "2.25",amountToPot: "188",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1412,indent: 1,parent: 1409,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "6.00",potSizeToWin: "9.50",amountToPot: "63",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1413,indent: 0,parent: null,handNum: "546",wonOrLost: "-3.75",startAmt: "297.52",endAmt: "293.77",finalHand: "",position: "Dealer_UTG (3 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1414,indent: 1,parent: 1413,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1415,indent: 1,parent: 1413,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.25",potSizeToWin: "3.50",amountToPot: "64",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1416,indent: 1,parent: 1413,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "DanC",lastActionAmount: "4.50",boardCards: "",
},
{
id: 1417,indent: 0,parent: null,handNum: "547",wonOrLost: "-0.50",startAmt: "293.77",endAmt: "293.27",finalHand: "",position: "BB (2 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1418,indent: 1,parent: 1417,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1419,indent: 1,parent: 1417,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 1420,indent: 0,parent: null,handNum: "548",wonOrLost: "-0.50",startAmt: "293.27",endAmt: "292.77",finalHand: "",position: "SB (1 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1421,indent: 1,parent: 1420,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1422,indent: 1,parent: 1420,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1423,indent: 1,parent: 1420,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1424,indent: 1,parent: 1420,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1425,indent: 0,parent: null,handNum: "549",wonOrLost: "-1.00",startAmt: "292.77",endAmt: "291.77",finalHand: "",position: "Dealer_UTG (3 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1426,indent: 1,parent: 1425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1427,indent: 1,parent: 1425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.75",boardCards: "",
},
{
id: 1428,indent: 1,parent: 1425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1429,indent: 0,parent: null,handNum: "550",wonOrLost: "-2.50",startAmt: "291.77",endAmt: "289.27",finalHand: "",position: "BB (2 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1430,indent: 1,parent: 1429,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1431,indent: 1,parent: 1429,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.50",amountToPot: "40",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "",
},
{
id: 1432,indent: 1,parent: 1429,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "6.50",amountToPot: "15",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "",
},
{
id: 1433,indent: 1,parent: 1429,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1434,indent: 1,parent: 1429,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "15.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "7.50",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1435,indent: 0,parent: null,handNum: "551",wonOrLost: "1.00",startAmt: "289.27",endAmt: "289.77",finalHand: "",position: "Dealer_SB (2 of 2)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1436,indent: 1,parent: 1435,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1437,indent: 1,parent: 1435,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1438,indent: 1,parent: 1435,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.75",potSizeToWin: "1.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1439,indent: 0,parent: null,handNum: "552",wonOrLost: "1.50",startAmt: "289.77",endAmt: "290.77",finalHand: "",position: "Dealer_UTG (3 of 3)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1440,indent: 1,parent: 1439,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.00",amountToPot: "150",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1441,indent: 0,parent: null,handNum: "553",wonOrLost: "-0.50",startAmt: "290.77",endAmt: "290.27",finalHand: "",position: "BB (2 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1442,indent: 1,parent: 1441,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1443,indent: 1,parent: 1441,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 1444,indent: 0,parent: null,handNum: "554",wonOrLost: "-0.50",startAmt: "290.27",endAmt: "289.77",finalHand: "",position: "SB (1 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1445,indent: 1,parent: 1444,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1446,indent: 1,parent: 1444,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1447,indent: 1,parent: 1444,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1448,indent: 1,parent: 1444,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1449,indent: 0,parent: null,handNum: "555",wonOrLost: "0.00",startAmt: "289.77",endAmt: "289.77",finalHand: "",position: "Dealer_UTG (3 of 3)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1450,indent: 1,parent: 1449,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 1451,indent: 0,parent: null,handNum: "556",wonOrLost: "-0.50",startAmt: "289.77",endAmt: "289.27",finalHand: "",position: "BB (2 of 3)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1452,indent: 1,parent: 1451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1453,indent: 1,parent: 1451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1454,indent: 1,parent: 1451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1455,indent: 1,parent: 1451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1456,indent: 0,parent: null,handNum: "557",wonOrLost: "1.00",startAmt: "289.27",endAmt: "289.77",finalHand: "",position: "Dealer_SB (2 of 2)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1457,indent: 1,parent: 1456,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1458,indent: 1,parent: 1456,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "1.00",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1459,indent: 0,parent: null,handNum: "558",wonOrLost: "-3.25",startAmt: "289.77",endAmt: "286.52",finalHand: "",position: "BB (1 of 2)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1460,indent: 1,parent: 1459,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1461,indent: 1,parent: 1459,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.25",potSizeToWin: "0.75",amountToPot: "166",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1462,indent: 1,parent: 1459,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.75",potSizeToWin: "3.00",amountToPot: "58",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1463,indent: 1,parent: 1459,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Chris Moy",lastActionAmount: "3.50",boardCards: "",
},
{
id: 1464,indent: 0,parent: null,handNum: "559",wonOrLost: "-5.00",startAmt: "286.52",endAmt: "281.52",finalHand: "",position: "Dealer_SB (2 of 2)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1465,indent: 1,parent: 1464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1466,indent: 1,parent: 1464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1467,indent: 1,parent: 1464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.75",potSizeToWin: "1.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1468,indent: 1,parent: 1464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.75",potSizeToWin: "3.25",amountToPot: "23",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 1469,indent: 1,parent: 1464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1470,indent: 1,parent: 1464,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "3.00",potSizeToWin: "4.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1471,indent: 0,parent: null,handNum: "560",wonOrLost: "5.00",startAmt: "281.52",endAmt: "284.02",finalHand: "Pair, K's",position: "BB (1 of 2)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1472,indent: 1,parent: 1471,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1473,indent: 1,parent: 1471,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1474,indent: 1,parent: 1471,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1475,indent: 1,parent: 1471,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 1476,indent: 1,parent: 1471,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "1.00",potSizeToWin: "4.00",amountToPot: "25",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1477,indent: 0,parent: null,handNum: "561",wonOrLost: "-0.50",startAmt: "284.02",endAmt: "283.52",finalHand: "",position: "Dealer_SB (2 of 2)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1478,indent: 1,parent: 1477,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1479,indent: 1,parent: 1477,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "",
},
{
id: 1480,indent: 0,parent: null,handNum: "562",wonOrLost: "1.00",startAmt: "283.52",endAmt: "284.02",finalHand: "",position: "BB (1 of 2)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1481,indent: 1,parent: 1480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1482,indent: 1,parent: 1480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1483,indent: 1,parent: 1480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 1484,indent: 1,parent: 1480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.75",potSizeToWin: "1.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1485,indent: 0,parent: null,handNum: "563",wonOrLost: "17.00",startAmt: "284.02",endAmt: "292.52",finalHand: "Full House, 9's over 3's",position: "Dealer_SB (2 of 2)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1486,indent: 1,parent: 1485,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1487,indent: 1,parent: 1485,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 1488,indent: 1,parent: 1485,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1489,indent: 1,parent: 1485,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "",
},
{
id: 1490,indent: 1,parent: 1485,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.00",potSizeToWin: "3.00",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 1491,indent: 1,parent: 1485,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "5.00",potSizeToWin: "7.00",amountToPot: "71",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 1492,indent: 0,parent: null,handNum: "564",wonOrLost: "-0.25",startAmt: "292.52",endAmt: "292.27",finalHand: "",position: "BB (1 of 2)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1493,indent: 1,parent: 1492,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 1494,indent: 1,parent: 1492,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
];
