﻿var title = "Hand Details for Craig at Table1";
var handFilename = "Table1-Details.html";
var data = [
{
id: 0,indent: 0,parent: null,handNum: "257",wonOrLost: "0.00",startAmt: "102.46",endAmt: "102.46",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 2,indent: 0,parent: null,handNum: "258",wonOrLost: "0.00",startAmt: "102.46",endAmt: "102.46",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 3,indent: 1,parent: 2,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 4,indent: 0,parent: null,handNum: "259",wonOrLost: "0.00",startAmt: "102.46",endAmt: "102.46",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 5,indent: 1,parent: 4,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 6,indent: 0,parent: null,handNum: "260",wonOrLost: "0.00",startAmt: "102.46",endAmt: "102.46",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 7,indent: 1,parent: 6,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 8,indent: 0,parent: null,handNum: "261",wonOrLost: "-0.50",startAmt: "102.46",endAmt: "101.96",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 9,indent: 1,parent: 8,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 10,indent: 1,parent: 8,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "0.75",boardCards: "",
},
{
id: 11,indent: 0,parent: null,handNum: "262",wonOrLost: "-0.25",startAmt: "101.96",endAmt: "101.71",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 12,indent: 1,parent: 11,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 13,indent: 1,parent: 11,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "RB33",lastActionAmount: "2.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 14,indent: 0,parent: null,handNum: "263",wonOrLost: "-0.50",startAmt: "101.71",endAmt: "101.21",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 15,indent: 1,parent: 14,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 16,indent: 1,parent: 14,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 17,indent: 0,parent: null,handNum: "264",wonOrLost: "0.00",startAmt: "101.21",endAmt: "101.21",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 18,indent: 1,parent: 17,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 19,indent: 0,parent: null,handNum: "265",wonOrLost: "-1.00",startAmt: "101.21",endAmt: "100.21",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 20,indent: 1,parent: 19,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 21,indent: 1,parent: 19,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.50",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.75",boardCards: "",
},
{
id: 22,indent: 1,parent: 19,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, [Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 23,indent: 0,parent: null,handNum: "266",wonOrLost: "0.00",startAmt: "100.21",endAmt: "100.21",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 24,indent: 1,parent: 23,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 25,indent: 0,parent: null,handNum: "267",wonOrLost: "0.00",startAmt: "100.21",endAmt: "100.21",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 26,indent: 1,parent: 25,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 27,indent: 0,parent: null,handNum: "268",wonOrLost: "0.00",startAmt: "100.21",endAmt: "100.21",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 28,indent: 1,parent: 27,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 29,indent: 0,parent: null,handNum: "269",wonOrLost: "-1.00",startAmt: "100.21",endAmt: "99.21",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 30,indent: 1,parent: 29,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 31,indent: 1,parent: 29,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 32,indent: 1,parent: 29,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 33,indent: 1,parent: 29,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 34,indent: 0,parent: null,handNum: "270",wonOrLost: "-0.50",startAmt: "99.21",endAmt: "98.71",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 35,indent: 1,parent: 34,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 36,indent: 1,parent: 34,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 37,indent: 1,parent: 34,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 38,indent: 1,parent: 34,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.50",boardCards: "",
},
{
id: 39,indent: 0,parent: null,handNum: "271",wonOrLost: "-0.50",startAmt: "98.71",endAmt: "98.21",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 40,indent: 1,parent: 39,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 41,indent: 1,parent: 39,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 42,indent: 0,parent: null,handNum: "272",wonOrLost: "0.00",startAmt: "98.21",endAmt: "98.21",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 43,indent: 1,parent: 42,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "5",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 44,indent: 0,parent: null,handNum: "273",wonOrLost: "0.00",startAmt: "98.21",endAmt: "98.21",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 45,indent: 1,parent: 44,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 46,indent: 0,parent: null,handNum: "274",wonOrLost: "0.00",startAmt: "98.21",endAmt: "98.21",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 47,indent: 1,parent: 46,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 48,indent: 0,parent: null,handNum: "275",wonOrLost: "-0.50",startAmt: "98.21",endAmt: "97.71",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 49,indent: 1,parent: 48,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 50,indent: 1,parent: 48,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "15.37",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "8.12",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 51,indent: 0,parent: null,handNum: "276",wonOrLost: "0.00",startAmt: "97.71",endAmt: "97.71",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 52,indent: 1,parent: 51,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 53,indent: 0,parent: null,handNum: "277",wonOrLost: "-6.00",startAmt: "97.71",endAmt: "91.71",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 54,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 55,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "5.50",potSizeToWin: "7.50",amountToPot: "73",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 56,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "21.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 57,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "27.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "6.00",boardCards: "",
},
{
id: 58,indent: 0,parent: null,handNum: "278",wonOrLost: "-0.25",startAmt: "91.71",endAmt: "91.46",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 59,indent: 1,parent: 58,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 60,indent: 1,parent: 58,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 61,indent: 0,parent: null,handNum: "279",wonOrLost: "0.00",startAmt: "91.46",endAmt: "91.46",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 62,indent: 1,parent: 61,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 63,indent: 0,parent: null,handNum: "280",wonOrLost: "-1.75",startAmt: "91.46",endAmt: "89.71",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 64,indent: 1,parent: 63,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "2.50",amountToPot: "70",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "",
},
{
id: 65,indent: 1,parent: 63,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jim O",lastActionAmount: "7.75",boardCards: "",
},
{
id: 66,indent: 0,parent: null,handNum: "281",wonOrLost: "0.00",startAmt: "89.71",endAmt: "89.71",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 67,indent: 1,parent: 66,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 68,indent: 0,parent: null,handNum: "282",wonOrLost: "0.00",startAmt: "89.71",endAmt: "89.71",finalHand: "",position: "MP2 (6 of 9)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 69,indent: 1,parent: 68,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 70,indent: 0,parent: null,handNum: "283",wonOrLost: "0.00",startAmt: "89.71",endAmt: "89.71",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 71,indent: 1,parent: 70,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 72,indent: 0,parent: null,handNum: "284",wonOrLost: "0.00",startAmt: "89.71",endAmt: "89.71",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 73,indent: 1,parent: 72,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 74,indent: 0,parent: null,handNum: "285",wonOrLost: "-2.75",startAmt: "89.71",endAmt: "86.96",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 75,indent: 1,parent: 74,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "0.75",amountToPot: "133",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 76,indent: 1,parent: 74,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "4.50",amountToPot: "38",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "2.75",boardCards: "",
},
{
id: 77,indent: 1,parent: 74,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 78,indent: 1,parent: 74,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.93",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "4.68",boardCards: "",
},
{
id: 79,indent: 0,parent: null,handNum: "286",wonOrLost: "-0.50",startAmt: "86.96",endAmt: "86.46",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 80,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 81,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 82,indent: 1,parent: 79,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "1.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 83,indent: 0,parent: null,handNum: "287",wonOrLost: "-0.50",startAmt: "86.46",endAmt: "85.96",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 84,indent: 1,parent: 83,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 85,indent: 1,parent: 83,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jim O",lastActionAmount: "0.50",boardCards: "",
},
{
id: 86,indent: 1,parent: 83,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 87,indent: 1,parent: 83,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "5.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 88,indent: 0,parent: null,handNum: "288",wonOrLost: "0.00",startAmt: "85.96",endAmt: "85.96",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 89,indent: 1,parent: 88,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.75",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 90,indent: 0,parent: null,handNum: "289",wonOrLost: "-0.50",startAmt: "85.96",endAmt: "85.46",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 91,indent: 1,parent: 90,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 92,indent: 1,parent: 90,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 93,indent: 0,parent: null,handNum: "290",wonOrLost: "-3.50",startAmt: "85.46",endAmt: "81.96",finalHand: "",position: "Hijack (7 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 94,indent: 1,parent: 93,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 95,indent: 1,parent: 93,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 96,indent: 1,parent: 93,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "5.25",amountToPot: "28",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 97,indent: 1,parent: 93,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 98,indent: 1,parent: 93,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "12.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jim O",lastActionAmount: "4.50",boardCards: "",
},
{
id: 99,indent: 0,parent: null,handNum: "291",wonOrLost: "0.00",startAmt: "81.96",endAmt: "81.96",finalHand: "",position: "MP2 (6 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 100,indent: 1,parent: 99,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 101,indent: 0,parent: null,handNum: "292",wonOrLost: "0.00",startAmt: "81.96",endAmt: "81.96",finalHand: "",position: "UTG2 (5 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 102,indent: 1,parent: 101,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 103,indent: 0,parent: null,handNum: "293",wonOrLost: "0.00",startAmt: "81.96",endAmt: "81.96",finalHand: "",position: "MP1 (4 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 104,indent: 1,parent: 103,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "9",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 105,indent: 0,parent: null,handNum: "294",wonOrLost: "-1.50",startAmt: "81.96",endAmt: "80.46",finalHand: "",position: "UTG1 (3 of 9)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 106,indent: 1,parent: 105,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "9",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 107,indent: 1,parent: 105,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 108,indent: 1,parent: 105,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.63",amountToPot: "0",numPlayers: "3",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "DanC",lastActionAmount: "6.88",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 109,indent: 0,parent: null,handNum: "295",wonOrLost: "-0.50",startAmt: "80.46",endAmt: "79.96",finalHand: "",position: "BB (2 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 110,indent: 1,parent: 109,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 111,indent: 1,parent: 109,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Jim O",lastActionAmount: "3.25",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 112,indent: 0,parent: null,handNum: "296",wonOrLost: "-0.25",startAmt: "79.96",endAmt: "79.71",finalHand: "",position: "SB (1 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 113,indent: 1,parent: 112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "9",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 114,indent: 1,parent: 112,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 115,indent: 0,parent: null,handNum: "297",wonOrLost: "0.00",startAmt: "79.71",endAmt: "79.71",finalHand: "",position: "Dealer (9 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 116,indent: 1,parent: 115,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 117,indent: 0,parent: null,handNum: "298",wonOrLost: "0.00",startAmt: "79.71",endAmt: "79.71",finalHand: "",position: "Cutoff (8 of 9)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 118,indent: 1,parent: 117,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 119,indent: 0,parent: null,handNum: "299",wonOrLost: "0.00",startAmt: "79.71",endAmt: "79.71",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 120,indent: 1,parent: 119,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "29.32",amountToPot: "0",numPlayers: "6",numAllIns: "1",positionToLastAction: "1",lastAction: "RaiseAllIn",lastActionPlayer: "Chris Moy",lastActionAmount: "28.57",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 121,indent: 0,parent: null,handNum: "300",wonOrLost: "0.00",startAmt: "79.71",endAmt: "79.71",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 122,indent: 1,parent: 121,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 123,indent: 0,parent: null,handNum: "301",wonOrLost: "13.00",startAmt: "79.71",endAmt: "88.71",finalHand: "",position: "MP1 (4 of 8)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 124,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.50",amountToPot: "133",numPlayers: "8",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 125,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "7.00",amountToPot: "28",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 126,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "13.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 127,indent: 1,parent: 123,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.50",potSizeToWin: "13.00",amountToPot: "11",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 128,indent: 0,parent: null,handNum: "302",wonOrLost: "-3.87",startAmt: "88.71",endAmt: "84.84",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 129,indent: 1,parent: 128,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 130,indent: 1,parent: 128,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.37",potSizeToWin: "3.75",amountToPot: "63",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 131,indent: 1,parent: 128,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "8.49",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 132,indent: 1,parent: 128,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "14.85",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "6.36",boardCards: "",
},
{
id: 133,indent: 0,parent: null,handNum: "303",wonOrLost: "-1.00",startAmt: "84.84",endAmt: "83.84",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 134,indent: 1,parent: 133,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 135,indent: 1,parent: 133,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "0.75",boardCards: "",
},
{
id: 136,indent: 1,parent: 133,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 137,indent: 1,parent: 133,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "RB33",lastActionAmount: "5.00",boardCards: "",
},
{
id: 138,indent: 0,parent: null,handNum: "304",wonOrLost: "-0.25",startAmt: "83.84",endAmt: "83.59",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 139,indent: 1,parent: 138,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 140,indent: 1,parent: 138,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 141,indent: 0,parent: null,handNum: "305",wonOrLost: "-1.50",startAmt: "83.59",endAmt: "82.09",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 142,indent: 1,parent: 141,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "3.75",amountToPot: "40",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 143,indent: 1,parent: 141,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "14.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, [6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 144,indent: 0,parent: null,handNum: "306",wonOrLost: "-0.50",startAmt: "82.09",endAmt: "81.59",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 145,indent: 1,parent: 144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "7",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 146,indent: 1,parent: 144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "3.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, [J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 147,indent: 0,parent: null,handNum: "307",wonOrLost: "-70.37",startAmt: "81.59",endAmt: "11.22",finalHand: "",position: "Hijack (6 of 8)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 148,indent: 1,parent: 147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.25",amountToPot: "120",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 149,indent: 1,parent: 147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "5.25",amountToPot: "19",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "2.50",boardCards: "",
},
{
id: 150,indent: 1,parent: 147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "6.25",potSizeToWin: "6.25",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 151,indent: 1,parent: 147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "6.25",potSizeToWin: "25.00",amountToPot: "25",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "12.50",boardCards: "",
},
{
id: 152,indent: 1,parent: 147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "23.43",potSizeToWin: "31.25",amountToPot: "74",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 153,indent: 1,parent: 147,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "RaiseAllIn",amount: "43.16",potSizeToWin: "110.05",amountToPot: "39",numPlayers: "2",numAllIns: "2",positionToLastAction: "1",lastAction: "RaiseAllIn",lastActionPlayer: "John P",lastActionAmount: "55.37",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 154,indent: 0,parent: null,handNum: "308",wonOrLost: "1.25",startAmt: "11.22",endAmt: "11.97",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 155,indent: 1,parent: 154,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "RaiseAllIn",amount: "11.22",potSizeToWin: "0.75",amountToPot: "1496",numPlayers: "6",numAllIns: "1",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 156,indent: 0,parent: null,handNum: "309",wonOrLost: "5.75",startAmt: "11.97",endAmt: "15.22",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 157,indent: 1,parent: 156,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "1.25",amountToPot: "200",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 158,indent: 1,parent: 156,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "5.75",amountToPot: "34",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 159,indent: 0,parent: null,handNum: "310",wonOrLost: "-1.50",startAmt: "15.22",endAmt: "13.72",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 160,indent: 1,parent: 159,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 161,indent: 1,parent: 159,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "11.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.75",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 162,indent: 0,parent: null,handNum: "311",wonOrLost: "-0.50",startAmt: "13.72",endAmt: "13.22",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 163,indent: 1,parent: 162,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 164,indent: 1,parent: 162,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 165,indent: 0,parent: null,handNum: "312",wonOrLost: "-0.25",startAmt: "13.22",endAmt: "12.97",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 166,indent: 1,parent: 165,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 167,indent: 1,parent: 165,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Chris Moy",lastActionAmount: "3.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 168,indent: 0,parent: null,handNum: "313",wonOrLost: "-0.50",startAmt: "12.97",endAmt: "12.47",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 169,indent: 1,parent: 168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 170,indent: 1,parent: 168,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 171,indent: 0,parent: null,handNum: "314",wonOrLost: "-2.74",startAmt: "12.47",endAmt: "9.73",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 172,indent: 1,parent: 171,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "2.74",potSizeToWin: "3.37",amountToPot: "81",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.62",boardCards: "",
},
{
id: 173,indent: 1,parent: 171,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.32",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "2.09",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 174,indent: 0,parent: null,handNum: "315",wonOrLost: "0.00",startAmt: "9.73",endAmt: "9.73",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 175,indent: 1,parent: 174,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 176,indent: 0,parent: null,handNum: "316",wonOrLost: "0.00",startAmt: "9.73",endAmt: "9.73",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 177,indent: 1,parent: 176,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 178,indent: 0,parent: null,handNum: "317",wonOrLost: "0.00",startAmt: "9.73",endAmt: "9.73",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 179,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 180,indent: 0,parent: null,handNum: "318",wonOrLost: "0.00",startAmt: "9.73",endAmt: "9.73",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 181,indent: 1,parent: 180,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 182,indent: 0,parent: null,handNum: "319",wonOrLost: "-0.50",startAmt: "9.73",endAmt: "9.23",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 183,indent: 1,parent: 182,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 184,indent: 1,parent: 182,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 185,indent: 0,parent: null,handNum: "320",wonOrLost: "-0.25",startAmt: "9.23",endAmt: "8.98",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 186,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 187,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "4.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 188,indent: 0,parent: null,handNum: "321",wonOrLost: "19.21",startAmt: "8.98",endAmt: "19.21",finalHand: "Straight, 6 High",position: "Dealer (8 of 8)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 189,indent: 1,parent: 188,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "1.25",amountToPot: "80",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 190,indent: 1,parent: 188,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "RaiseAllIn",amount: "7.98",potSizeToWin: "5.68",amountToPot: "140",numPlayers: "3",numAllIns: "1",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "2.43",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 191,indent: 0,parent: null,handNum: "322",wonOrLost: "-3.50",startAmt: "19.21",endAmt: "15.71",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 192,indent: 1,parent: 191,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 193,indent: 1,parent: 191,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "5.00",amountToPot: "40",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 194,indent: 1,parent: 191,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 195,indent: 1,parent: 191,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 196,indent: 0,parent: null,handNum: "323",wonOrLost: "0.00",startAmt: "15.71",endAmt: "15.71",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 197,indent: 1,parent: 196,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 198,indent: 0,parent: null,handNum: "324",wonOrLost: "0.00",startAmt: "15.71",endAmt: "15.71",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 199,indent: 1,parent: 198,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.26",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "2.01",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 200,indent: 0,parent: null,handNum: "325",wonOrLost: "0.00",startAmt: "15.71",endAmt: "15.71",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 201,indent: 1,parent: 200,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 202,indent: 0,parent: null,handNum: "326",wonOrLost: "0.00",startAmt: "15.71",endAmt: "15.71",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 203,indent: 1,parent: 202,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 204,indent: 0,parent: null,handNum: "327",wonOrLost: "2.00",startAmt: "15.71",endAmt: "17.21",finalHand: "",position: "BB (2 of 8)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 205,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 206,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 207,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "2.00",amountToPot: "75",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 208,indent: 0,parent: null,handNum: "328",wonOrLost: "-0.25",startAmt: "17.21",endAmt: "16.96",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 209,indent: 1,parent: 208,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 210,indent: 1,parent: 208,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "6",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 211,indent: 0,parent: null,handNum: "329",wonOrLost: "0.00",startAmt: "16.96",endAmt: "16.96",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 212,indent: 1,parent: 211,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 213,indent: 0,parent: null,handNum: "330",wonOrLost: "0.00",startAmt: "16.96",endAmt: "16.96",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 214,indent: 1,parent: 213,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 215,indent: 0,parent: null,handNum: "331",wonOrLost: "0.00",startAmt: "16.96",endAmt: "16.96",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 216,indent: 1,parent: 215,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 217,indent: 0,parent: null,handNum: "332",wonOrLost: "-1.50",startAmt: "16.96",endAmt: "15.46",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 218,indent: 1,parent: 217,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.25",amountToPot: "120",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 219,indent: 1,parent: 217,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "4.00",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 220,indent: 0,parent: null,handNum: "333",wonOrLost: "0.00",startAmt: "15.46",endAmt: "15.46",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 221,indent: 1,parent: 220,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.05",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "2.30",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 222,indent: 0,parent: null,handNum: "334",wonOrLost: "-0.50",startAmt: "15.46",endAmt: "14.96",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 223,indent: 1,parent: 222,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 224,indent: 1,parent: 222,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 225,indent: 1,parent: 222,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 226,indent: 1,parent: 222,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 227,indent: 0,parent: null,handNum: "335",wonOrLost: "-14.96",startAmt: "14.96",endAmt: "0.00",finalHand: "",position: "SB (1 of 7)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 228,indent: 1,parent: 227,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 229,indent: 1,parent: 227,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.25",potSizeToWin: "3.25",amountToPot: "69",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.50",boardCards: "",
},
{
id: 230,indent: 1,parent: 227,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.50",potSizeToWin: "5.50",amountToPot: "45",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 231,indent: 1,parent: 227,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "ReraiseAllIn",amount: "9.96",potSizeToWin: "13.00",amountToPot: "76",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "5.00",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 232,indent: 0,parent: null,handNum: "338",wonOrLost: "0.00",startAmt: "100.00",endAmt: "100.00",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 233,indent: 1,parent: 232,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 234,indent: 0,parent: null,handNum: "339",wonOrLost: "0.00",startAmt: "100.00",endAmt: "100.00",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 235,indent: 1,parent: 234,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 236,indent: 0,parent: null,handNum: "340",wonOrLost: "12.25",startAmt: "100.00",endAmt: "107.75",finalHand: "A High",position: "MP1 (4 of 8)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 237,indent: 1,parent: 236,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "1.25",amountToPot: "200",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 238,indent: 1,parent: 236,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "8.25",amountToPot: "24",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 239,indent: 1,parent: 236,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "12.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 240,indent: 1,parent: 236,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "12.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 241,indent: 0,parent: null,handNum: "341",wonOrLost: "-1.50",startAmt: "107.75",endAmt: "106.25",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 242,indent: 1,parent: 241,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 243,indent: 1,parent: 241,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 244,indent: 1,parent: 241,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "",
},
{
id: 245,indent: 0,parent: null,handNum: "342",wonOrLost: "-0.50",startAmt: "106.25",endAmt: "105.75",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 246,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 247,indent: 1,parent: 245,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.75",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 248,indent: 0,parent: null,handNum: "343",wonOrLost: "-0.25",startAmt: "105.75",endAmt: "105.50",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 249,indent: 1,parent: 248,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 250,indent: 1,parent: 248,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "2.50",boardCards: "",
},
{
id: 251,indent: 0,parent: null,handNum: "344",wonOrLost: "-0.50",startAmt: "105.50",endAmt: "105.00",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 252,indent: 1,parent: 251,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 253,indent: 1,parent: 251,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 254,indent: 1,parent: 251,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.75",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 255,indent: 0,parent: null,handNum: "345",wonOrLost: "-0.50",startAmt: "105.00",endAmt: "104.50",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 256,indent: 1,parent: 255,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "7",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 257,indent: 1,parent: 255,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 258,indent: 0,parent: null,handNum: "346",wonOrLost: "0.00",startAmt: "104.50",endAmt: "104.50",finalHand: "",position: "Hijack (6 of 8)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 259,indent: 1,parent: 258,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 260,indent: 0,parent: null,handNum: "347",wonOrLost: "0.00",startAmt: "104.50",endAmt: "104.50",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 261,indent: 1,parent: 260,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 262,indent: 0,parent: null,handNum: "348",wonOrLost: "0.00",startAmt: "104.50",endAmt: "104.50",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 263,indent: 1,parent: 262,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.00",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 264,indent: 0,parent: null,handNum: "349",wonOrLost: "0.00",startAmt: "104.50",endAmt: "104.50",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 265,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 266,indent: 0,parent: null,handNum: "350",wonOrLost: "-0.50",startAmt: "104.50",endAmt: "104.00",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 267,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 268,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 269,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 270,indent: 1,parent: 266,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 271,indent: 0,parent: null,handNum: "351",wonOrLost: "-0.50",startAmt: "104.00",endAmt: "103.50",finalHand: "",position: "SB (1 of 8)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 272,indent: 1,parent: 271,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 273,indent: 1,parent: 271,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 274,indent: 1,parent: 271,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.75",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 275,indent: 0,parent: null,handNum: "352",wonOrLost: "-0.50",startAmt: "103.50",endAmt: "103.00",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 276,indent: 1,parent: 275,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 277,indent: 1,parent: 275,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.25",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 278,indent: 0,parent: null,handNum: "353",wonOrLost: "12.25",startAmt: "103.00",endAmt: "109.75",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 279,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "3.50",potSizeToWin: "2.25",amountToPot: "155",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.00",boardCards: "",
},
{
id: 280,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "2.00",potSizeToWin: "8.75",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 281,indent: 1,parent: 278,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.50",potSizeToWin: "12.25",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 282,indent: 0,parent: null,handNum: "354",wonOrLost: "-1.50",startAmt: "109.75",endAmt: "108.25",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 283,indent: 1,parent: 282,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.25",amountToPot: "120",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 284,indent: 1,parent: 282,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "4.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 285,indent: 0,parent: null,handNum: "355",wonOrLost: "0.00",startAmt: "108.25",endAmt: "108.25",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 286,indent: 1,parent: 285,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 287,indent: 0,parent: null,handNum: "356",wonOrLost: "0.00",startAmt: "108.25",endAmt: "108.25",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 288,indent: 1,parent: 287,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 289,indent: 0,parent: null,handNum: "357",wonOrLost: "0.00",startAmt: "108.25",endAmt: "108.25",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 290,indent: 1,parent: 289,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 291,indent: 0,parent: null,handNum: "358",wonOrLost: "-0.50",startAmt: "108.25",endAmt: "107.75",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 292,indent: 1,parent: 291,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 293,indent: 1,parent: 291,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.66",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.91",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 294,indent: 0,parent: null,handNum: "359",wonOrLost: "-0.25",startAmt: "107.75",endAmt: "107.50",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 295,indent: 1,parent: 294,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 296,indent: 1,parent: 294,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 297,indent: 0,parent: null,handNum: "360",wonOrLost: "-1.00",startAmt: "107.50",endAmt: "106.50",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 298,indent: 1,parent: 297,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "1.75",amountToPot: "57",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 299,indent: 1,parent: 297,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 300,indent: 1,parent: 297,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "3.75",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 301,indent: 0,parent: null,handNum: "361",wonOrLost: "0.00",startAmt: "106.50",endAmt: "106.50",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 302,indent: 1,parent: 301,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 303,indent: 0,parent: null,handNum: "362",wonOrLost: "0.00",startAmt: "106.50",endAmt: "106.50",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 304,indent: 1,parent: 303,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 305,indent: 0,parent: null,handNum: "363",wonOrLost: "0.00",startAmt: "106.50",endAmt: "106.50",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 306,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 307,indent: 0,parent: null,handNum: "364",wonOrLost: "-1.50",startAmt: "106.50",endAmt: "105.00",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 308,indent: 1,parent: 307,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 309,indent: 1,parent: 307,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 310,indent: 1,parent: 307,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "3.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 311,indent: 0,parent: null,handNum: "365",wonOrLost: "-4.00",startAmt: "105.00",endAmt: "101.00",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 312,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 313,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "7.75",amountToPot: "32",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "4.00",boardCards: "",
},
{
id: 314,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "12.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 315,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "17.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "5.00",boardCards: "",
},
{
id: 316,indent: 0,parent: null,handNum: "366",wonOrLost: "-0.50",startAmt: "101.00",endAmt: "100.50",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 317,indent: 1,parent: 316,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 318,indent: 1,parent: 316,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "2.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 319,indent: 0,parent: null,handNum: "367",wonOrLost: "-0.25",startAmt: "100.50",endAmt: "100.25",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 320,indent: 1,parent: 319,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 321,indent: 1,parent: 319,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 322,indent: 0,parent: null,handNum: "368",wonOrLost: "0.00",startAmt: "100.25",endAmt: "100.25",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 323,indent: 1,parent: 322,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "",
},
{
id: 324,indent: 0,parent: null,handNum: "369",wonOrLost: "0.00",startAmt: "100.25",endAmt: "100.25",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 325,indent: 1,parent: 324,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 326,indent: 0,parent: null,handNum: "370",wonOrLost: "8.75",startAmt: "100.25",endAmt: "106.00",finalHand: "",position: "Hijack (6 of 8)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 327,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.75",amountToPot: "114",numPlayers: "7",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 328,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.00",potSizeToWin: "6.75",amountToPot: "14",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 329,indent: 1,parent: 326,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.50",potSizeToWin: "8.75",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 330,indent: 0,parent: null,handNum: "371",wonOrLost: "-2.25",startAmt: "106.00",endAmt: "103.75",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 331,indent: 1,parent: 330,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "8",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 332,indent: 1,parent: 330,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.75",potSizeToWin: "7.00",amountToPot: "25",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.75",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 333,indent: 1,parent: 330,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 334,indent: 1,parent: 330,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "13.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "4.50",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 335,indent: 0,parent: null,handNum: "372",wonOrLost: "0.00",startAmt: "103.75",endAmt: "103.75",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 336,indent: 1,parent: 335,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 337,indent: 0,parent: null,handNum: "373",wonOrLost: "-3.50",startAmt: "103.75",endAmt: "100.25",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 338,indent: 1,parent: 337,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 339,indent: 1,parent: 337,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "6.25",amountToPot: "24",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 340,indent: 1,parent: 337,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 341,indent: 1,parent: 337,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "11.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "",
},
{
id: 342,indent: 0,parent: null,handNum: "374",wonOrLost: "-0.50",startAmt: "100.25",endAmt: "99.75",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 343,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 344,indent: 1,parent: 342,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 345,indent: 0,parent: null,handNum: "375",wonOrLost: "-2.00",startAmt: "99.75",endAmt: "97.75",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 346,indent: 1,parent: 345,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 347,indent: 1,parent: 345,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 348,indent: 1,parent: 345,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "1.50",amountToPot: "100",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 349,indent: 1,parent: 345,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 350,indent: 1,parent: 345,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "9.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "3.25",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 351,indent: 0,parent: null,handNum: "376",wonOrLost: "0.00",startAmt: "97.75",endAmt: "97.75",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 352,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.06",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.81",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 353,indent: 0,parent: null,handNum: "377",wonOrLost: "0.00",startAmt: "97.75",endAmt: "97.75",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 354,indent: 1,parent: 353,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 355,indent: 0,parent: null,handNum: "378",wonOrLost: "-3.50",startAmt: "97.75",endAmt: "94.25",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 356,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 357,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.75",amountToPot: "26",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "3.00",boardCards: "",
},
{
id: 358,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "12.68",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "5.43",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 359,indent: 0,parent: null,handNum: "379",wonOrLost: "-0.50",startAmt: "94.25",endAmt: "93.75",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 360,indent: 1,parent: 359,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 361,indent: 1,parent: 359,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 362,indent: 0,parent: null,handNum: "380",wonOrLost: "0.00",startAmt: "93.75",endAmt: "93.75",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 363,indent: 1,parent: 362,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 364,indent: 0,parent: null,handNum: "381",wonOrLost: "0.00",startAmt: "93.75",endAmt: "93.75",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 365,indent: 1,parent: 364,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 366,indent: 0,parent: null,handNum: "382",wonOrLost: "-1.00",startAmt: "93.75",endAmt: "92.75",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 367,indent: 1,parent: 366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 368,indent: 1,parent: 366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "4.75",amountToPot: "10",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 369,indent: 1,parent: 366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 370,indent: 1,parent: 366,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.87",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "2.62",boardCards: "",
},
{
id: 371,indent: 0,parent: null,handNum: "383",wonOrLost: "-0.25",startAmt: "92.75",endAmt: "92.50",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 372,indent: 1,parent: 371,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 373,indent: 1,parent: 371,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 374,indent: 0,parent: null,handNum: "384",wonOrLost: "0.00",startAmt: "92.50",endAmt: "92.50",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 375,indent: 1,parent: 374,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 376,indent: 0,parent: null,handNum: "385",wonOrLost: "0.00",startAmt: "92.50",endAmt: "92.50",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 377,indent: 1,parent: 376,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 378,indent: 0,parent: null,handNum: "386",wonOrLost: "0.00",startAmt: "92.50",endAmt: "92.50",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 379,indent: 1,parent: 378,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 380,indent: 0,parent: null,handNum: "387",wonOrLost: "0.00",startAmt: "92.50",endAmt: "92.50",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 381,indent: 1,parent: 380,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 382,indent: 0,parent: null,handNum: "388",wonOrLost: "-0.50",startAmt: "92.50",endAmt: "92.00",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 383,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "8",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 384,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "3.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 385,indent: 0,parent: null,handNum: "389",wonOrLost: "0.00",startAmt: "92.00",endAmt: "92.00",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 386,indent: 1,parent: 385,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 387,indent: 0,parent: null,handNum: "390",wonOrLost: "-0.50",startAmt: "92.00",endAmt: "91.50",finalHand: "",position: "BB (2 of 8)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 388,indent: 1,parent: 387,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 389,indent: 1,parent: 387,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 390,indent: 0,parent: null,handNum: "391",wonOrLost: "-0.25",startAmt: "91.50",endAmt: "91.25",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 391,indent: 1,parent: 390,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 392,indent: 1,parent: 390,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "2.25",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 393,indent: 0,parent: null,handNum: "392",wonOrLost: "-1.50",startAmt: "91.25",endAmt: "89.75",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 394,indent: 1,parent: 393,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.75",amountToPot: "85",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 395,indent: 1,parent: 393,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.70",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.20",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 396,indent: 0,parent: null,handNum: "393",wonOrLost: "2.50",startAmt: "89.75",endAmt: "91.75",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 397,indent: 1,parent: 396,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 398,indent: 1,parent: 396,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "2.50",amountToPot: "60",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 399,indent: 0,parent: null,handNum: "394",wonOrLost: "-0.50",startAmt: "91.75",endAmt: "91.25",finalHand: "",position: "Hijack (6 of 8)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 400,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 401,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "2.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 402,indent: 0,parent: null,handNum: "395",wonOrLost: "6.75",startAmt: "91.25",endAmt: "95.00",finalHand: "",position: "UTG2 (5 of 8)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 403,indent: 1,parent: 402,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 404,indent: 1,parent: 402,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.00",potSizeToWin: "4.75",amountToPot: "21",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 405,indent: 1,parent: 402,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.50",potSizeToWin: "6.75",amountToPot: "37",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 406,indent: 0,parent: null,handNum: "396",wonOrLost: "0.00",startAmt: "95.00",endAmt: "95.00",finalHand: "",position: "MP1 (4 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 407,indent: 1,parent: 406,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.75",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 408,indent: 0,parent: null,handNum: "397",wonOrLost: "0.00",startAmt: "95.00",endAmt: "95.00",finalHand: "",position: "UTG1 (3 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 409,indent: 1,parent: 408,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "8",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 410,indent: 0,parent: null,handNum: "398",wonOrLost: "-0.50",startAmt: "95.00",endAmt: "94.50",finalHand: "",position: "BB (2 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 411,indent: 1,parent: 410,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 412,indent: 1,parent: 410,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 413,indent: 1,parent: 410,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 414,indent: 1,parent: 410,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.13",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "RB33",lastActionAmount: "5.13",boardCards: "",
},
{
id: 415,indent: 0,parent: null,handNum: "399",wonOrLost: "-0.25",startAmt: "94.50",endAmt: "94.25",finalHand: "",position: "SB (1 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 416,indent: 1,parent: 415,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "8",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 417,indent: 1,parent: 415,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 418,indent: 0,parent: null,handNum: "400",wonOrLost: "-2.00",startAmt: "94.25",endAmt: "92.25",finalHand: "",position: "Dealer (8 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 419,indent: 1,parent: 418,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 420,indent: 1,parent: 418,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "1.50",potSizeToWin: "3.25",amountToPot: "46",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 421,indent: 1,parent: 418,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "13.56",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Jeff",lastActionAmount: "7.31",boardCards: "",
},
{
id: 422,indent: 0,parent: null,handNum: "401",wonOrLost: "-1.50",startAmt: "92.25",endAmt: "90.75",finalHand: "",position: "Cutoff (7 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 423,indent: 1,parent: 422,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "3.25",amountToPot: "46",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 424,indent: 1,parent: 422,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "13.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "5.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 425,indent: 0,parent: null,handNum: "402",wonOrLost: "0.00",startAmt: "90.75",endAmt: "90.75",finalHand: "",position: "Hijack (6 of 8)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 426,indent: 1,parent: 425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 427,indent: 0,parent: null,handNum: "403",wonOrLost: "-8.25",startAmt: "90.75",endAmt: "82.50",finalHand: "",position: "MP1 (4 of 7)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 428,indent: 1,parent: 427,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 429,indent: 1,parent: 427,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "6.25",potSizeToWin: "14.25",amountToPot: "43",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Jeff",lastActionAmount: "8.00",boardCards: "",
},
{
id: 430,indent: 1,parent: 427,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "50.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "25.25",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 431,indent: 0,parent: null,handNum: "404",wonOrLost: "-23.50",startAmt: "82.50",endAmt: "59.00",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 432,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "0.75",amountToPot: "333",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 433,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "12.25",amountToPot: "16",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "John P",lastActionAmount: "4.50",boardCards: "",
},
{
id: 434,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.00",potSizeToWin: "14.25",amountToPot: "21",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 435,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "6.00",potSizeToWin: "32.25",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "9.00",boardCards: "",
},
{
id: 436,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "41.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 437,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "10.00",potSizeToWin: "51.25",amountToPot: "19",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "10.00",boardCards: "",
},
{
id: 438,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "61.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 439,indent: 1,parent: 431,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "90.88",amountToPot: "0",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "DanC",lastActionAmount: "29.63",boardCards: "",
},
{
id: 440,indent: 0,parent: null,handNum: "405",wonOrLost: "-0.50",startAmt: "59.00",endAmt: "58.50",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 441,indent: 1,parent: 440,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 442,indent: 1,parent: 440,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 443,indent: 1,parent: 440,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 444,indent: 1,parent: 440,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.25",boardCards: "",
},
{
id: 445,indent: 0,parent: null,handNum: "406",wonOrLost: "-0.25",startAmt: "58.50",endAmt: "58.25",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 446,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 447,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 448,indent: 0,parent: null,handNum: "407",wonOrLost: "1.25",startAmt: "58.25",endAmt: "59.00",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 449,indent: 1,parent: 448,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "0.75",amountToPot: "266",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 450,indent: 0,parent: null,handNum: "408",wonOrLost: "-5.25",startAmt: "59.00",endAmt: "53.75",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 451,indent: 1,parent: 450,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 452,indent: 1,parent: 450,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "4.50",amountToPot: "27",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.75",boardCards: "",
},
{
id: 453,indent: 1,parent: 450,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "5.75",amountToPot: "34",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 454,indent: 1,parent: 450,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "9.75",amountToPot: "15",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 455,indent: 1,parent: 450,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "12.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 456,indent: 1,parent: 450,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "15.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "3.00",boardCards: "",
},
{
id: 457,indent: 0,parent: null,handNum: "409",wonOrLost: "11.00",startAmt: "53.75",endAmt: "62.25",finalHand: "",position: "Hijack (5 of 7)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 458,indent: 1,parent: 457,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "2.50",potSizeToWin: "2.75",amountToPot: "90",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 459,indent: 1,parent: 457,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.50",potSizeToWin: "11.00",amountToPot: "31",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 460,indent: 0,parent: null,handNum: "410",wonOrLost: "14.00",startAmt: "62.25",endAmt: "69.75",finalHand: "Pair, 8's",position: "MP1 (4 of 7)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 461,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "3.00",potSizeToWin: "1.25",amountToPot: "240",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 462,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 463,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 464,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.50",potSizeToWin: "10.50",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "3.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 465,indent: 0,parent: null,handNum: "411",wonOrLost: "6.25",startAmt: "69.75",endAmt: "70.00",finalHand: "Straight, 9 High (SP:2)",position: "UTG1 (3 of 7)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 466,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 467,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 468,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 469,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Raise",amount: "5.00",potSizeToWin: "5.00",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 470,indent: 0,parent: null,handNum: "412",wonOrLost: "-0.50",startAmt: "70.00",endAmt: "69.50",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 471,indent: 1,parent: 470,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 472,indent: 1,parent: 470,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "3.50",boardCards: "",
},
{
id: 473,indent: 0,parent: null,handNum: "413",wonOrLost: "15.00",startAmt: "69.50",endAmt: "77.25",finalHand: "Flush, 7d High",position: "SB (1 of 7)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 474,indent: 1,parent: 473,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 475,indent: 1,parent: 473,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 476,indent: 1,parent: 473,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.00",potSizeToWin: "1.50",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 477,indent: 1,parent: 473,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.00",potSizeToWin: "3.50",amountToPot: "57",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 478,indent: 1,parent: 473,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 479,indent: 1,parent: 473,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.75",potSizeToWin: "11.25",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "3.75",boardCards: "",
},
{
id: 480,indent: 0,parent: null,handNum: "414",wonOrLost: "0.00",startAmt: "77.25",endAmt: "77.25",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 481,indent: 1,parent: 480,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "",
},
{
id: 482,indent: 0,parent: null,handNum: "415",wonOrLost: "0.00",startAmt: "77.25",endAmt: "77.25",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 483,indent: 1,parent: 482,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 484,indent: 0,parent: null,handNum: "416",wonOrLost: "-1.50",startAmt: "77.25",endAmt: "75.75",finalHand: "",position: "Hijack (5 of 7)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 485,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.25",amountToPot: "120",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 486,indent: 1,parent: 484,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.62",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.87",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 487,indent: 0,parent: null,handNum: "417",wonOrLost: "0.00",startAmt: "75.75",endAmt: "75.75",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 488,indent: 1,parent: 487,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 489,indent: 0,parent: null,handNum: "418",wonOrLost: "-2.50",startAmt: "75.75",endAmt: "73.25",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 490,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "0.75",amountToPot: "333",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 491,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "20.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "10.25",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 492,indent: 0,parent: null,handNum: "419",wonOrLost: "-0.50",startAmt: "73.25",endAmt: "72.75",finalHand: "",position: "BB (2 of 7)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 493,indent: 1,parent: 492,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 494,indent: 1,parent: 492,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "John P",lastActionAmount: "1.00",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 495,indent: 0,parent: null,handNum: "420",wonOrLost: "-0.50",startAmt: "72.75",endAmt: "72.25",finalHand: "",position: "SB (1 of 7)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 496,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 497,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 498,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 499,indent: 1,parent: 495,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "",
},
{
id: 500,indent: 0,parent: null,handNum: "421",wonOrLost: "0.00",startAmt: "72.25",endAmt: "72.25",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 501,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 502,indent: 0,parent: null,handNum: "422",wonOrLost: "-1.50",startAmt: "72.25",endAmt: "70.75",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 503,indent: 1,parent: 502,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "4.25",amountToPot: "35",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 504,indent: 1,parent: 502,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "9.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "3.50",boardCards: "",
},
{
id: 505,indent: 0,parent: null,handNum: "423",wonOrLost: "-0.50",startAmt: "70.75",endAmt: "70.25",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 506,indent: 1,parent: 505,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 507,indent: 1,parent: 505,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 508,indent: 0,parent: null,handNum: "424",wonOrLost: "0.00",startAmt: "70.25",endAmt: "70.25",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 509,indent: 1,parent: 508,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 510,indent: 0,parent: null,handNum: "425",wonOrLost: "0.00",startAmt: "70.25",endAmt: "70.25",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 511,indent: 1,parent: 510,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 512,indent: 0,parent: null,handNum: "426",wonOrLost: "-0.50",startAmt: "70.25",endAmt: "69.75",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 513,indent: 1,parent: 512,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 514,indent: 1,parent: 512,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "11.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "6.00",boardCards: "",
},
{
id: 515,indent: 0,parent: null,handNum: "427",wonOrLost: "-0.25",startAmt: "69.75",endAmt: "69.50",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 516,indent: 1,parent: 515,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 517,indent: 1,parent: 515,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 518,indent: 0,parent: null,handNum: "428",wonOrLost: "-1.00",startAmt: "69.50",endAmt: "68.50",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 519,indent: 1,parent: 518,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.75",amountToPot: "36",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 520,indent: 1,parent: 518,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 521,indent: 0,parent: null,handNum: "429",wonOrLost: "0.00",startAmt: "68.50",endAmt: "68.50",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 522,indent: 1,parent: 521,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 523,indent: 0,parent: null,handNum: "430",wonOrLost: "0.00",startAmt: "68.50",endAmt: "68.50",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 524,indent: 1,parent: 523,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 525,indent: 0,parent: null,handNum: "431",wonOrLost: "1.75",startAmt: "68.50",endAmt: "69.75",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 526,indent: 1,parent: 525,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.50",potSizeToWin: "1.25",amountToPot: "200",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 527,indent: 0,parent: null,handNum: "432",wonOrLost: "-2.00",startAmt: "69.75",endAmt: "67.75",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 528,indent: 1,parent: 527,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 529,indent: 1,parent: 527,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.00",amountToPot: "30",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "",
},
{
id: 530,indent: 1,parent: 527,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 531,indent: 1,parent: 527,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "4.00",boardCards: "",
},
{
id: 532,indent: 0,parent: null,handNum: "433",wonOrLost: "-0.50",startAmt: "67.75",endAmt: "67.25",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 533,indent: 1,parent: 532,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 534,indent: 1,parent: 532,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 535,indent: 0,parent: null,handNum: "434",wonOrLost: "-0.25",startAmt: "67.25",endAmt: "67.00",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 536,indent: 1,parent: 535,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 537,indent: 1,parent: 535,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "5.00",boardCards: "",
},
{
id: 538,indent: 0,parent: null,handNum: "435",wonOrLost: "28.75",startAmt: "67.00",endAmt: "85.00",finalHand: "",position: "Dealer (7 of 7)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 539,indent: 1,parent: 538,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.25",amountToPot: "120",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 540,indent: 1,parent: 538,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.25",potSizeToWin: "10.50",amountToPot: "21",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.25",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 541,indent: 1,parent: 538,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "7.00",potSizeToWin: "16.75",amountToPot: "41",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 542,indent: 1,parent: 538,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "7.50",potSizeToWin: "28.75",amountToPot: "26",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 543,indent: 0,parent: null,handNum: "436",wonOrLost: "0.00",startAmt: "85.00",endAmt: "85.00",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 544,indent: 1,parent: 543,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 545,indent: 0,parent: null,handNum: "437",wonOrLost: "2.50",startAmt: "85.00",endAmt: "87.00",finalHand: "",position: "Hijack (5 of 7)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 546,indent: 1,parent: 545,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 547,indent: 1,parent: 545,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "2.50",amountToPot: "60",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 548,indent: 0,parent: null,handNum: "438",wonOrLost: "0.00",startAmt: "87.00",endAmt: "87.00",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 549,indent: 1,parent: 548,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 550,indent: 0,parent: null,handNum: "439",wonOrLost: "0.00",startAmt: "87.00",endAmt: "87.00",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 551,indent: 1,parent: 550,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 552,indent: 0,parent: null,handNum: "440",wonOrLost: "-0.50",startAmt: "87.00",endAmt: "86.50",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 553,indent: 1,parent: 552,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 554,indent: 1,parent: 552,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 555,indent: 1,parent: 552,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 556,indent: 1,parent: 552,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 557,indent: 0,parent: null,handNum: "441",wonOrLost: "-0.50",startAmt: "86.50",endAmt: "86.00",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 558,indent: 1,parent: 557,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 559,indent: 1,parent: 557,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 560,indent: 1,parent: 557,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 561,indent: 1,parent: 557,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 562,indent: 0,parent: null,handNum: "442",wonOrLost: "0.00",startAmt: "86.00",endAmt: "86.00",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 563,indent: 1,parent: 562,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 564,indent: 0,parent: null,handNum: "443",wonOrLost: "-10.50",startAmt: "86.00",endAmt: "75.50",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 565,indent: 1,parent: 564,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.25",amountToPot: "120",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 566,indent: 1,parent: 564,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "8.50",amountToPot: "23",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "2.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 567,indent: 1,parent: 564,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.50",potSizeToWin: "14.00",amountToPot: "25",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "3.50",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 568,indent: 1,parent: 564,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.50",potSizeToWin: "21.00",amountToPot: "16",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "3.50",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 569,indent: 0,parent: null,handNum: "444",wonOrLost: "-1.50",startAmt: "75.50",endAmt: "74.00",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 570,indent: 1,parent: 569,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 571,indent: 1,parent: 569,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.50",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.75",boardCards: "",
},
{
id: 572,indent: 1,parent: 569,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "5.00",amountToPot: "10",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 573,indent: 1,parent: 569,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 574,indent: 1,parent: 569,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "2.00",boardCards: "",
},
{
id: 575,indent: 0,parent: null,handNum: "445",wonOrLost: "0.00",startAmt: "74.00",endAmt: "74.00",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 576,indent: 1,parent: 575,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 577,indent: 0,parent: null,handNum: "446",wonOrLost: "0.00",startAmt: "74.00",endAmt: "74.00",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 578,indent: 1,parent: 577,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 579,indent: 0,parent: null,handNum: "447",wonOrLost: "5.00",startAmt: "74.00",endAmt: "77.00",finalHand: "",position: "BB (2 of 7)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 580,indent: 1,parent: 579,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 581,indent: 1,parent: 579,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "2.00",amountToPot: "75",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 582,indent: 1,parent: 579,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.50",potSizeToWin: "5.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 583,indent: 0,parent: null,handNum: "448",wonOrLost: "-0.25",startAmt: "77.00",endAmt: "76.75",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 584,indent: 1,parent: 583,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 585,indent: 1,parent: 583,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 586,indent: 0,parent: null,handNum: "449",wonOrLost: "-0.50",startAmt: "76.75",endAmt: "76.25",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 587,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 588,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 589,indent: 1,parent: 586,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.37",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "John P",lastActionAmount: "1.87",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 590,indent: 0,parent: null,handNum: "450",wonOrLost: "-4.12",startAmt: "76.25",endAmt: "72.13",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 591,indent: 1,parent: 590,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "3.75",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Jeff",lastActionAmount: "1.50",boardCards: "",
},
{
id: 592,indent: 1,parent: 590,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.62",potSizeToWin: "7.87",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "2.62",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 593,indent: 1,parent: 590,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "10.49",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 594,indent: 1,parent: 590,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "15.73",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Jeff",lastActionAmount: "5.24",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 595,indent: 0,parent: null,handNum: "451",wonOrLost: "1.75",startAmt: "72.13",endAmt: "73.38",finalHand: "",position: "Hijack (5 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 596,indent: 1,parent: 595,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.00",potSizeToWin: "1.25",amountToPot: "160",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Jeff",lastActionAmount: "0.50",boardCards: "",
},
{
id: 597,indent: 0,parent: null,handNum: "452",wonOrLost: "0.00",startAmt: "73.38",endAmt: "73.38",finalHand: "",position: "MP1 (4 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 598,indent: 1,parent: 597,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "7",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 599,indent: 0,parent: null,handNum: "453",wonOrLost: "-0.50",startAmt: "73.38",endAmt: "72.88",finalHand: "",position: "UTG1 (3 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 600,indent: 1,parent: 599,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "7",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 601,indent: 1,parent: 599,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.25",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 602,indent: 0,parent: null,handNum: "454",wonOrLost: "-0.50",startAmt: "72.88",endAmt: "72.38",finalHand: "",position: "BB (2 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 603,indent: 1,parent: 602,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 604,indent: 1,parent: 602,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 605,indent: 0,parent: null,handNum: "455",wonOrLost: "-2.00",startAmt: "72.38",endAmt: "70.38",finalHand: "",position: "SB (1 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 606,indent: 1,parent: 605,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "7",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 607,indent: 1,parent: 605,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "2.75",amountToPot: "63",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.00",boardCards: "",
},
{
id: 608,indent: 1,parent: 605,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 609,indent: 1,parent: 605,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "3.00",boardCards: "",
},
{
id: 610,indent: 0,parent: null,handNum: "456",wonOrLost: "0.00",startAmt: "70.38",endAmt: "70.38",finalHand: "",position: "Dealer (7 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 611,indent: 1,parent: 610,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 612,indent: 0,parent: null,handNum: "457",wonOrLost: "0.00",startAmt: "70.38",endAmt: "70.38",finalHand: "",position: "Cutoff (6 of 7)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 613,indent: 1,parent: 612,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 614,indent: 0,parent: null,handNum: "458",wonOrLost: "-0.50",startAmt: "70.38",endAmt: "69.88",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 615,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 616,indent: 1,parent: 614,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.75",boardCards: "",
},
{
id: 617,indent: 0,parent: null,handNum: "459",wonOrLost: "0.00",startAmt: "69.88",endAmt: "69.88",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 618,indent: 1,parent: 617,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 619,indent: 0,parent: null,handNum: "460",wonOrLost: "-0.50",startAmt: "69.88",endAmt: "69.38",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 620,indent: 1,parent: 619,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 621,indent: 1,parent: 619,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 622,indent: 1,parent: 619,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 623,indent: 0,parent: null,handNum: "461",wonOrLost: "-0.25",startAmt: "69.38",endAmt: "69.13",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 624,indent: 1,parent: 623,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 625,indent: 1,parent: 623,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 626,indent: 0,parent: null,handNum: "462",wonOrLost: "0.00",startAmt: "69.13",endAmt: "69.13",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 627,indent: 1,parent: 626,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 628,indent: 0,parent: null,handNum: "463",wonOrLost: "-0.50",startAmt: "69.13",endAmt: "68.63",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 629,indent: 1,parent: 628,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 630,indent: 1,parent: 628,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 631,indent: 1,parent: 628,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 632,indent: 1,parent: 628,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 633,indent: 0,parent: null,handNum: "464",wonOrLost: "-10.50",startAmt: "68.63",endAmt: "58.13",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 634,indent: 1,parent: 633,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 635,indent: 1,parent: 633,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "4.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 636,indent: 1,parent: 633,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "3.50",potSizeToWin: "11.00",amountToPot: "31",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Dave",lastActionAmount: "5.00",boardCards: "",
},
{
id: 637,indent: 1,parent: 633,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "14.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 638,indent: 1,parent: 633,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "4.00",potSizeToWin: "18.50",amountToPot: "21",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "4.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 639,indent: 0,parent: null,handNum: "465",wonOrLost: "-2.50",startAmt: "58.13",endAmt: "55.63",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 640,indent: 1,parent: 639,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 641,indent: 1,parent: 639,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 642,indent: 1,parent: 639,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 643,indent: 1,parent: 639,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "2.50",amountToPot: "60",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 644,indent: 1,parent: 639,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 645,indent: 0,parent: null,handNum: "466",wonOrLost: "-0.25",startAmt: "55.63",endAmt: "55.38",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 646,indent: 1,parent: 645,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 647,indent: 1,parent: 645,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 648,indent: 0,parent: null,handNum: "467",wonOrLost: "-0.50",startAmt: "55.38",endAmt: "54.88",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 649,indent: 1,parent: 648,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 650,indent: 1,parent: 648,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "2.25",boardCards: "",
},
{
id: 651,indent: 0,parent: null,handNum: "468",wonOrLost: "0.00",startAmt: "54.88",endAmt: "54.88",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 652,indent: 1,parent: 651,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 653,indent: 0,parent: null,handNum: "469",wonOrLost: "0.00",startAmt: "54.88",endAmt: "54.88",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 654,indent: 1,parent: 653,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 655,indent: 0,parent: null,handNum: "470",wonOrLost: "-0.50",startAmt: "54.88",endAmt: "54.38",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 656,indent: 1,parent: 655,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 657,indent: 1,parent: 655,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Chris Moy",lastActionAmount: "4.25",boardCards: "",
},
{
id: 658,indent: 0,parent: null,handNum: "471",wonOrLost: "30.75",startAmt: "54.38",endAmt: "71.38",finalHand: "Three of a Kind, 5's",position: "SB (1 of 5)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 659,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 660,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "4.25",amountToPot: "35",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.75",boardCards: "",
},
{
id: 661,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.00",potSizeToWin: "5.75",amountToPot: "17",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 662,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "4.50",potSizeToWin: "13.25",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "5.50",boardCards: "",
},
{
id: 663,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "17.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 664,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "4.50",potSizeToWin: "22.25",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "4.50",boardCards: "",
},
{
id: 665,indent: 1,parent: 658,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "2.00",potSizeToWin: "26.75",amountToPot: "7",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 666,indent: 0,parent: null,handNum: "472",wonOrLost: "0.00",startAmt: "71.38",endAmt: "71.38",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 667,indent: 1,parent: 666,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 668,indent: 0,parent: null,handNum: "473",wonOrLost: "-1.50",startAmt: "71.38",endAmt: "69.88",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 669,indent: 1,parent: 668,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 670,indent: 1,parent: 668,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "3.75",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 671,indent: 0,parent: null,handNum: "474",wonOrLost: "0.00",startAmt: "69.88",endAmt: "69.88",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 672,indent: 1,parent: 671,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 673,indent: 0,parent: null,handNum: "475",wonOrLost: "-0.50",startAmt: "69.88",endAmt: "69.38",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 674,indent: 1,parent: 673,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 675,indent: 1,parent: 673,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 676,indent: 1,parent: 673,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 677,indent: 1,parent: 673,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 678,indent: 0,parent: null,handNum: "476",wonOrLost: "-0.25",startAmt: "69.38",endAmt: "69.13",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 679,indent: 1,parent: 678,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 680,indent: 1,parent: 678,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 681,indent: 0,parent: null,handNum: "477",wonOrLost: "0.00",startAmt: "69.13",endAmt: "69.13",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 682,indent: 1,parent: 681,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 683,indent: 0,parent: null,handNum: "478",wonOrLost: "-1.50",startAmt: "69.13",endAmt: "67.63",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 684,indent: 1,parent: 683,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "1.25",amountToPot: "120",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 685,indent: 1,parent: 683,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.12",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.37",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 686,indent: 0,parent: null,handNum: "479",wonOrLost: "-3.00",startAmt: "67.63",endAmt: "64.63",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 687,indent: 1,parent: 686,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 688,indent: 1,parent: 686,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "6.75",amountToPot: "22",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "3.00",boardCards: "",
},
{
id: 689,indent: 1,parent: 686,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "9.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 690,indent: 1,parent: 686,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "14.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "5.00",boardCards: "",
},
{
id: 691,indent: 0,parent: null,handNum: "480",wonOrLost: "3.00",startAmt: "64.63",endAmt: "66.13",finalHand: "",position: "BB (2 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 692,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 693,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 694,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 695,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 696,indent: 1,parent: 691,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 697,indent: 0,parent: null,handNum: "481",wonOrLost: "1.00",startAmt: "66.13",endAmt: "66.63",finalHand: "",position: "SB (1 of 5)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 698,indent: 1,parent: 697,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 699,indent: 1,parent: 697,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 700,indent: 1,parent: 697,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 701,indent: 0,parent: null,handNum: "482",wonOrLost: "16.49",startAmt: "66.63",endAmt: "76.50",finalHand: "",position: "Dealer (5 of 5)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 702,indent: 1,parent: 701,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "3.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 703,indent: 1,parent: 701,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "8.24",potSizeToWin: "12.37",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.12",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 704,indent: 0,parent: null,handNum: "483",wonOrLost: "0.00",startAmt: "76.50",endAmt: "76.50",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 705,indent: 1,parent: 704,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 706,indent: 0,parent: null,handNum: "484",wonOrLost: "0.00",startAmt: "76.50",endAmt: "76.50",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 707,indent: 1,parent: 706,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 708,indent: 0,parent: null,handNum: "485",wonOrLost: "-0.50",startAmt: "76.50",endAmt: "76.00",finalHand: "",position: "BB (2 of 5)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 709,indent: 1,parent: 708,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 710,indent: 1,parent: 708,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 711,indent: 1,parent: 708,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 712,indent: 0,parent: null,handNum: "486",wonOrLost: "-0.25",startAmt: "76.00",endAmt: "75.75",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 713,indent: 1,parent: 712,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 714,indent: 1,parent: 712,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 715,indent: 0,parent: null,handNum: "487",wonOrLost: "-6.50",startAmt: "75.75",endAmt: "69.25",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 716,indent: 1,parent: 715,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 717,indent: 1,parent: 715,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 718,indent: 1,parent: 715,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "4.50",potSizeToWin: "6.00",amountToPot: "75",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 719,indent: 1,parent: 715,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "13.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 720,indent: 0,parent: null,handNum: "488",wonOrLost: "-5.00",startAmt: "69.25",endAmt: "64.25",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 721,indent: 1,parent: 720,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "3.25",amountToPot: "76",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "",
},
{
id: 722,indent: 1,parent: 720,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.50",potSizeToWin: "8.00",amountToPot: "31",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 723,indent: 1,parent: 720,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "18.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Chris Moy",lastActionAmount: "7.50",boardCards: "",
},
{
id: 724,indent: 0,parent: null,handNum: "489",wonOrLost: "0.00",startAmt: "64.25",endAmt: "64.25",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 725,indent: 1,parent: 724,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 726,indent: 0,parent: null,handNum: "490",wonOrLost: "-1.50",startAmt: "64.25",endAmt: "62.75",finalHand: "",position: "BB (2 of 5)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 727,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 728,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.25",amountToPot: "44",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.50",boardCards: "",
},
{
id: 729,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 730,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 731,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 732,indent: 0,parent: null,handNum: "491",wonOrLost: "-0.25",startAmt: "62.75",endAmt: "62.50",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 733,indent: 1,parent: 732,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 734,indent: 1,parent: 732,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 735,indent: 0,parent: null,handNum: "492",wonOrLost: "0.00",startAmt: "62.50",endAmt: "62.50",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 736,indent: 1,parent: 735,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 737,indent: 0,parent: null,handNum: "493",wonOrLost: "0.00",startAmt: "62.50",endAmt: "62.50",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 738,indent: 1,parent: 737,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 739,indent: 0,parent: null,handNum: "494",wonOrLost: "4.75",startAmt: "62.50",endAmt: "65.75",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 740,indent: 1,parent: 739,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.75",amountToPot: "200",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 741,indent: 1,parent: 739,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "4.75",amountToPot: "31",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 742,indent: 0,parent: null,handNum: "495",wonOrLost: "3.00",startAmt: "65.75",endAmt: "67.25",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 743,indent: 1,parent: 742,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 744,indent: 1,parent: 742,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 745,indent: 1,parent: 742,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 746,indent: 1,parent: 742,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 747,indent: 0,parent: null,handNum: "496",wonOrLost: "-0.25",startAmt: "67.25",endAmt: "67.00",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 748,indent: 1,parent: 747,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 749,indent: 1,parent: 747,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 750,indent: 0,parent: null,handNum: "497",wonOrLost: "0.00",startAmt: "67.00",endAmt: "67.00",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 751,indent: 1,parent: 750,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "3.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 752,indent: 0,parent: null,handNum: "498",wonOrLost: "-5.50",startAmt: "67.00",endAmt: "61.50",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 753,indent: 1,parent: 752,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 754,indent: 1,parent: 752,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "6.00",amountToPot: "41",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 755,indent: 1,parent: 752,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.50",potSizeToWin: "13.50",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 756,indent: 1,parent: 752,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "18.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 757,indent: 1,parent: 752,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "28.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "10.00",boardCards: "",
},
{
id: 758,indent: 0,parent: null,handNum: "499",wonOrLost: "27.00",startAmt: "61.50",endAmt: "76.50",finalHand: "Three of a Kind, 3's",position: "BB (2 of 4)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 759,indent: 1,parent: 758,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "0.50",amountToPot: "300",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 760,indent: 1,parent: 758,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "6.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 761,indent: 1,parent: 758,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 762,indent: 1,parent: 758,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Raise",amount: "9.00",potSizeToWin: "13.50",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "4.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 763,indent: 0,parent: null,handNum: "500",wonOrLost: "-0.50",startAmt: "76.50",endAmt: "76.00",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 764,indent: 1,parent: 763,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 765,indent: 1,parent: 763,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 766,indent: 0,parent: null,handNum: "501",wonOrLost: "-0.50",startAmt: "76.00",endAmt: "75.50",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 767,indent: 1,parent: 766,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 768,indent: 1,parent: 766,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 769,indent: 1,parent: 766,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 770,indent: 1,parent: 766,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 771,indent: 0,parent: null,handNum: "502",wonOrLost: "3.50",startAmt: "75.50",endAmt: "78.00",finalHand: "",position: "Dealer (4 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 772,indent: 1,parent: 771,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 773,indent: 1,parent: 771,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 774,indent: 1,parent: 771,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.00",potSizeToWin: "3.50",amountToPot: "28",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 775,indent: 0,parent: null,handNum: "503",wonOrLost: "3.00",startAmt: "78.00",endAmt: "80.00",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 776,indent: 1,parent: 775,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 777,indent: 1,parent: 775,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 778,indent: 1,parent: 775,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 779,indent: 0,parent: null,handNum: "504",wonOrLost: "3.50",startAmt: "80.00",endAmt: "82.00",finalHand: "",position: "BB (2 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 780,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 781,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 782,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 783,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 784,indent: 0,parent: null,handNum: "505",wonOrLost: "-0.50",startAmt: "82.00",endAmt: "81.50",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 785,indent: 1,parent: 784,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 786,indent: 1,parent: 784,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 787,indent: 1,parent: 784,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 788,indent: 1,parent: 784,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 789,indent: 1,parent: 784,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.25",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 790,indent: 0,parent: null,handNum: "506",wonOrLost: "0.00",startAmt: "81.50",endAmt: "81.50",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 791,indent: 1,parent: 790,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 792,indent: 0,parent: null,handNum: "507",wonOrLost: "-0.50",startAmt: "81.50",endAmt: "81.00",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 793,indent: 1,parent: 792,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 794,indent: 1,parent: 792,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 795,indent: 0,parent: null,handNum: "508",wonOrLost: "2.25",startAmt: "81.00",endAmt: "82.25",finalHand: "",position: "BB (2 of 4)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 796,indent: 1,parent: 795,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 797,indent: 1,parent: 795,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 798,indent: 1,parent: 795,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 799,indent: 0,parent: null,handNum: "509",wonOrLost: "-0.50",startAmt: "82.25",endAmt: "81.75",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 800,indent: 1,parent: 799,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 801,indent: 1,parent: 799,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 802,indent: 1,parent: 799,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 803,indent: 1,parent: 799,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.25",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 804,indent: 0,parent: null,handNum: "510",wonOrLost: "-0.50",startAmt: "81.75",endAmt: "81.25",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 805,indent: 1,parent: 804,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 806,indent: 1,parent: 804,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 807,indent: 0,parent: null,handNum: "511",wonOrLost: "-1.00",startAmt: "81.25",endAmt: "80.25",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 808,indent: 1,parent: 807,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 809,indent: 1,parent: 807,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "0.75",boardCards: "",
},
{
id: 810,indent: 1,parent: 807,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "DanC",lastActionAmount: "1.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 811,indent: 0,parent: null,handNum: "512",wonOrLost: "2.25",startAmt: "80.25",endAmt: "81.50",finalHand: "",position: "BB (2 of 4)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 812,indent: 1,parent: 811,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 813,indent: 1,parent: 811,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "DanC",lastActionAmount: "1.00",boardCards: "",
},
{
id: 814,indent: 1,parent: 811,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 815,indent: 1,parent: 811,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 816,indent: 0,parent: null,handNum: "513",wonOrLost: "5.00",startAmt: "81.50",endAmt: "84.50",finalHand: "",position: "SB (1 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 817,indent: 1,parent: 816,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 818,indent: 1,parent: 816,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 819,indent: 1,parent: 816,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 820,indent: 1,parent: 816,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.00",potSizeToWin: "3.00",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 821,indent: 1,parent: 816,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "2.00",potSizeToWin: "5.00",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 822,indent: 0,parent: null,handNum: "514",wonOrLost: "0.00",startAmt: "84.50",endAmt: "84.50",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 823,indent: 1,parent: 822,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 824,indent: 0,parent: null,handNum: "515",wonOrLost: "0.00",startAmt: "84.50",endAmt: "84.50",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 825,indent: 1,parent: 824,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 826,indent: 0,parent: null,handNum: "516",wonOrLost: "-0.50",startAmt: "84.50",endAmt: "84.00",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 827,indent: 1,parent: 826,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 828,indent: 1,parent: 826,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "",
},
{
id: 829,indent: 0,parent: null,handNum: "517",wonOrLost: "-0.25",startAmt: "84.00",endAmt: "83.75",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 830,indent: 1,parent: 829,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 831,indent: 1,parent: 829,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 832,indent: 0,parent: null,handNum: "518",wonOrLost: "0.00",startAmt: "83.75",endAmt: "83.75",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 833,indent: 1,parent: 832,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 834,indent: 0,parent: null,handNum: "519",wonOrLost: "0.00",startAmt: "83.75",endAmt: "83.75",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 835,indent: 1,parent: 834,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 836,indent: 0,parent: null,handNum: "520",wonOrLost: "6.00",startAmt: "83.75",endAmt: "87.00",finalHand: "",position: "BB (2 of 4)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 837,indent: 1,parent: 836,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 838,indent: 1,parent: 836,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 839,indent: 1,parent: 836,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.75",potSizeToWin: "2.25",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.75",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 840,indent: 1,parent: 836,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 841,indent: 1,parent: 836,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "3.00",potSizeToWin: "6.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 842,indent: 0,parent: null,handNum: "521",wonOrLost: "-0.50",startAmt: "87.00",endAmt: "86.50",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 843,indent: 1,parent: 842,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 844,indent: 1,parent: 842,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 845,indent: 1,parent: 842,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 846,indent: 1,parent: 842,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "2.00",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 847,indent: 0,parent: null,handNum: "522",wonOrLost: "-1.50",startAmt: "86.50",endAmt: "85.00",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 848,indent: 1,parent: 847,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 849,indent: 1,parent: 847,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "8.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Greg",lastActionAmount: "4.75",boardCards: "",
},
{
id: 850,indent: 0,parent: null,handNum: "523",wonOrLost: "-1.00",startAmt: "85.00",endAmt: "84.00",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 851,indent: 1,parent: 850,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "0.75",amountToPot: "133",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 852,indent: 1,parent: 850,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "2.25",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 853,indent: 0,parent: null,handNum: "524",wonOrLost: "-5.37",startAmt: "84.00",endAmt: "78.63",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 854,indent: 1,parent: 853,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 855,indent: 1,parent: 853,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Reraise",amount: "2.00",potSizeToWin: "3.75",amountToPot: "53",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "",
},
{
id: 856,indent: 1,parent: 853,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.87",potSizeToWin: "7.75",amountToPot: "37",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 857,indent: 1,parent: 853,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "17.62",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "7.00",boardCards: "",
},
{
id: 858,indent: 0,parent: null,handNum: "525",wonOrLost: "5.00",startAmt: "78.63",endAmt: "82.13",finalHand: "",position: "SB (1 of 4)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 859,indent: 1,parent: 858,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 860,indent: 1,parent: 858,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "2.75",amountToPot: "45",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 861,indent: 1,parent: 858,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "5.00",amountToPot: "40",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 862,indent: 0,parent: null,handNum: "526",wonOrLost: "0.00",startAmt: "82.13",endAmt: "82.13",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 863,indent: 1,parent: 862,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 864,indent: 0,parent: null,handNum: "527",wonOrLost: "0.00",startAmt: "82.13",endAmt: "82.13",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 865,indent: 1,parent: 864,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 866,indent: 0,parent: null,handNum: "528",wonOrLost: "9.25",startAmt: "82.13",endAmt: "88.38",finalHand: "",position: "BB (2 of 4)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 867,indent: 1,parent: 866,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 868,indent: 1,parent: 866,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.50",potSizeToWin: "5.25",amountToPot: "47",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "3.00",boardCards: "",
},
{
id: 869,indent: 1,parent: 866,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "4.62",potSizeToWin: "9.25",amountToPot: "49",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 870,indent: 0,parent: null,handNum: "529",wonOrLost: "-0.25",startAmt: "88.38",endAmt: "88.13",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 871,indent: 1,parent: 870,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 872,indent: 1,parent: 870,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 873,indent: 0,parent: null,handNum: "530",wonOrLost: "0.00",startAmt: "88.13",endAmt: "88.13",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 874,indent: 1,parent: 873,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
{
id: 875,indent: 0,parent: null,handNum: "531",wonOrLost: "0.00",startAmt: "88.13",endAmt: "88.13",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 876,indent: 1,parent: 875,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 877,indent: 0,parent: null,handNum: "532",wonOrLost: "-0.50",startAmt: "88.13",endAmt: "87.63",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 878,indent: 1,parent: 877,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 879,indent: 1,parent: 877,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "DanC",lastActionAmount: "2.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 880,indent: 0,parent: null,handNum: "533",wonOrLost: "-0.25",startAmt: "87.63",endAmt: "87.38",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 881,indent: 1,parent: 880,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 882,indent: 1,parent: 880,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 883,indent: 0,parent: null,handNum: "534",wonOrLost: "0.00",startAmt: "87.38",endAmt: "87.38",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 884,indent: 1,parent: 883,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 885,indent: 0,parent: null,handNum: "535",wonOrLost: "0.00",startAmt: "87.38",endAmt: "87.38",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 886,indent: 1,parent: 885,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 887,indent: 0,parent: null,handNum: "536",wonOrLost: "-0.50",startAmt: "87.38",endAmt: "86.88",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 888,indent: 1,parent: 887,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 889,indent: 1,parent: 887,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Greg",lastActionAmount: "1.50",boardCards: "",
},
{
id: 890,indent: 0,parent: null,handNum: "537",wonOrLost: "-0.25",startAmt: "86.88",endAmt: "86.63",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 891,indent: 1,parent: 890,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 892,indent: 1,parent: 890,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 893,indent: 0,parent: null,handNum: "538",wonOrLost: "-1.50",startAmt: "86.63",endAmt: "85.13",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 894,indent: 1,parent: 893,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Chris Moy",lastActionAmount: "1.50",boardCards: "",
},
{
id: 895,indent: 1,parent: 893,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.62",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "1.87",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 896,indent: 0,parent: null,handNum: "539",wonOrLost: "-0.50",startAmt: "85.13",endAmt: "84.63",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 897,indent: 1,parent: 896,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "",
},
{
id: 898,indent: 1,parent: 896,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 899,indent: 1,parent: 896,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Greg",lastActionAmount: "1.25",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 900,indent: 0,parent: null,handNum: "540",wonOrLost: "2.00",startAmt: "84.63",endAmt: "85.63",finalHand: "",position: "BB (2 of 4)",holeCards: "6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 901,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 902,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 903,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 904,indent: 1,parent: 900,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "1.50",potSizeToWin: "1.50",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Chris Moy",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 905,indent: 0,parent: null,handNum: "541",wonOrLost: "17.00",startAmt: "85.63",endAmt: "96.63",finalHand: "Two Pair, K's & 10's",position: "SB (1 of 4)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 906,indent: 1,parent: 905,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 907,indent: 1,parent: 905,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Greg",lastActionAmount: "0.50",boardCards: "",
},
{
id: 908,indent: 1,parent: 905,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "2.00",amountToPot: "75",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 909,indent: 1,parent: 905,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.50",potSizeToWin: "6.50",amountToPot: "38",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 910,indent: 1,parent: 905,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.50",potSizeToWin: "14.00",amountToPot: "10",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 911,indent: 0,parent: null,handNum: "542",wonOrLost: "0.00",startAmt: "96.63",endAmt: "96.63",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 912,indent: 1,parent: 911,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "DanC",lastActionAmount: "0.50",boardCards: "",
},
];
