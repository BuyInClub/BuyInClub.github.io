﻿var title = "Hand Details for John P at Table2";
var handFilename = "Table2-Details.html";
var data = [
{
id: 0,indent: 0,parent: null,handNum: "1",wonOrLost: "-1.00",startAmt: "20.00",endAmt: "19.00",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 1,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 2,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "",
},
{
id: 3,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 4,indent: 1,parent: 0,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 5,indent: 0,parent: null,handNum: "2",wonOrLost: "-0.25",startAmt: "19.00",endAmt: "18.75",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 6,indent: 1,parent: 5,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 7,indent: 1,parent: 5,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 8,indent: 0,parent: null,handNum: "3",wonOrLost: "0.00",startAmt: "18.75",endAmt: "18.75",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 9,indent: 1,parent: 8,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 10,indent: 0,parent: null,handNum: "4",wonOrLost: "2.00",startAmt: "18.75",endAmt: "20.25",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 11,indent: 1,parent: 10,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 12,indent: 1,parent: 10,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "3.00",potSizeToWin: "2.00",amountToPot: "150",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 13,indent: 0,parent: null,handNum: "5",wonOrLost: "0.00",startAmt: "20.25",endAmt: "20.25",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 14,indent: 1,parent: 13,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 15,indent: 0,parent: null,handNum: "6",wonOrLost: "-1.00",startAmt: "20.25",endAmt: "19.25",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 16,indent: 1,parent: 15,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 17,indent: 1,parent: 15,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 18,indent: 1,parent: 15,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 19,indent: 1,parent: 15,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 20,indent: 1,parent: 15,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 21,indent: 0,parent: null,handNum: "7",wonOrLost: "-0.25",startAmt: "19.25",endAmt: "19.00",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 22,indent: 1,parent: 21,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 23,indent: 1,parent: 21,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 24,indent: 0,parent: null,handNum: "8",wonOrLost: "0.00",startAmt: "19.00",endAmt: "19.00",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 25,indent: 1,parent: 24,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 26,indent: 0,parent: null,handNum: "9",wonOrLost: "0.00",startAmt: "19.00",endAmt: "19.00",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 27,indent: 1,parent: 26,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 28,indent: 0,parent: null,handNum: "10",wonOrLost: "11.25",startAmt: "19.00",endAmt: "26.75",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 29,indent: 1,parent: 28,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 30,indent: 1,parent: 28,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.25",amountToPot: "23",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 31,indent: 1,parent: 28,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "6.75",amountToPot: "7",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 32,indent: 1,parent: 28,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "1.50",potSizeToWin: "8.25",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 33,indent: 1,parent: 28,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.50",potSizeToWin: "11.25",amountToPot: "13",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 34,indent: 0,parent: null,handNum: "11",wonOrLost: "-0.50",startAmt: "26.75",endAmt: "26.25",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 35,indent: 1,parent: 34,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 36,indent: 1,parent: 34,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 37,indent: 0,parent: null,handNum: "12",wonOrLost: "-8.75",startAmt: "26.25",endAmt: "17.50",finalHand: "",position: "SB (1 of 6)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 38,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 39,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 40,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.75",potSizeToWin: "2.50",amountToPot: "30",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 41,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.75",potSizeToWin: "4.75",amountToPot: "57",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 42,indent: 1,parent: 37,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "4.75",potSizeToWin: "10.25",amountToPot: "46",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 43,indent: 0,parent: null,handNum: "13",wonOrLost: "0.00",startAmt: "17.50",endAmt: "17.50",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 44,indent: 1,parent: 43,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 45,indent: 0,parent: null,handNum: "14",wonOrLost: "6.25",startAmt: "17.50",endAmt: "21.00",finalHand: "Two Pair, K's & 2's",position: "Cutoff (5 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 46,indent: 1,parent: 45,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 47,indent: 1,parent: 45,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "3.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 48,indent: 1,parent: 45,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 49,indent: 1,parent: 45,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 50,indent: 1,parent: 45,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "5.25",amountToPot: "9",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 51,indent: 0,parent: null,handNum: "15",wonOrLost: "0.00",startAmt: "21.00",endAmt: "21.00",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 52,indent: 1,parent: 51,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Arya",lastActionAmount: "1.00",boardCards: "",
},
{
id: 53,indent: 0,parent: null,handNum: "16",wonOrLost: "-2.25",startAmt: "21.00",endAmt: "18.75",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 54,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.25",potSizeToWin: "0.75",amountToPot: "166",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 55,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "5.00",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "1.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 56,indent: 1,parent: 53,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "2.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 57,indent: 0,parent: null,handNum: "17",wonOrLost: "-2.25",startAmt: "18.75",endAmt: "16.50",finalHand: "",position: "BB (2 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 58,indent: 1,parent: 57,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 59,indent: 1,parent: 57,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "0.75",potSizeToWin: "1.50",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 60,indent: 1,parent: 57,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 61,indent: 1,parent: 57,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "3.00",amountToPot: "16",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 62,indent: 1,parent: 57,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "0.50",potSizeToWin: "4.00",amountToPot: "12",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 63,indent: 1,parent: 57,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "3.00",boardCards: "",
},
{
id: 64,indent: 0,parent: null,handNum: "18",wonOrLost: "-0.50",startAmt: "16.50",endAmt: "16.00",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 65,indent: 1,parent: 64,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 66,indent: 1,parent: 64,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "0.75",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 67,indent: 1,parent: 64,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 68,indent: 1,parent: 64,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "1.00",boardCards: "",
},
{
id: 69,indent: 0,parent: null,handNum: "19",wonOrLost: "0.00",startAmt: "16.00",endAmt: "16.00",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 70,indent: 1,parent: 69,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 71,indent: 0,parent: null,handNum: "20",wonOrLost: "-1.00",startAmt: "16.00",endAmt: "15.00",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 72,indent: 1,parent: 71,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 73,indent: 1,parent: 71,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.25",amountToPot: "15",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 74,indent: 1,parent: 71,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.43",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "3.18",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 75,indent: 0,parent: null,handNum: "21",wonOrLost: "-2.00",startAmt: "15.00",endAmt: "13.00",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 76,indent: 1,parent: 75,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 77,indent: 1,parent: 75,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.75",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "1.00",boardCards: "",
},
{
id: 78,indent: 1,parent: 75,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "4.25",amountToPot: "23",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 79,indent: 1,parent: 75,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 80,indent: 0,parent: null,handNum: "22",wonOrLost: "0.00",startAmt: "13.00",endAmt: "13.00",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 81,indent: 1,parent: 80,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 82,indent: 0,parent: null,handNum: "23",wonOrLost: "-0.50",startAmt: "13.00",endAmt: "12.50",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 83,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 84,indent: 1,parent: 82,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 85,indent: 0,parent: null,handNum: "24",wonOrLost: "-0.25",startAmt: "12.50",endAmt: "12.25",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 86,indent: 1,parent: 85,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 87,indent: 1,parent: 85,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 88,indent: 0,parent: null,handNum: "25",wonOrLost: "3.00",startAmt: "12.25",endAmt: "14.00",finalHand: "",position: "Dealer (6 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 89,indent: 1,parent: 88,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.25",potSizeToWin: "0.75",amountToPot: "166",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 90,indent: 1,parent: 88,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 91,indent: 1,parent: 88,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.75",potSizeToWin: "3.00",amountToPot: "58",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 92,indent: 0,parent: null,handNum: "26",wonOrLost: "-2.62",startAmt: "14.00",endAmt: "11.38",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 93,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 94,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 95,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.62",potSizeToWin: "4.87",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "1.62",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 96,indent: 1,parent: 92,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "14.19",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "6.08",boardCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 97,indent: 0,parent: null,handNum: "27",wonOrLost: "1.25",startAmt: "11.38",endAmt: "12.13",finalHand: "",position: "MP1 (4 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 98,indent: 1,parent: 97,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 99,indent: 1,parent: 97,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.25",potSizeToWin: "1.25",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 100,indent: 0,parent: null,handNum: "28",wonOrLost: "-0.50",startAmt: "12.13",endAmt: "11.63",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 101,indent: 1,parent: 100,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 102,indent: 1,parent: 100,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 103,indent: 1,parent: 100,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 104,indent: 1,parent: 100,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 105,indent: 0,parent: null,handNum: "29",wonOrLost: "-0.50",startAmt: "11.63",endAmt: "11.13",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 106,indent: 1,parent: 105,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 107,indent: 1,parent: 105,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 108,indent: 0,parent: null,handNum: "30",wonOrLost: "-1.50",startAmt: "11.13",endAmt: "9.63",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 109,indent: 1,parent: 108,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 110,indent: 1,parent: 108,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.25",potSizeToWin: "3.75",amountToPot: "33",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 111,indent: 1,parent: 108,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 112,indent: 1,parent: 108,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 113,indent: 0,parent: null,handNum: "31",wonOrLost: "8.00",startAmt: "9.63",endAmt: "14.13",finalHand: "Two Pair, Q's & J's",position: "Dealer (6 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 114,indent: 1,parent: 113,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 115,indent: 1,parent: 113,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.75",potSizeToWin: "2.00",amountToPot: "87",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 116,indent: 1,parent: 113,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.25",potSizeToWin: "5.50",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 117,indent: 1,parent: 113,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "8.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 118,indent: 0,parent: null,handNum: "32",wonOrLost: "0.00",startAmt: "14.13",endAmt: "14.13",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 119,indent: 1,parent: 118,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 120,indent: 0,parent: null,handNum: "33",wonOrLost: "1.75",startAmt: "14.13",endAmt: "15.38",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 121,indent: 1,parent: 120,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "3.25",potSizeToWin: "1.25",amountToPot: "260",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 122,indent: 0,parent: null,handNum: "34",wonOrLost: "-0.50",startAmt: "15.38",endAmt: "14.88",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 123,indent: 1,parent: 122,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 124,indent: 1,parent: 122,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "2.00",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 125,indent: 0,parent: null,handNum: "35",wonOrLost: "-14.88",startAmt: "14.88",endAmt: "0.00",finalHand: "",position: "BB (2 of 6)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 126,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 127,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 128,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 129,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "4.00",amountToPot: "12",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.00",boardCards: "",
},
{
id: 130,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 131,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.50",potSizeToWin: "6.00",amountToPot: "25",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 132,indent: 1,parent: 125,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "BetAllIn",amount: "11.88",potSizeToWin: "7.50",amountToPot: "158",numPlayers: "2",numAllIns: "1",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 133,indent: 0,parent: null,handNum: "38",wonOrLost: "5.25",startAmt: "20.00",endAmt: "23.25",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 134,indent: 1,parent: 133,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 135,indent: 1,parent: 133,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "3.75",amountToPot: "40",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 136,indent: 1,parent: 133,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 137,indent: 1,parent: 133,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "5.25",potSizeToWin: "5.25",amountToPot: "100",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 138,indent: 0,parent: null,handNum: "39",wonOrLost: "-2.25",startAmt: "23.25",endAmt: "21.00",finalHand: "",position: "MP1 (4 of 6)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 139,indent: 1,parent: 138,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 140,indent: 1,parent: 138,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "3.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 141,indent: 1,parent: 138,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 142,indent: 1,parent: 138,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 143,indent: 1,parent: 138,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 144,indent: 0,parent: null,handNum: "40",wonOrLost: "-19.50",startAmt: "21.00",endAmt: "1.50",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 145,indent: 1,parent: 144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "0.75",amountToPot: "133",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 146,indent: 1,parent: 144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.62",potSizeToWin: "3.25",amountToPot: "49",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 147,indent: 1,parent: 144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "6.08",potSizeToWin: "8.11",amountToPot: "74",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 148,indent: 1,parent: 144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "20.27",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 149,indent: 1,parent: 144,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "10.80",potSizeToWin: "31.07",amountToPot: "34",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "Doug",lastActionAmount: "10.80",boardCards: "",
},
{
id: 150,indent: 0,parent: null,handNum: "41",wonOrLost: "-1.50",startAmt: "1.50",endAmt: "0.00",finalHand: "",position: "BB (2 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 151,indent: 1,parent: 150,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 152,indent: 1,parent: 150,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.25",amountToPot: "15",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "",
},
{
id: 153,indent: 1,parent: 150,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 154,indent: 1,parent: 150,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 155,indent: 1,parent: 150,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "CallAllIn",amount: "0.50",potSizeToWin: "4.75",amountToPot: "10",numPlayers: "3",numAllIns: "1",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 156,indent: 0,parent: null,handNum: "51",wonOrLost: "0.00",startAmt: "40.00",endAmt: "40.00",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 157,indent: 1,parent: 156,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 158,indent: 0,parent: null,handNum: "52",wonOrLost: "-3.50",startAmt: "40.00",endAmt: "36.50",finalHand: "",position: "BB (2 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 159,indent: 1,parent: 158,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 160,indent: 1,parent: 158,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "2.75",amountToPot: "36",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 161,indent: 1,parent: 158,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 162,indent: 1,parent: 158,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "5.25",amountToPot: "9",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 163,indent: 1,parent: 158,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 164,indent: 1,parent: 158,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.50",potSizeToWin: "7.75",amountToPot: "19",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 165,indent: 1,parent: 158,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "9.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 166,indent: 0,parent: null,handNum: "53",wonOrLost: "-0.25",startAmt: "36.50",endAmt: "36.25",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 167,indent: 1,parent: 166,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 168,indent: 1,parent: 166,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 169,indent: 0,parent: null,handNum: "54",wonOrLost: "0.00",startAmt: "36.25",endAmt: "36.25",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 170,indent: 1,parent: 169,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 171,indent: 0,parent: null,handNum: "55",wonOrLost: "1.25",startAmt: "36.25",endAmt: "37.00",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 172,indent: 1,parent: 171,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "0.75",amountToPot: "133",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 173,indent: 0,parent: null,handNum: "56",wonOrLost: "-0.50",startAmt: "37.00",endAmt: "36.50",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 174,indent: 1,parent: 173,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 175,indent: 1,parent: 173,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 176,indent: 0,parent: null,handNum: "57",wonOrLost: "0.00",startAmt: "36.50",endAmt: "36.50",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 177,indent: 1,parent: 176,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 178,indent: 0,parent: null,handNum: "58",wonOrLost: "4.50",startAmt: "36.50",endAmt: "39.00",finalHand: "",position: "BB (2 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 179,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 180,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 181,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 182,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "3.50",amountToPot: "28",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 183,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 184,indent: 1,parent: 178,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.25",potSizeToWin: "4.50",amountToPot: "27",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 185,indent: 0,parent: null,handNum: "59",wonOrLost: "-0.25",startAmt: "39.00",endAmt: "38.75",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 186,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 187,indent: 1,parent: 185,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 188,indent: 0,parent: null,handNum: "60",wonOrLost: "0.00",startAmt: "38.75",endAmt: "38.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 189,indent: 1,parent: 188,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 190,indent: 0,parent: null,handNum: "61",wonOrLost: "1.25",startAmt: "38.75",endAmt: "39.50",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 191,indent: 1,parent: 190,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 192,indent: 1,parent: 190,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 193,indent: 0,parent: null,handNum: "62",wonOrLost: "-1.00",startAmt: "39.50",endAmt: "38.50",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 194,indent: 1,parent: 193,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 195,indent: 1,parent: 193,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.50",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "0.75",boardCards: "",
},
{
id: 196,indent: 1,parent: 193,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 197,indent: 1,parent: 193,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 198,indent: 1,parent: 193,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Arya",lastActionAmount: "3.00",boardCards: "",
},
{
id: 199,indent: 0,parent: null,handNum: "63",wonOrLost: "-1.50",startAmt: "38.50",endAmt: "37.00",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 200,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 201,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.00",amountToPot: "25",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.50",boardCards: "",
},
{
id: 202,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 203,indent: 1,parent: 199,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "3.75",boardCards: "",
},
{
id: 204,indent: 0,parent: null,handNum: "64",wonOrLost: "-2.25",startAmt: "37.00",endAmt: "34.75",finalHand: "",position: "BB (2 of 6)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 205,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 206,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "5.00",amountToPot: "35",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 207,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 208,indent: 1,parent: 204,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "11.81",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "5.06",boardCards: "",
},
{
id: 209,indent: 0,parent: null,handNum: "65",wonOrLost: "-0.25",startAmt: "34.75",endAmt: "34.50",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 210,indent: 1,parent: 209,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 211,indent: 1,parent: 209,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 212,indent: 0,parent: null,handNum: "66",wonOrLost: "0.00",startAmt: "34.50",endAmt: "34.50",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 213,indent: 1,parent: 212,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 214,indent: 0,parent: null,handNum: "67",wonOrLost: "0.00",startAmt: "34.50",endAmt: "34.50",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 215,indent: 1,parent: 214,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 216,indent: 0,parent: null,handNum: "68",wonOrLost: "0.00",startAmt: "34.50",endAmt: "34.50",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 217,indent: 1,parent: 216,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "1",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 218,indent: 0,parent: null,handNum: "69",wonOrLost: "0.00",startAmt: "34.50",endAmt: "34.50",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 219,indent: 1,parent: 218,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 220,indent: 0,parent: null,handNum: "70",wonOrLost: "-0.50",startAmt: "34.50",endAmt: "34.00",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 221,indent: 1,parent: 220,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 222,indent: 1,parent: 220,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 223,indent: 0,parent: null,handNum: "71",wonOrLost: "-0.25",startAmt: "34.00",endAmt: "33.75",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 224,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 225,indent: 1,parent: 223,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 226,indent: 0,parent: null,handNum: "72",wonOrLost: "0.00",startAmt: "33.75",endAmt: "33.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 227,indent: 1,parent: 226,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 228,indent: 0,parent: null,handNum: "73",wonOrLost: "-1.50",startAmt: "33.75",endAmt: "32.25",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 229,indent: 1,parent: 228,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 230,indent: 1,parent: 228,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "13.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "6.50",boardCards: "",
},
{
id: 231,indent: 0,parent: null,handNum: "74",wonOrLost: "0.00",startAmt: "32.25",endAmt: "32.25",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 232,indent: 1,parent: 231,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 233,indent: 0,parent: null,handNum: "75",wonOrLost: "0.00",startAmt: "32.25",endAmt: "32.25",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 234,indent: 1,parent: 233,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 235,indent: 0,parent: null,handNum: "76",wonOrLost: "2.50",startAmt: "32.25",endAmt: "34.25",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 236,indent: 1,parent: 235,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 237,indent: 1,parent: 235,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 238,indent: 1,parent: 235,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.50",potSizeToWin: "2.50",amountToPot: "100",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 239,indent: 0,parent: null,handNum: "77",wonOrLost: "-0.50",startAmt: "34.25",endAmt: "33.75",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 240,indent: 1,parent: 239,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 241,indent: 1,parent: 239,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 242,indent: 1,parent: 239,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 243,indent: 1,parent: 239,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.00",boardCards: "",
},
{
id: 244,indent: 0,parent: null,handNum: "78",wonOrLost: "0.00",startAmt: "33.75",endAmt: "33.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 245,indent: 1,parent: 244,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 246,indent: 0,parent: null,handNum: "79",wonOrLost: "-1.00",startAmt: "33.75",endAmt: "32.75",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 247,indent: 1,parent: 246,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 248,indent: 1,parent: 246,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 249,indent: 1,parent: 246,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.50",potSizeToWin: "2.75",amountToPot: "18",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 250,indent: 1,parent: 246,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "3.75",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 251,indent: 0,parent: null,handNum: "80",wonOrLost: "0.00",startAmt: "32.75",endAmt: "32.75",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 252,indent: 1,parent: 251,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 253,indent: 0,parent: null,handNum: "81",wonOrLost: "-1.62",startAmt: "32.75",endAmt: "31.13",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 254,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 255,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.12",potSizeToWin: "4.74",amountToPot: "23",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.62",boardCards: "",
},
{
id: 256,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.98",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 257,indent: 1,parent: 253,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "12.21",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "5.23",boardCards: "",
},
{
id: 258,indent: 0,parent: null,handNum: "82",wonOrLost: "-0.50",startAmt: "31.13",endAmt: "30.63",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 259,indent: 1,parent: 258,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 260,indent: 1,parent: 258,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 261,indent: 0,parent: null,handNum: "83",wonOrLost: "-0.25",startAmt: "30.63",endAmt: "30.38",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 262,indent: 1,parent: 261,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 263,indent: 1,parent: 261,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 264,indent: 0,parent: null,handNum: "84",wonOrLost: "-1.50",startAmt: "30.38",endAmt: "28.88",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 265,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 266,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "",
},
{
id: 267,indent: 1,parent: 264,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "18.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "6.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 268,indent: 0,parent: null,handNum: "85",wonOrLost: "0.00",startAmt: "28.88",endAmt: "28.88",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 269,indent: 1,parent: 268,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 270,indent: 0,parent: null,handNum: "86",wonOrLost: "0.00",startAmt: "28.88",endAmt: "28.88",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 271,indent: 1,parent: 270,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 272,indent: 0,parent: null,handNum: "87",wonOrLost: "0.00",startAmt: "28.88",endAmt: "28.88",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 273,indent: 1,parent: 272,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 274,indent: 0,parent: null,handNum: "88",wonOrLost: "-11.75",startAmt: "28.88",endAmt: "17.13",finalHand: "",position: "BB (2 of 6)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 275,indent: 1,parent: 274,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 276,indent: 1,parent: 274,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 277,indent: 1,parent: 274,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 278,indent: 1,parent: 274,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "3.50",amountToPot: "42",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 279,indent: 1,parent: 274,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "8.00",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Craig",lastActionAmount: "3.00",boardCards: "",
},
{
id: 280,indent: 1,parent: 274,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "4.75",potSizeToWin: "9.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 281,indent: 1,parent: 274,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.50",potSizeToWin: "22.50",amountToPot: "15",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "RaiseAllIn",lastActionPlayer: "Craig",lastActionAmount: "8.25",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 282,indent: 0,parent: null,handNum: "89",wonOrLost: "3.74",startAmt: "17.13",endAmt: "19.25",finalHand: "",position: "SB (1 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 283,indent: 1,parent: 282,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 284,indent: 1,parent: 282,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 285,indent: 1,parent: 282,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 286,indent: 1,parent: 282,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.12",potSizeToWin: "1.50",amountToPot: "74",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 287,indent: 1,parent: 282,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "2.80",potSizeToWin: "3.74",amountToPot: "74",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 288,indent: 0,parent: null,handNum: "90",wonOrLost: "1.75",startAmt: "19.25",endAmt: "20.50",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 289,indent: 1,parent: 288,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "3.25",potSizeToWin: "1.25",amountToPot: "260",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 290,indent: 0,parent: null,handNum: "91",wonOrLost: "0.00",startAmt: "20.50",endAmt: "20.50",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 291,indent: 1,parent: 290,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 292,indent: 0,parent: null,handNum: "92",wonOrLost: "-0.50",startAmt: "20.50",endAmt: "20.00",finalHand: "",position: "MP1 (4 of 6)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 293,indent: 1,parent: 292,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 294,indent: 1,parent: 292,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "2.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 295,indent: 0,parent: null,handNum: "93",wonOrLost: "-20.00",startAmt: "20.00",endAmt: "0.00",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 296,indent: 1,parent: 295,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 297,indent: 1,parent: 295,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.75",amountToPot: "18",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "",
},
{
id: 298,indent: 1,parent: 295,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.25",potSizeToWin: "3.75",amountToPot: "60",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 299,indent: 1,parent: 295,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.25",potSizeToWin: "12.75",amountToPot: "17",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "4.50",boardCards: "",
},
{
id: 300,indent: 1,parent: 295,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "5.00",potSizeToWin: "17.25",amountToPot: "28",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 301,indent: 1,parent: 295,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "ReraiseAllIn",amount: "9.50",potSizeToWin: "32.25",amountToPot: "29",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "10.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 302,indent: 0,parent: null,handNum: "95",wonOrLost: "-0.50",startAmt: "40.00",endAmt: "39.50",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 303,indent: 1,parent: 302,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 304,indent: 1,parent: 302,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Doug",lastActionAmount: "3.25",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 305,indent: 0,parent: null,handNum: "96",wonOrLost: "-0.25",startAmt: "39.50",endAmt: "39.25",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 306,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 307,indent: 1,parent: 305,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.75",boardCards: "",
},
{
id: 308,indent: 0,parent: null,handNum: "97",wonOrLost: "-0.50",startAmt: "39.25",endAmt: "38.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 309,indent: 1,parent: 308,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 310,indent: 1,parent: 308,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 311,indent: 0,parent: null,handNum: "98",wonOrLost: "0.00",startAmt: "38.75",endAmt: "38.75",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 312,indent: 1,parent: 311,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 313,indent: 0,parent: null,handNum: "99",wonOrLost: "0.00",startAmt: "38.75",endAmt: "38.75",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 314,indent: 1,parent: 313,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 315,indent: 0,parent: null,handNum: "100",wonOrLost: "0.00",startAmt: "38.75",endAmt: "38.75",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 316,indent: 1,parent: 315,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 317,indent: 0,parent: null,handNum: "101",wonOrLost: "-0.50",startAmt: "38.75",endAmt: "38.25",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 318,indent: 1,parent: 317,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 319,indent: 1,parent: 317,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 320,indent: 0,parent: null,handNum: "102",wonOrLost: "-0.25",startAmt: "38.25",endAmt: "38.00",finalHand: "",position: "SB (1 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 321,indent: 1,parent: 320,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 322,indent: 1,parent: 320,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "3.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 323,indent: 0,parent: null,handNum: "103",wonOrLost: "0.00",startAmt: "38.00",endAmt: "38.00",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 324,indent: 1,parent: 323,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 325,indent: 0,parent: null,handNum: "104",wonOrLost: "2.25",startAmt: "38.00",endAmt: "39.25",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 326,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 327,indent: 1,parent: 325,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "2.50",potSizeToWin: "1.75",amountToPot: "142",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 328,indent: 0,parent: null,handNum: "105",wonOrLost: "-2.00",startAmt: "39.25",endAmt: "37.25",finalHand: "",position: "MP1 (4 of 6)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 329,indent: 1,parent: 328,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 330,indent: 1,parent: 328,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 331,indent: 1,parent: 328,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "4.00",amountToPot: "37",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "1.50",boardCards: "",
},
{
id: 332,indent: 1,parent: 328,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 333,indent: 1,parent: 328,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "5.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 334,indent: 0,parent: null,handNum: "106",wonOrLost: "-2.00",startAmt: "37.25",endAmt: "35.25",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 335,indent: 1,parent: 334,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 336,indent: 1,parent: 334,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 337,indent: 1,parent: 334,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.00",potSizeToWin: "3.50",amountToPot: "28",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "1.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 338,indent: 1,parent: 334,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "9.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "5.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 339,indent: 0,parent: null,handNum: "107",wonOrLost: "-0.50",startAmt: "35.25",endAmt: "34.75",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 340,indent: 1,parent: 339,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 341,indent: 1,parent: 339,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 342,indent: 1,parent: 339,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 343,indent: 1,parent: 339,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, [7<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 344,indent: 0,parent: null,handNum: "108",wonOrLost: "-2.00",startAmt: "34.75",endAmt: "32.75",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 345,indent: 1,parent: 344,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 346,indent: 1,parent: 344,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.75",potSizeToWin: "5.25",amountToPot: "33",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 347,indent: 1,parent: 344,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 348,indent: 1,parent: 344,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "15.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "4.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 349,indent: 0,parent: null,handNum: "109",wonOrLost: "0.00",startAmt: "32.75",endAmt: "32.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 350,indent: 1,parent: 349,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 351,indent: 0,parent: null,handNum: "110",wonOrLost: "5.25",startAmt: "32.75",endAmt: "35.75",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 352,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.25",potSizeToWin: "1.25",amountToPot: "180",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 353,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 354,indent: 1,parent: 351,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.62",potSizeToWin: "5.25",amountToPot: "49",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 355,indent: 0,parent: null,handNum: "111",wonOrLost: "-0.50",startAmt: "35.75",endAmt: "35.25",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 356,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 357,indent: 1,parent: 355,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, [7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 358,indent: 0,parent: null,handNum: "112",wonOrLost: "0.00",startAmt: "35.25",endAmt: "35.25",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 359,indent: 1,parent: 358,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 360,indent: 0,parent: null,handNum: "113",wonOrLost: "-0.50",startAmt: "35.25",endAmt: "34.75",finalHand: "",position: "BB (2 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 361,indent: 1,parent: 360,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 362,indent: 1,parent: 360,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Doug",lastActionAmount: "6.25",boardCards: "",
},
{
id: 363,indent: 0,parent: null,handNum: "114",wonOrLost: "-0.50",startAmt: "34.75",endAmt: "34.25",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 364,indent: 1,parent: 363,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 365,indent: 1,parent: 363,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 366,indent: 1,parent: 363,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 367,indent: 0,parent: null,handNum: "115",wonOrLost: "0.00",startAmt: "34.25",endAmt: "34.25",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 368,indent: 1,parent: 367,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 369,indent: 0,parent: null,handNum: "116",wonOrLost: "-1.00",startAmt: "34.25",endAmt: "33.25",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 370,indent: 1,parent: 369,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 371,indent: 1,parent: 369,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.00",amountToPot: "16",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "0.75",boardCards: "",
},
{
id: 372,indent: 1,parent: 369,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 373,indent: 1,parent: 369,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 374,indent: 1,parent: 369,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 375,indent: 0,parent: null,handNum: "117",wonOrLost: "0.00",startAmt: "33.25",endAmt: "33.25",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 376,indent: 1,parent: 375,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 377,indent: 0,parent: null,handNum: "118",wonOrLost: "-33.25",startAmt: "33.25",endAmt: "0.00",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 378,indent: 1,parent: 377,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 379,indent: 1,parent: 377,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "6.75",amountToPot: "22",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 380,indent: 1,parent: 377,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "8.25",potSizeToWin: "8.25",amountToPot: "100",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 381,indent: 1,parent: 377,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "BetAllIn",amount: "23.00",potSizeToWin: "24.75",amountToPot: "92",numPlayers: "2",numAllIns: "1",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, [7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 382,indent: 0,parent: null,handNum: "121",wonOrLost: "-0.50",startAmt: "60.00",endAmt: "59.50",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 383,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 384,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 385,indent: 1,parent: 382,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "2.75",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 386,indent: 0,parent: null,handNum: "122",wonOrLost: "-0.50",startAmt: "59.50",endAmt: "59.00",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 387,indent: 1,parent: 386,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 388,indent: 1,parent: 386,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 389,indent: 1,parent: 386,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 390,indent: 0,parent: null,handNum: "123",wonOrLost: "0.00",startAmt: "59.00",endAmt: "59.00",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 391,indent: 1,parent: 390,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 392,indent: 0,parent: null,handNum: "124",wonOrLost: "7.50",startAmt: "59.00",endAmt: "63.00",finalHand: "Pair, 8's",position: "BB (2 of 6)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 393,indent: 1,parent: 392,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 394,indent: 1,parent: 392,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 395,indent: 1,parent: 392,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 396,indent: 1,parent: 392,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 397,indent: 1,parent: 392,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "2.50",potSizeToWin: "5.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "CheckRaise",lastActionPlayer: "Doug",lastActionAmount: "3.00",boardCards: "",
},
{
id: 398,indent: 1,parent: 392,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 399,indent: 0,parent: null,handNum: "125",wonOrLost: "-1.00",startAmt: "63.00",endAmt: "62.00",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 400,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 401,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.75",potSizeToWin: "2.75",amountToPot: "27",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "",
},
{
id: 402,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 403,indent: 1,parent: 399,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "3.50",boardCards: "",
},
{
id: 404,indent: 0,parent: null,handNum: "126",wonOrLost: "0.00",startAmt: "62.00",endAmt: "62.00",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 405,indent: 1,parent: 404,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 406,indent: 0,parent: null,handNum: "127",wonOrLost: "-2.50",startAmt: "62.00",endAmt: "59.50",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 407,indent: 1,parent: 406,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 408,indent: 1,parent: 406,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "4.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 409,indent: 1,parent: 406,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "6.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 410,indent: 0,parent: null,handNum: "128",wonOrLost: "0.00",startAmt: "59.50",endAmt: "59.50",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 411,indent: 1,parent: 410,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 412,indent: 0,parent: null,handNum: "129",wonOrLost: "16.50",startAmt: "59.50",endAmt: "68.00",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 413,indent: 1,parent: 412,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 414,indent: 1,parent: 412,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "3.50",amountToPot: "57",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.00",boardCards: "",
},
{
id: 415,indent: 1,parent: 412,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "5.50",potSizeToWin: "11.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "5.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 416,indent: 1,parent: 412,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "5.00",potSizeToWin: "16.50",amountToPot: "30",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 417,indent: 0,parent: null,handNum: "130",wonOrLost: "-0.50",startAmt: "68.00",endAmt: "67.50",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 418,indent: 1,parent: 417,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 419,indent: 1,parent: 417,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "",
},
{
id: 420,indent: 0,parent: null,handNum: "131",wonOrLost: "-0.50",startAmt: "67.50",endAmt: "67.00",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 421,indent: 1,parent: 420,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 422,indent: 1,parent: 420,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 423,indent: 1,parent: 420,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 424,indent: 1,parent: 420,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "2.00",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 425,indent: 0,parent: null,handNum: "132",wonOrLost: "-0.50",startAmt: "67.00",endAmt: "66.50",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 426,indent: 1,parent: 425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.25",amountToPot: "22",numPlayers: "6",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 427,indent: 1,parent: 425,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 428,indent: 0,parent: null,handNum: "133",wonOrLost: "14.25",startAmt: "66.50",endAmt: "76.25",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 429,indent: 1,parent: 428,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 430,indent: 1,parent: 428,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.50",potSizeToWin: "7.25",amountToPot: "34",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 431,indent: 1,parent: 428,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 432,indent: 1,parent: 428,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Raise",amount: "4.00",potSizeToWin: "12.75",amountToPot: "31",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 433,indent: 0,parent: null,handNum: "134",wonOrLost: "-0.50",startAmt: "76.25",endAmt: "75.75",finalHand: "",position: "MP1 (4 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 434,indent: 1,parent: 433,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 435,indent: 1,parent: 433,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 436,indent: 1,parent: 433,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 437,indent: 1,parent: 433,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 438,indent: 1,parent: 433,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "1.25",boardCards: "",
},
{
id: 439,indent: 0,parent: null,handNum: "135",wonOrLost: "0.00",startAmt: "75.75",endAmt: "75.75",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 440,indent: 1,parent: 439,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 441,indent: 0,parent: null,handNum: "136",wonOrLost: "-0.50",startAmt: "75.75",endAmt: "75.25",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 442,indent: 1,parent: 441,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 443,indent: 1,parent: 441,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 444,indent: 1,parent: 441,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 445,indent: 0,parent: null,handNum: "137",wonOrLost: "-0.50",startAmt: "75.25",endAmt: "74.75",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 446,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 447,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 448,indent: 1,parent: 445,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 449,indent: 0,parent: null,handNum: "138",wonOrLost: "0.00",startAmt: "74.75",endAmt: "74.75",finalHand: "",position: "Dealer (6 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 450,indent: 1,parent: 449,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 451,indent: 0,parent: null,handNum: "139",wonOrLost: "11.25",startAmt: "74.75",endAmt: "82.00",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 452,indent: 1,parent: 451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 453,indent: 1,parent: 451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "6.25",amountToPot: "32",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "",
},
{
id: 454,indent: 1,parent: 451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 455,indent: 1,parent: 451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "9.75",amountToPot: "15",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 456,indent: 1,parent: 451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "11.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 457,indent: 1,parent: 451,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "1.50",potSizeToWin: "11.25",amountToPot: "13",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 458,indent: 0,parent: null,handNum: "140",wonOrLost: "0.00",startAmt: "82.00",endAmt: "82.00",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 459,indent: 1,parent: 458,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 460,indent: 0,parent: null,handNum: "141",wonOrLost: "4.49",startAmt: "82.00",endAmt: "84.37",finalHand: "Two Pair, K's & J's",position: "UTG1 (3 of 6)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 461,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "0.75",amountToPot: "133",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 462,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 463,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.12",potSizeToWin: "2.25",amountToPot: "49",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 464,indent: 1,parent: 460,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "4.49",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 465,indent: 0,parent: null,handNum: "142",wonOrLost: "-0.50",startAmt: "84.37",endAmt: "83.87",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 466,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 467,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 468,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 469,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 470,indent: 1,parent: 465,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 471,indent: 0,parent: null,handNum: "143",wonOrLost: "-0.25",startAmt: "83.87",endAmt: "83.62",finalHand: "",position: "SB (1 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 472,indent: 1,parent: 471,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 473,indent: 1,parent: 471,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 474,indent: 0,parent: null,handNum: "144",wonOrLost: "23.61",startAmt: "83.62",endAmt: "96.61",finalHand: "Full House, J's over Q's",position: "Dealer (6 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 475,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.62",potSizeToWin: "1.75",amountToPot: "92",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 476,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "7.61",amountToPot: "26",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 477,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "3.50",potSizeToWin: "13.11",amountToPot: "26",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "3.50",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 478,indent: 1,parent: 474,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "3.50",potSizeToWin: "20.11",amountToPot: "17",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "3.50",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 479,indent: 0,parent: null,handNum: "145",wonOrLost: "0.00",startAmt: "96.61",endAmt: "96.61",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 480,indent: 1,parent: 479,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 481,indent: 0,parent: null,handNum: "151",wonOrLost: "-0.75",startAmt: "96.61",endAmt: "95.86",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 482,indent: 1,parent: 481,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "PostsMissingSmallBlind",amount: "0.25",potSizeToWin: "0.75",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 483,indent: 1,parent: 481,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "PostsMissingBigBlind",amount: "0.50",potSizeToWin: "1.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 484,indent: 1,parent: 481,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 485,indent: 1,parent: 481,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 486,indent: 0,parent: null,handNum: "152",wonOrLost: "-1.25",startAmt: "95.86",endAmt: "94.61",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 487,indent: 1,parent: 486,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.25",potSizeToWin: "0.75",amountToPot: "166",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 488,indent: 1,parent: 486,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "5.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 489,indent: 0,parent: null,handNum: "153",wonOrLost: "-0.50",startAmt: "94.61",endAmt: "94.11",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 490,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 491,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 492,indent: 1,parent: 489,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "1.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [7<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 493,indent: 0,parent: null,handNum: "154",wonOrLost: "-0.25",startAmt: "94.11",endAmt: "93.86",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 494,indent: 1,parent: 493,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 495,indent: 1,parent: 493,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 496,indent: 0,parent: null,handNum: "155",wonOrLost: "0.00",startAmt: "93.86",endAmt: "93.86",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 497,indent: 1,parent: 496,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 498,indent: 0,parent: null,handNum: "156",wonOrLost: "0.00",startAmt: "93.86",endAmt: "93.86",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 499,indent: 1,parent: 498,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 500,indent: 0,parent: null,handNum: "157",wonOrLost: "29.25",startAmt: "93.86",endAmt: "110.36",finalHand: "Two Pair, A's & 5's",position: "MP1 (4 of 6)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 501,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 502,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "5.25",amountToPot: "19",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 503,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Raise",amount: "3.25",potSizeToWin: "7.25",amountToPot: "44",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 504,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "3.00",potSizeToWin: "13.25",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 505,indent: 1,parent: 500,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "5.00",potSizeToWin: "24.25",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "5.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 506,indent: 0,parent: null,handNum: "158",wonOrLost: "9.25",startAmt: "110.36",endAmt: "115.86",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 507,indent: 1,parent: 506,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 508,indent: 1,parent: 506,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "3.75",amountToPot: "26",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 509,indent: 1,parent: 506,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.25",potSizeToWin: "4.75",amountToPot: "47",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 510,indent: 1,parent: 506,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.25",potSizeToWin: "9.25",amountToPot: "24",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 511,indent: 0,parent: null,handNum: "159",wonOrLost: "-5.00",startAmt: "115.86",endAmt: "110.86",finalHand: "",position: "BB (2 of 6)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 512,indent: 1,parent: 511,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 513,indent: 1,parent: 511,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "4.50",amountToPot: "33",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 514,indent: 1,parent: 511,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 515,indent: 1,parent: 511,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "7.50",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 516,indent: 1,parent: 511,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 517,indent: 1,parent: 511,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.50",potSizeToWin: "10.50",amountToPot: "14",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 518,indent: 1,parent: 511,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 519,indent: 0,parent: null,handNum: "160",wonOrLost: "-0.25",startAmt: "110.86",endAmt: "110.61",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 520,indent: 1,parent: 519,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 521,indent: 1,parent: 519,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "2.18",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.43",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 522,indent: 0,parent: null,handNum: "161",wonOrLost: "0.00",startAmt: "110.61",endAmt: "110.61",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 523,indent: 1,parent: 522,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 524,indent: 0,parent: null,handNum: "162",wonOrLost: "-2.50",startAmt: "110.61",endAmt: "108.11",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 525,indent: 1,parent: 524,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 526,indent: 1,parent: 524,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "4.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 527,indent: 1,parent: 524,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "37.34",amountToPot: "0",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "CheckRaiseAllIn",lastActionPlayer: "Dave",lastActionAmount: "31.34",boardCards: "",
},
{
id: 528,indent: 0,parent: null,handNum: "163",wonOrLost: "-1.00",startAmt: "108.11",endAmt: "107.11",finalHand: "",position: "MP1 (4 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 529,indent: 1,parent: 528,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 530,indent: 1,parent: 528,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.25",amountToPot: "15",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "",
},
{
id: 531,indent: 1,parent: 528,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 532,indent: 1,parent: 528,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 533,indent: 1,parent: 528,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "3.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 534,indent: 0,parent: null,handNum: "164",wonOrLost: "0.00",startAmt: "107.11",endAmt: "107.11",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 535,indent: 1,parent: 534,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 536,indent: 0,parent: null,handNum: "165",wonOrLost: "-0.50",startAmt: "107.11",endAmt: "106.61",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 537,indent: 1,parent: 536,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 538,indent: 1,parent: 536,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 539,indent: 1,parent: 536,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 540,indent: 0,parent: null,handNum: "166",wonOrLost: "-0.25",startAmt: "106.61",endAmt: "106.36",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 541,indent: 1,parent: 540,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 542,indent: 1,parent: 540,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 543,indent: 0,parent: null,handNum: "167",wonOrLost: "0.00",startAmt: "106.36",endAmt: "106.36",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 544,indent: 1,parent: 543,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 545,indent: 0,parent: null,handNum: "168",wonOrLost: "0.00",startAmt: "106.36",endAmt: "106.36",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 546,indent: 1,parent: 545,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 547,indent: 0,parent: null,handNum: "169",wonOrLost: "0.00",startAmt: "106.36",endAmt: "106.36",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 548,indent: 1,parent: 547,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 549,indent: 0,parent: null,handNum: "170",wonOrLost: "0.00",startAmt: "106.36",endAmt: "106.36",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 550,indent: 1,parent: 549,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[9<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 551,indent: 0,parent: null,handNum: "171",wonOrLost: "-1.00",startAmt: "106.36",endAmt: "105.36",finalHand: "",position: "BB (2 of 5)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 552,indent: 1,parent: 551,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 553,indent: 1,parent: 551,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "",
},
{
id: 554,indent: 1,parent: 551,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 555,indent: 1,parent: 551,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.25",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "2.25",boardCards: "",
},
{
id: 556,indent: 0,parent: null,handNum: "172",wonOrLost: "32.00",startAmt: "105.36",endAmt: "121.61",finalHand: "Straight, 8 High",position: "SB (1 of 5)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 557,indent: 1,parent: 556,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 558,indent: 1,parent: 556,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.00",potSizeToWin: "3.00",amountToPot: "66",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 559,indent: 1,parent: 556,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "5.00",amountToPot: "30",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 560,indent: 1,parent: 556,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "4.00",potSizeToWin: "8.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 561,indent: 1,parent: 556,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "8.00",potSizeToWin: "16.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 562,indent: 0,parent: null,handNum: "173",wonOrLost: "-0.50",startAmt: "121.61",endAmt: "121.11",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 563,indent: 1,parent: 562,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 564,indent: 1,parent: 562,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 565,indent: 1,parent: 562,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "1.75",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 566,indent: 0,parent: null,handNum: "174",wonOrLost: "0.00",startAmt: "121.11",endAmt: "121.11",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 567,indent: 1,parent: 566,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 6<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 568,indent: 0,parent: null,handNum: "175",wonOrLost: "0.00",startAmt: "121.11",endAmt: "121.11",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 569,indent: 1,parent: 568,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 570,indent: 0,parent: null,handNum: "176",wonOrLost: "-0.50",startAmt: "121.11",endAmt: "120.61",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 571,indent: 1,parent: 570,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 572,indent: 1,parent: 570,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 573,indent: 0,parent: null,handNum: "177",wonOrLost: "-0.50",startAmt: "120.61",endAmt: "120.11",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 574,indent: 1,parent: 573,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 575,indent: 1,parent: 573,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "2.25",amountToPot: "11",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 576,indent: 1,parent: 573,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 577,indent: 1,parent: 573,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 578,indent: 1,parent: 573,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.50",boardCards: "",
},
{
id: 579,indent: 0,parent: null,handNum: "178",wonOrLost: "0.00",startAmt: "120.11",endAmt: "120.11",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 580,indent: 1,parent: 579,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 581,indent: 0,parent: null,handNum: "179",wonOrLost: "-0.50",startAmt: "120.11",endAmt: "119.61",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 582,indent: 1,parent: 581,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 583,indent: 1,parent: 581,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "1.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 584,indent: 0,parent: null,handNum: "180",wonOrLost: "-0.50",startAmt: "119.61",endAmt: "119.11",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 585,indent: 1,parent: 584,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 586,indent: 1,parent: 584,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 587,indent: 1,parent: 584,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "4<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 588,indent: 0,parent: null,handNum: "181",wonOrLost: "-1.50",startAmt: "119.11",endAmt: "117.61",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 589,indent: 1,parent: 588,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 590,indent: 1,parent: 588,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 591,indent: 1,parent: 588,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.00",potSizeToWin: "2.00",amountToPot: "50",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 592,indent: 1,parent: 588,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "9.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "4.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 593,indent: 0,parent: null,handNum: "182",wonOrLost: "-10.25",startAmt: "117.61",endAmt: "107.36",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 594,indent: 1,parent: 593,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 595,indent: 1,parent: 593,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.50",potSizeToWin: "2.25",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "4",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 596,indent: 1,parent: 593,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "6.25",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 597,indent: 1,parent: 593,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "0.50",potSizeToWin: "7.25",amountToPot: "6",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 598,indent: 1,parent: 593,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "7.75",amountToPot: "19",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 599,indent: 1,parent: 593,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "1.50",potSizeToWin: "15.25",amountToPot: "9",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Arya",lastActionAmount: "3.00",boardCards: "",
},
{
id: 600,indent: 1,parent: 593,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "16.75",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 601,indent: 1,parent: 593,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Call",amount: "5.00",potSizeToWin: "21.75",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "5.00",boardCards: "",
},
{
id: 602,indent: 0,parent: null,handNum: "183",wonOrLost: "0.00",startAmt: "107.36",endAmt: "107.36",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 603,indent: 1,parent: 602,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 604,indent: 0,parent: null,handNum: "184",wonOrLost: "0.00",startAmt: "107.36",endAmt: "107.36",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 605,indent: 1,parent: 604,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 606,indent: 0,parent: null,handNum: "185",wonOrLost: "0.00",startAmt: "107.36",endAmt: "107.36",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 607,indent: 1,parent: 606,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 608,indent: 0,parent: null,handNum: "186",wonOrLost: "-0.50",startAmt: "107.36",endAmt: "106.86",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 609,indent: 1,parent: 608,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 610,indent: 1,parent: 608,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.00",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&diams;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 611,indent: 0,parent: null,handNum: "187",wonOrLost: "3.00",startAmt: "106.86",endAmt: "108.61",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 612,indent: 1,parent: 611,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 613,indent: 1,parent: 611,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 614,indent: 1,parent: 611,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.75",potSizeToWin: "1.50",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 615,indent: 1,parent: 611,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 616,indent: 0,parent: null,handNum: "188",wonOrLost: "10.00",startAmt: "108.61",endAmt: "114.86",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 617,indent: 1,parent: 616,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 618,indent: 1,parent: 616,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 619,indent: 1,parent: 616,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "5.00",amountToPot: "30",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 620,indent: 1,parent: 616,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.75",potSizeToWin: "6.50",amountToPot: "26",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 621,indent: 1,parent: 616,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "2.25",potSizeToWin: "10.00",amountToPot: "22",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 622,indent: 0,parent: null,handNum: "189",wonOrLost: "-1.50",startAmt: "114.86",endAmt: "113.36",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 623,indent: 1,parent: 622,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "1.00",potSizeToWin: "0.75",amountToPot: "133",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 624,indent: 1,parent: 622,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "3.50",amountToPot: "14",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "",
},
{
id: 625,indent: 1,parent: 622,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 626,indent: 1,parent: 622,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, [Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 627,indent: 0,parent: null,handNum: "190",wonOrLost: "-0.50",startAmt: "113.36",endAmt: "112.86",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 628,indent: 1,parent: 627,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.75",amountToPot: "28",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 629,indent: 1,parent: 627,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "10.50",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "2.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 630,indent: 0,parent: null,handNum: "191",wonOrLost: "5.50",startAmt: "112.86",endAmt: "116.11",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 631,indent: 1,parent: 630,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 632,indent: 1,parent: 630,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 633,indent: 1,parent: 630,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.25",potSizeToWin: "3.00",amountToPot: "41",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 634,indent: 1,parent: 630,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Bet",amount: "2.75",potSizeToWin: "5.50",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 635,indent: 0,parent: null,handNum: "192",wonOrLost: "-2.00",startAmt: "116.11",endAmt: "114.11",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 636,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 637,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "6.75",amountToPot: "22",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "",
},
{
id: 638,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "8.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 639,indent: 1,parent: 635,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.50",boardCards: "",
},
{
id: 640,indent: 0,parent: null,handNum: "193",wonOrLost: "2.00",startAmt: "114.11",endAmt: "115.61",finalHand: "",position: "BB (2 of 6)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 641,indent: 1,parent: 640,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 642,indent: 1,parent: 640,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 643,indent: 1,parent: 640,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "2.00",amountToPot: "100",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 644,indent: 0,parent: null,handNum: "194",wonOrLost: "-0.50",startAmt: "115.61",endAmt: "115.11",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 645,indent: 1,parent: 644,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 646,indent: 1,parent: 644,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 647,indent: 1,parent: 644,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 648,indent: 1,parent: 644,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 649,indent: 1,parent: 644,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.00",boardCards: "[7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 650,indent: 0,parent: null,handNum: "195",wonOrLost: "22.50",startAmt: "115.11",endAmt: "127.86",finalHand: "Two Pair, K's & 4's",position: "Dealer (6 of 6)",holeCards: "K<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 651,indent: 1,parent: 650,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "2.25",potSizeToWin: "3.50",amountToPot: "64",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 652,indent: 1,parent: 650,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "7.50",potSizeToWin: "15.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "7.50",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 653,indent: 1,parent: 650,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "22.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 654,indent: 1,parent: 650,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "22.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 655,indent: 0,parent: null,handNum: "196",wonOrLost: "-1.00",startAmt: "127.86",endAmt: "126.86",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 656,indent: 1,parent: 655,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "",
},
{
id: 657,indent: 1,parent: 655,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "0.75",boardCards: "",
},
{
id: 658,indent: 1,parent: 655,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 659,indent: 1,parent: 655,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 660,indent: 1,parent: 655,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 661,indent: 1,parent: 655,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.00",boardCards: "",
},
{
id: 662,indent: 0,parent: null,handNum: "197",wonOrLost: "-1.00",startAmt: "126.86",endAmt: "125.86",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 663,indent: 1,parent: 662,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 664,indent: 1,parent: 662,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "4.00",amountToPot: "12",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "",
},
{
id: 665,indent: 1,parent: 662,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "10.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Arya",lastActionAmount: "5.00",boardCards: "5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 666,indent: 0,parent: null,handNum: "198",wonOrLost: "5.25",startAmt: "125.86",endAmt: "129.61",finalHand: "",position: "BB (2 of 6)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 667,indent: 1,parent: 666,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 668,indent: 1,parent: 666,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "4.25",amountToPot: "23",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 669,indent: 1,parent: 666,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.25",potSizeToWin: "5.25",amountToPot: "42",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 670,indent: 0,parent: null,handNum: "199",wonOrLost: "-0.50",startAmt: "129.61",endAmt: "129.11",finalHand: "",position: "SB (1 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 671,indent: 1,parent: 670,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 672,indent: 1,parent: 670,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.25",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
{
id: 673,indent: 1,parent: 670,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 674,indent: 1,parent: 670,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "3.00",boardCards: "",
},
{
id: 675,indent: 0,parent: null,handNum: "200",wonOrLost: "-6.56",startAmt: "129.11",endAmt: "122.55",finalHand: "",position: "Dealer (6 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 676,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.25",potSizeToWin: "1.75",amountToPot: "128",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 677,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "4.31",potSizeToWin: "5.75",amountToPot: "74",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 678,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "14.37",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 679,indent: 1,parent: 675,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "32.89",amountToPot: "0",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "Doug",lastActionAmount: "18.52",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 680,indent: 0,parent: null,handNum: "201",wonOrLost: "2.00",startAmt: "122.55",endAmt: "124.05",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 681,indent: 1,parent: 680,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 682,indent: 1,parent: 680,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.00",potSizeToWin: "2.00",amountToPot: "100",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 683,indent: 0,parent: null,handNum: "202",wonOrLost: "0.00",startAmt: "124.05",endAmt: "124.05",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 684,indent: 1,parent: 683,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 685,indent: 0,parent: null,handNum: "203",wonOrLost: "0.00",startAmt: "124.05",endAmt: "124.05",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 686,indent: 1,parent: 685,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 687,indent: 0,parent: null,handNum: "204",wonOrLost: "-0.50",startAmt: "124.05",endAmt: "123.55",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 688,indent: 1,parent: 687,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 689,indent: 1,parent: 687,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 690,indent: 1,parent: 687,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 691,indent: 1,parent: 687,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 692,indent: 1,parent: 687,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 693,indent: 1,parent: 687,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "2.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 694,indent: 0,parent: null,handNum: "205",wonOrLost: "-5.75",startAmt: "123.55",endAmt: "117.80",finalHand: "",position: "SB (1 of 6)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 695,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 696,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.50",potSizeToWin: "2.50",amountToPot: "60",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "1.75",boardCards: "",
},
{
id: 697,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 698,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "4.00",potSizeToWin: "8.00",amountToPot: "50",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "4.00",boardCards: "",
},
{
id: 699,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 700,indent: 1,parent: 694,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "27.11",amountToPot: "0",numPlayers: "2",numAllIns: "1",positionToLastAction: "1",lastAction: "BetAllIn",lastActionPlayer: "Doug",lastActionAmount: "15.11",boardCards: "",
},
{
id: 701,indent: 0,parent: null,handNum: "206",wonOrLost: "0.00",startAmt: "117.80",endAmt: "117.80",finalHand: "",position: "Dealer (6 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 702,indent: 1,parent: 701,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 703,indent: 0,parent: null,handNum: "207",wonOrLost: "-0.50",startAmt: "117.80",endAmt: "117.30",finalHand: "",position: "Cutoff (5 of 6)",holeCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 704,indent: 1,parent: 703,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 705,indent: 1,parent: 703,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "1.75",boardCards: "K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 706,indent: 0,parent: null,handNum: "208",wonOrLost: "0.00",startAmt: "117.30",endAmt: "117.30",finalHand: "",position: "MP1 (4 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 707,indent: 1,parent: 706,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Arya",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 708,indent: 0,parent: null,handNum: "209",wonOrLost: "-1.50",startAmt: "117.30",endAmt: "115.80",finalHand: "",position: "UTG1 (3 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 709,indent: 1,parent: 708,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "6",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 710,indent: 1,parent: 708,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "5.25",amountToPot: "19",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "",
},
{
id: 711,indent: 1,parent: 708,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "12.50",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "6.25",boardCards: "6<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, [4<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 712,indent: 0,parent: null,handNum: "210",wonOrLost: "-0.50",startAmt: "115.80",endAmt: "115.30",finalHand: "",position: "BB (2 of 6)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 713,indent: 1,parent: 712,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 714,indent: 1,parent: 712,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 715,indent: 1,parent: 712,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 716,indent: 1,parent: 712,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "12.00",amountToPot: "0",numPlayers: "6",numAllIns: "0",positionToLastAction: "3",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "3.00",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 717,indent: 0,parent: null,handNum: "211",wonOrLost: "-0.25",startAmt: "115.30",endAmt: "115.05",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 718,indent: 1,parent: 717,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 719,indent: 1,parent: 717,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 720,indent: 0,parent: null,handNum: "212",wonOrLost: "-14.00",startAmt: "115.05",endAmt: "101.05",finalHand: "",position: "Dealer (5 of 5)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 721,indent: 1,parent: 720,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Raise",amount: "2.25",potSizeToWin: "1.25",amountToPot: "180",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 722,indent: 1,parent: 720,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.75",potSizeToWin: "8.25",amountToPot: "33",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "2.75",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 723,indent: 1,parent: 720,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Raise",amount: "4.50",potSizeToWin: "12.50",amountToPot: "36",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 724,indent: 1,parent: 720,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "4.50",potSizeToWin: "24.50",amountToPot: "18",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Reraise",lastActionPlayer: "Craig",lastActionAmount: "7.50",boardCards: "",
},
{
id: 725,indent: 1,parent: 720,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "43.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Craig",lastActionAmount: "14.50",boardCards: "10<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 726,indent: 0,parent: null,handNum: "213",wonOrLost: "-0.50",startAmt: "101.05",endAmt: "100.55",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 727,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 728,indent: 1,parent: 726,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 729,indent: 0,parent: null,handNum: "214",wonOrLost: "0.00",startAmt: "100.55",endAmt: "100.55",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 730,indent: 1,parent: 729,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 731,indent: 0,parent: null,handNum: "215",wonOrLost: "-4.00",startAmt: "100.55",endAmt: "96.55",finalHand: "",position: "BB (2 of 5)",holeCards: "5<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 732,indent: 1,parent: 731,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 733,indent: 1,parent: 731,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "",
},
{
id: 734,indent: 1,parent: 731,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "1.50",potSizeToWin: "3.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 735,indent: 1,parent: 731,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.50",potSizeToWin: "7.50",amountToPot: "20",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "3.00",boardCards: "",
},
{
id: 736,indent: 1,parent: 731,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "9.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "K<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 737,indent: 1,parent: 731,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "13.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "4.50",boardCards: "",
},
{
id: 738,indent: 0,parent: null,handNum: "216",wonOrLost: "-1.00",startAmt: "96.55",endAmt: "95.55",finalHand: "",position: "SB (1 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 739,indent: 1,parent: 738,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 740,indent: 1,parent: 738,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.75",potSizeToWin: "2.75",amountToPot: "27",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Bailey",lastActionAmount: "1.00",boardCards: "",
},
{
id: 741,indent: 1,parent: 738,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "3.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 742,indent: 1,parent: 738,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Bailey",lastActionAmount: "3.50",boardCards: "",
},
{
id: 743,indent: 0,parent: null,handNum: "217",wonOrLost: "0.00",startAmt: "95.55",endAmt: "95.55",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 744,indent: 1,parent: 743,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 745,indent: 0,parent: null,handNum: "218",wonOrLost: "0.00",startAmt: "95.55",endAmt: "95.55",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 746,indent: 1,parent: 745,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 747,indent: 0,parent: null,handNum: "219",wonOrLost: "-1.00",startAmt: "95.55",endAmt: "94.55",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 748,indent: 1,parent: 747,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "0.75",amountToPot: "66",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 749,indent: 1,parent: 747,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 750,indent: 1,parent: 747,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Call",amount: "0.50",potSizeToWin: "2.50",amountToPot: "20",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 751,indent: 1,parent: 747,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Fold",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "3.50",boardCards: "J<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&spades;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 752,indent: 0,parent: null,handNum: "220",wonOrLost: "-0.50",startAmt: "94.55",endAmt: "94.05",finalHand: "",position: "BB (2 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 753,indent: 1,parent: 752,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 754,indent: 1,parent: 752,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "1.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 755,indent: 1,parent: 752,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "1.50",boardCards: "Q<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>, [2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 756,indent: 0,parent: null,handNum: "221",wonOrLost: "-0.25",startAmt: "94.05",endAmt: "93.80",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 757,indent: 1,parent: 756,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 758,indent: 1,parent: 756,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.75",boardCards: "",
},
{
id: 759,indent: 0,parent: null,handNum: "222",wonOrLost: "0.00",startAmt: "93.80",endAmt: "93.80",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 760,indent: 1,parent: 759,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 761,indent: 0,parent: null,handNum: "223",wonOrLost: "0.00",startAmt: "93.80",endAmt: "93.80",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 762,indent: 1,parent: 761,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 763,indent: 0,parent: null,handNum: "224",wonOrLost: "0.00",startAmt: "93.80",endAmt: "93.80",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 764,indent: 1,parent: 763,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 765,indent: 0,parent: null,handNum: "225",wonOrLost: "-0.50",startAmt: "93.80",endAmt: "93.30",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 766,indent: 1,parent: 765,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 767,indent: 1,parent: 765,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "4.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "[10<span style = 'font-size:125%; color: blue; '>&diams;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 768,indent: 0,parent: null,handNum: "226",wonOrLost: "-2.50",startAmt: "93.30",endAmt: "90.80",finalHand: "",position: "SB (1 of 4)",holeCards: "Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 769,indent: 1,parent: 768,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 770,indent: 1,parent: 768,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "",
},
{
id: 771,indent: 1,parent: 768,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 772,indent: 1,parent: 768,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "2.00",potSizeToWin: "4.00",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 773,indent: 1,parent: 768,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 774,indent: 1,parent: 768,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "6.00",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, K<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 7<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 775,indent: 0,parent: null,handNum: "227",wonOrLost: "0.00",startAmt: "90.80",endAmt: "90.80",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 776,indent: 1,parent: 775,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 777,indent: 0,parent: null,handNum: "228",wonOrLost: "0.00",startAmt: "90.80",endAmt: "90.80",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 778,indent: 1,parent: 777,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[8<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 779,indent: 0,parent: null,handNum: "229",wonOrLost: "-1.50",startAmt: "90.80",endAmt: "89.30",finalHand: "",position: "BB (2 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 780,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 781,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.00",potSizeToWin: "3.50",amountToPot: "28",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "Dave",lastActionAmount: "1.50",boardCards: "",
},
{
id: 782,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "4.50",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "4<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 783,indent: 1,parent: 779,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "6.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Dave",lastActionAmount: "2.00",boardCards: "",
},
{
id: 784,indent: 0,parent: null,handNum: "230",wonOrLost: "-0.25",startAmt: "89.30",endAmt: "89.05",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 785,indent: 1,parent: 784,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 786,indent: 1,parent: 784,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Bailey",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 787,indent: 0,parent: null,handNum: "231",wonOrLost: "0.00",startAmt: "89.05",endAmt: "89.05",finalHand: "",position: "Dealer (4 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 788,indent: 1,parent: 787,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "3.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "Raise",lastActionPlayer: "Doug",lastActionAmount: "2.25",boardCards: "",
},
{
id: 789,indent: 0,parent: null,handNum: "232",wonOrLost: "0.00",startAmt: "89.05",endAmt: "89.05",finalHand: "",position: "UTG1 (3 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 790,indent: 1,parent: 789,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[A<span style = 'font-size:125%; color: blue; '>&spades;</span>, 2<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 791,indent: 0,parent: null,handNum: "233",wonOrLost: "3.00",startAmt: "89.05",endAmt: "91.05",finalHand: "",position: "BB (2 of 4)",holeCards: "2<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 2<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 792,indent: 1,parent: 791,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 793,indent: 1,parent: 791,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "BigBlind",lastActionPlayer: "John P",lastActionAmount: "0.50",boardCards: "",
},
{
id: 794,indent: 1,parent: 791,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "0.50",potSizeToWin: "2.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>",
},
{
id: 795,indent: 1,parent: 791,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Bet",amount: "1.25",potSizeToWin: "3.00",amountToPot: "41",numPlayers: "2",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "9<span style = 'font-size:125%; color: blue; '>&spades;</span>, 6<span style = 'font-size:125%; color: blue; '>&diams;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 796,indent: 0,parent: null,handNum: "234",wonOrLost: "-1.50",startAmt: "91.05",endAmt: "89.55",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 797,indent: 1,parent: 796,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 798,indent: 1,parent: 796,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.25",potSizeToWin: "1.75",amountToPot: "14",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Dave",lastActionAmount: "0.50",boardCards: "",
},
{
id: 799,indent: 1,parent: 796,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Check",amount: "0.00",potSizeToWin: "2.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 800,indent: 1,parent: 796,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.00",potSizeToWin: "4.00",amountToPot: "25",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "1.00",boardCards: "",
},
{
id: 801,indent: 1,parent: 796,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "3<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 7<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 802,indent: 1,parent: 796,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Fold",amount: "0.00",potSizeToWin: "7.50",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "2.50",boardCards: "",
},
{
id: 803,indent: 0,parent: null,handNum: "235",wonOrLost: "-2.25",startAmt: "89.55",endAmt: "87.30",finalHand: "",position: "Dealer (4 of 4)",holeCards: "10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 804,indent: 1,parent: 803,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.25",amountToPot: "40",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "",
},
{
id: 805,indent: 1,parent: 803,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Call",amount: "1.75",potSizeToWin: "3.50",amountToPot: "50",numPlayers: "3",numAllIns: "0",positionToLastAction: "1",lastAction: "Bet",lastActionPlayer: "Doug",lastActionAmount: "1.75",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>",
},
{
id: 806,indent: 1,parent: 803,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Turn",action: "Check",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 807,indent: 1,parent: 803,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "River",action: "Check",amount: "0.00",potSizeToWin: "7.00",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&clubs;</span>",
},
{
id: 808,indent: 0,parent: null,handNum: "236",wonOrLost: "2.25",startAmt: "87.30",endAmt: "89.05",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "J<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 809,indent: 1,parent: 808,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "0.50",potSizeToWin: "1.50",amountToPot: "33",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "",
},
{
id: 810,indent: 1,parent: 808,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Bet",amount: "2.25",potSizeToWin: "2.25",amountToPot: "100",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "J<span style = 'font-size:125%; color: blue; '>&hearts;</span>, Q<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&hearts;</span>",
},
{
id: 811,indent: 0,parent: null,handNum: "237",wonOrLost: "-0.50",startAmt: "89.05",endAmt: "88.55",finalHand: "",position: "BB (2 of 5)",holeCards: "7<span style = 'font-size:125%; color: blue; '>&diams;</span>, 3<span style = 'font-size:125%; color: blue; '>&diams;</span>",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 812,indent: 1,parent: 811,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.25",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 813,indent: 1,parent: 811,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "8.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "2",lastAction: "Reraise",lastActionPlayer: "Dave",lastActionAmount: "3.50",boardCards: "[5<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, J<span style = 'font-size:125%; color: blue; '>&clubs;</span>]",
},
{
id: 814,indent: 0,parent: null,handNum: "238",wonOrLost: "-0.25",startAmt: "88.55",endAmt: "88.30",finalHand: "",position: "SB (1 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 815,indent: 1,parent: 814,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "5",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 816,indent: 1,parent: 814,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.75",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 3<span style = 'font-size:125%; color: blue; '>&spades;</span>, Q<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 817,indent: 0,parent: null,handNum: "239",wonOrLost: "-1.12",startAmt: "88.30",endAmt: "87.18",finalHand: "",position: "Dealer (5 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 818,indent: 1,parent: 817,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Call",amount: "1.12",potSizeToWin: "2.99",amountToPot: "37",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "Raise",lastActionPlayer: "RB33",lastActionAmount: "1.12",boardCards: "",
},
{
id: 819,indent: 1,parent: 817,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Flop",action: "Fold",amount: "0.00",potSizeToWin: "8.21",amountToPot: "0",numPlayers: "3",numAllIns: "0",positionToLastAction: "2",lastAction: "Bet",lastActionPlayer: "RB33",lastActionAmount: "2.05",boardCards: "A<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 4<span style = 'font-size:125%; color: blue; '>&hearts;</span>, [2<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 820,indent: 0,parent: null,handNum: "240",wonOrLost: "0.00",startAmt: "87.18",endAmt: "87.18",finalHand: "",position: "Cutoff (4 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 821,indent: 1,parent: 820,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "1.25",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "2",lastAction: "BigBlind",lastActionPlayer: "RB33",lastActionAmount: "0.50",boardCards: "[3<span style = 'font-size:125%; color: blue; '>&hearts;</span>, A<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&spades;</span>, 8<span style = 'font-size:125%; color: blue; '>&diams;</span>, 7<span style = 'font-size:125%; color: blue; '>&diams;</span>]",
},
{
id: 822,indent: 0,parent: null,handNum: "241",wonOrLost: "0.00",startAmt: "87.18",endAmt: "87.18",finalHand: "",position: "UTG1 (3 of 5)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 823,indent: 1,parent: 822,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "5",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Doug",lastActionAmount: "0.50",boardCards: "[6<span style = 'font-size:125%; color: blue; '>&hearts;</span>, 10<span style = 'font-size:125%; color: blue; '>&diams;</span>, 10<span style = 'font-size:125%; color: blue; '>&spades;</span>, 9<span style = 'font-size:125%; color: blue; '>&spades;</span>, J<span style = 'font-size:125%; color: blue; '>&spades;</span>]",
},
{
id: 824,indent: 0,parent: null,handNum: "242",wonOrLost: "-0.50",startAmt: "87.18",endAmt: "86.68",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 825,indent: 1,parent: 824,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "BigBlind",amount: "0.50",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 826,indent: 1,parent: 824,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "5.00",amountToPot: "0",numPlayers: "4",numAllIns: "0",positionToLastAction: "3",lastAction: "Raise",lastActionPlayer: "Craig",lastActionAmount: "1.50",boardCards: "[2<span style = 'font-size:125%; color: blue; '>&diams;</span>, 5<span style = 'font-size:125%; color: blue; '>&diams;</span>, 9<span style = 'font-size:125%; color: blue; '>&clubs;</span>, 6<span style = 'font-size:125%; color: blue; '>&spades;</span>, K<span style = 'font-size:125%; color: blue; '>&hearts;</span>]",
},
{
id: 827,indent: 0,parent: null,handNum: "243",wonOrLost: "-0.25",startAmt: "86.68",endAmt: "86.43",finalHand: "",position: "SB (1 of 4)",holeCards: "",step: "",action: "",amount: "",potSizeToWin: "",amountToPot: "",numPlayers: "",numAllIns: "",positionToLastAction: "",lastAction: "",lastActionPlayer: "",lastActionAmount: "",boardCards: "",
},
{
id: 828,indent: 1,parent: 827,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "SmallBlind",amount: "0.25",potSizeToWin: "0.00",amountToPot: "",numPlayers: "4",numAllIns: "0",positionToLastAction: "0",lastAction: "",lastActionPlayer: "",lastActionAmount: "0.00",boardCards: "",
},
{
id: 829,indent: 1,parent: 827,handNum: "",wonOrLost: "",startAmt: "",endAmt: "",finalHand: "",position: "",holeCards: "",step: "Preflop",action: "Fold",amount: "0.00",potSizeToWin: "0.75",amountToPot: "0",numPlayers: "2",numAllIns: "0",positionToLastAction: "1",lastAction: "BigBlind",lastActionPlayer: "Craig",lastActionAmount: "0.50",boardCards: "",
},
];
